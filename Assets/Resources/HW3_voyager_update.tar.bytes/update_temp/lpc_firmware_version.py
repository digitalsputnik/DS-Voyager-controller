import time
import serial

ser = serial.Serial(
        port='/dev/ttyS1',
        baudrate=750000,          # 115200 in versions v0.00.1 - v0.02.0. 750000 from version v0.02.1 o$
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
		rtscts=True,
        timeout=0               # Rx timeout, debugging only, adds delay. Defau
)

ser.flushInput()
ser.flushOutput()

firmware_version = [0xd5, 0x0a, 0x30, 0x01, 0x20, 0xef, 0xfe, 0x37]
firmware_update = [0xd5, 0x0a, 0x30, 0x02, 0x30, 0xef, 0xfe, 0x3B]

ser.write(firmware_version[:len(firmware_version)])
time.sleep(0.01)
ser_received_data = []
for i in range(50):
    ser_received_data.append(0)
ser_received_data = (ser.read(24))

#print(ser_received_data)
start_flag1 = ser_received_data[0:1]
start_flag1 = int.from_bytes(start_flag1, byteorder = 'big')
start_flag2 = ser_received_data[1:2]
start_flag2 = int.from_bytes(start_flag2, byteorder = 'big')
packet_definition1 = ser_received_data[2:3]
packet_definition1 = int.from_bytes(packet_definition1, byteorder = 'big')
packet_definition2 = ser_received_data[3:4]
packet_definition2 = int.from_bytes(packet_definition2, byteorder = 'big')

if  start_flag1 == 0xD5 and start_flag2 == 0x0A and packet_definition1 == 0x30 and packet_definition2 == 0x01:
	firmware_ver = ser_received_data[5:7]
	firmware_ver = int.from_bytes(firmware_ver, byteorder = 'big')
	print('Firmware version			' + str(firmware_ver))

ser.close()
exit()
