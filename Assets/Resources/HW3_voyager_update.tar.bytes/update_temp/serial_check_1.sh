if [ -f /mnt/data/serial.txt ]; then
	echo "serial_check_1 ok"
else
	echo "no serial.txt"
fi
