echo "if you want some sort of thing to run automatically, edit me"

mac_final6chars="voyager_$(/sbin/ip addr show wlan1 | /bin/sed -n 2p | /usr/bin/tr -d : | /usr/bin/cut -d ' ' -f 6 | /usr/bin/cut -c 7-)"
if [ "$mac_final6chars" == "voyager_" ]
then
	#no wifi interfaces, bad boot, waits for power cycle by LPC	
	sleep 30
else
	#restore
	cp /etc/net_orig/interfaces /mnt/data/net/interfaces
	cp /etc/net_orig/dnsmasq.conf /mnt/data/net/dnsmasq.conf 

	#restore in case hostapd conf goes missing..
	hostapd_line_check=$(wc -l < /mnt/data/net/hostapd.conf)
	if [[ ! -f /mnt/data/net/hostapd.conf  || "$hostapd_line_check" -lt  2 ]]; then
		#hostapd conf file not empty
		cp /etc/net_orig/hostapd.conf /mnt/data/net/hostapd.conf
		#ssid changed backup name. otherwise keeps original.
		active_ssid_line_check=$(wc -l < /mnt/data/active_ssid.txt)
		if [ "$active_ssid_line_check" -gt 1 ]; then
			ssid=$(cat /mnt/data/active_ssid.txt | awk 'NR==1')
			password=$(cat /mnt/data/active_ssid.txt | awk 'NR==2')
			sed -i "4 s/.*/ssid=$ssid/" /mnt/data/net/hostapd.conf
			sed -i "/wpa_passphrase=/c\wpa_passphrase=$password" /mnt/data/net/hostapd.conf
		fi
	fi

	#changes to network config, avoids changing readonly backups of network
	sed -i '/channel=3/c\channel=6' /mnt/data/net/hostapd.conf
	sed -i '/wpa=3/c\wpa=2' /mnt/data/net/hostapd.conf
	#echo "wmm_enabled=0" >> /mnt/data/net/hostapd.conf
	#echo "beacon_int=300" >> /mnt/data/net/hostapd.conf
	sed -i "/dhcp-range/c\dhcp-range=172.20.0.100,172.20.0.250,168h" /mnt/data/net/dnsmasq.conf
	
	#remove old leases
	rm /var/lib/misc/dnsmasq.leases
	touch /var/lib/misc/dnsmasq.leases

	#dhcp restart after removing leases and restoring network from backups.
	/etc/init.d/S80dnsmasq restart

	#disable power saving
	iwconfig wlan1 power off
	iwconfig wlan0 power off

	#reset timesyncflag
	echo 0 > /mnt/data/timesyncflag
	
	network_mode=$(cat /mnt/data/network_mode)
	
	if [ "$network_mode" == "client_mode" ] ; then
		(sleep 3; python3 /mnt/data/client_only.py )&
		echo 0 > /mnt/data/timesyncflag
	else
		(sleep 3; python3 /mnt/data/ap_only.py )&
		echo 1 > /mnt/data/timesyncflag
	fi
	echo $network_mode
	python3 /mnt/data/ut2.6.py &
	nice -11 python3 /mnt/data/animation/PythonReceiver.py &
	#sh /mnt/data/autoconnect.sh &
	
	python3 /mnt/data/timesync_service.py &

fi
