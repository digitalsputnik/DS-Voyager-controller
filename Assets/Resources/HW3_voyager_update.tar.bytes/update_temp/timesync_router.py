#!/usr/bin/env python

#11.04.2018. Removed approximation of delay, using only the last packet delay received!

# add to ignore own poll reply

#Timesync v 0.02
#1. broadcasts asking for time.
#2. collects IPs and unicasts with same packet and measures delay.
#3. chooses IP with the lowest delay, sends another packet and sets own time by that.
#4. if delay is over 200(?), ignore..?


#port number issue?
# add timeout if synced gone to try again.
# HOST CHECK before unicasting to it
# check after setting synced flag, only synced.
# timecompare..

def main():
	
	import socket
	import sys
	import time
	import os
	
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

	sock.settimeout(0.5)
	HOST = os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $9}'").readline().strip()
	IP = os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip()
	PORT = 30005

	os.system("ps ax | grep timesync_service |grep -v grep| awk -F ' ' '{print $1}' | xargs kill -9")
		
	#timepacket - legacy
	timepacket1 = bytearray()
	timepacket1[0:8] = 0xD5, 0x0A, 0x83, 0x10, 0xFF, 0x00, 0x00, 0x00

	#dummy packet
	timepacket2 = bytearray()
	timepacket2[0:8] = 0xD5, 0x0A, 0x84, 0x10, 0xFF, 0x00, 0x00, 0x00
	
	#flagged packet
	timepacket3 = bytearray()
	timepacket3[0:8] = 0xD5, 0x0A, 0x85, 0x10, 0xFF, 0x00, 0x00, 0x00

	synced_voyagers = 0
	search_counter=0
	while search_counter<3:
		#broadcasts flagged to everyone in network
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))

		#looks for flagged sync
		count = 0
		#print ("start search")
		while count <= 3:
			#tries to read udp with timeouts.
			try:
				count += 1
				#print (count)

				udp_data, addr = sock.recvfrom(4096)
				
				#while addr != IP:
				#	udp_data, addr = sock.recvfrom(4096)		
				
				#print (list(udp_data))
				#checks flagged packet and to ignore own ip
				if  (udp_data[0] == 0xD5 and udp_data[1] == 0x0A and udp_data[2] == 0x85 and udp_data[3] == 0x20 and
					(addr)[0] != os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip()):
					print ("found synced")
					synced_voyagers = 1
					# exit loop
					count = 100
					search_counter = 100
				else:
					pass
					#print ("bad response")		
					
			except KeyboardInterrupt:
				sock.close()
				sys.exit()
			except:
				pass
				#print ("udp receive timeout or wrong packet length")
				
		search_counter += 1
		print ("search counter", search_counter)
			
	###NO SYNCED VOYAGER FOUNDS, 
	###SET ITSELF WITH SYNCED FLAG
	if synced_voyagers == 0:
		print ("setting itself as sync")
		os.system("echo 1 > /mnt/data/timesyncflag")
		#sys.exit(1)
		time.sleep (1)
		#check no flags appeared..
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))
		sock.sendto(timepacket3, (HOST, PORT))
		try:
			udp_data, addr = sock.recvfrom(4096)
			if  (udp_data[0] == 0xD5 and udp_data[1] == 0x0A and udp_data[2] == 0x85 and udp_data[3] == 0x20 and
					(addr)[0] != os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip()):
				os.system("echo 0 > /mnt/data/timesyncflag")
				#os.system("python3 /mnt/data/timesync_router.py")
				sys.exit(1)
			else:
				os.system("ps ax | grep timesync_service |grep -v grep| awk -F ' ' '{print $1}' | xargs kill -9")
				os.system("python3 /mnt/data/timesync_service.py &")
				sys.exit(1)

		except:
			os.system("ps ax | grep timesync_service |grep -v grep| awk -F ' ' '{print $1}' | xargs kill -9")
			os.system("python3 /mnt/data/timesync_service.py &")
			sys.exit(1)
			
	#socket restart, empties buffer
	time.sleep (0.5)
	sock.close()
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	sock.settimeout(1)
		
	sync_ok = 0
	sync_counter = 0
	while sync_ok != 1:
		sync_counter += 1
		#SET TIME
		master_counter = 0
		while master_counter < 10:

			final_receive_delay = time.time()
			sock.sendto(timepacket2, (addr))
			
			try:
				udp_data, addr2 = sock.recvfrom(4096)

				while addr2 != addr:
					udp_data, addr2 = sock.recvfrom(4096)				
			except:
				master_counter += 1
				#print ("set noresponse")
				continue
			
			#print ("set", list(udp_data))
				
			if (udp_data[0] == 0xD5 and udp_data[1] == 0x0A and udp_data[2] == 0x84 and udp_data[3] == 0x20):
				final_receive_delay1 = time.time() - final_receive_delay
				datestring = float(udp_data[4:].decode('utf-8')) + float(final_receive_delay1) + 0.021
				os.system("date -s @" + str(datestring))
				
				time.sleep(0.2)			

				#print (float(final_receive_delay1))
				#print (float(udp_data[4:].decode('utf-8')))
				#print (datestring)
				
				master_counter = 100
			
			else:
				#print ("set", master_counter)
				master_counter += 1
				continue
		
		### CHECK SET TIME ###
		bad_delay = 0
		counter = 0
		while counter < 10:
			#time.sleep (0.05)
			final_receive_delay = time.time()
			sock.sendto(timepacket2, (addr))
			try: 
				udp_data, addr2 = sock.recvfrom(4096)		
				
			except KeyboardInterrupt:
				sock.close()
				sys.exit()
			except:
				counter += 1
				continue
				#print ("no response")
				
				#sock.close()
				#sys.exit(1)
			
			final_receive_delay1 = time.time() - final_receive_delay
			x = time.time()
			t = (x-float(udp_data[4:].decode('utf-8')) + float(final_receive_delay1) - 0.009)

			
			#print ("check", counter, list(udp_data))
			
			#print (t)

			if t > 0.005 or t < -0.005:
				bad_delay += 1
			counter += 1

		if bad_delay > 8:
			pass
		else:
			#print("ok")
			sync_ok = 1
			
		#print ("baddelay", bad_delay)	
		#print (sync_counter)
	

	###SYNC OK, SETS FLAG
	if sync_ok == 1:
		print ("sync ok, set flag")
		os.system("echo 1 > /mnt/data/timesyncflag")
		#restart ut

	try:
		udp_data, addr = sock.recvfrom(4096)
		#print (list(udp_data), addr)
	except:
		pass
		#print ("no spam")
	#print ("exit")
	os.system("ps ax | grep timesync_service |grep -v grep| awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("python3 /mnt/data/timesync_service.py &")
	"""			
	main_counter=0
	while main_counter<10:
		try:
			if main_counter > 8:
				time.sleep(1)		
			
			#send packet to IPs found and measure delays.
			sock.settimeout(0.5)

			send_count = 0
			while send_count < 3:

				for address_number_response in range(0,address_number):
					try:
					
						#sets time record when was something sent, tries to receive a packet and measure timedelay
						
						timeset[address_number_response] = time.time()
						print (timeset[address_number_response])
						sock.sendto(rgbw1, addr[address_number_response])
						udp_data, addr1[address_number_response] = sock.recvfrom(4096)
						while (addr[address_number_response] != addr1[address_number_response]):
							udp_data, addr1[address_number_response] = sock.recvfrom(4096)
						
						if (addr[address_number_response] == addr1[address_number_response]):
							if (udp_data[0] == 0xD5 and udp_data[1]== 0x0A and udp_data[2] == 0x84 and udp_data[3] == 0x20):
								timedelay[address_number_response] = time.time()
								print (timedelay[address_number_response])
					except:
						#resets and tries again.
						timedelay[address_number_response] = time.time()
						address_number_response -= 1
						
				#calculating time differences
				for i in range(0,address_number):
					#packet not from self
					if ((addr[i])[0] != os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip()):
						timediff[i] = timedelay[i] - timeset[i]
						print (timediff[i])
						timedifftotal[i] = timedifftotal[i] + timediff[i]
						print (timedifftotal[i])
						print (send_count+1)
						print ("division" ,(timedifftotal[i]) / (send_count+1) )
						print (i, addr[i], addr1[i], timediff[i], timedifftotal[i] / (send_count+1) , "time difference calculation")
				send_count += 1
				time.sleep(0.05)		
				
			final_delay = (sorted(timedifftotal[:address_number], key=int)[0]) / send_count
			print ("aproximate delay from ip", float(final_delay))
			print ("from address", addr1[timedifftotal.index(sorted(timedifftotal[:address_number], key=int)[0])])
			
				
			#ask for new current time packet, measure delays just in case
			new_addr = addr1[timedifftotal.index(sorted(timedifftotal[:address_number], key=int)[0])]
			print (new_addr)
					

			#print ("END TIMING")
			#time.sleep (100)
					
			final_receive_delay = time.time()
			sock.sendto(rgbw4, new_addr)	
			
			try:
				udp_data, new_addr = sock.recvfrom(4096)
			except:
				pass

			if (udp_data[0] == 0xD5 and udp_data[1] == 0x0A and udp_data[2] == 0x85 and udp_data[3] == 0x20):
				final_receive_delay1 = ((time.time() - final_receive_delay) + final_receive_delay) / 2
				print (final_receive_delay1)
				#time.sleep(100)
				datestring = float(udp_data[4:].decode('utf-8')) + float(final_receive_delay1) + 0.021
				os.system("date -s @" + str(datestring))
				
				time.sleep(0.2)			
				
			if new_addr != addr1[address_number_response]:
				main_counter += 1
				continue
			
			sock.close()
			
			break

		except KeyboardInterrupt:
			sock.close()
			sys.exit()
		except:
			print ("something wrong..")
		
	#os.system("ps ax | grep PythonReceiver | awk -F ' ' '{print $1}' | xargs kill -9")
	#os.system("nice -11 python3 /mnt/data/animation/PythonReceiver.py &")
	
	#os.system("python3 /mnt/data/ut2.6.py &")
	
	#os.system("sh /mnt/data/autoconnect.sh &")
	
	#os.system("/etc/init.d/S80dnsmasq restart")
	
	#if main_counter > 9:
	#	os.system("python3 /mnt/data/timesync-ask.py")
	"""
if __name__ == "__main__":
    x= main()
    #print( x )


	
	
	#while (new_addr != addr1[address_number_response]):
	#	udp_data, addr1[address_number_response] = sock.recvfrom(4096)
	#final_receive_delay = os.popen("date +%s%3N ").readline().strip()
	
#except:
#	main_counter += 1
#	continue
	#return "ERROR no response"	
	#sock.close()
	#exit()

#final delay from last time packet
#final_receive_delay = int(os.popen("date +%s%3N ").readline().strip()) - int(final_receive_delay)
#print (final_receive_delay)	
#print (final_delay - final_receive_delay)	
#if (final_delay - final_receive_delay) > 30:
#	return "ERROR receive too long"
#	sock.close()
#	exit()
	
#analyze packet, set correct format and set local time. 
#if (udp_data[0] == 0xD5 and udp_data[1] == 0x0A and udp_data[2] == 0x83 and udp_data[3] == 0x20):
#final_receive_delay = int(os.popen("date +%s%3N ").readline().strip()) - int(final_receive_delay) + 11
#print (final_receive_delay)
#datestring = int(udp_data[4:].decode('utf-8')) + int((final_receive_delay+final_delay)/2) # + 126230400000# 4 years date packge is able to set time. Weird bug where it cannot set time into past since boot....
#datestring = int(udp_data[4:].decode('utf-8')) + int((final_receive_delay))#+final_delay)/2) # + 126230400000# 4 years date packge is able to set time. Weird bug where it cannot set time into past since boot....

#datestring = int(udp_data[4:].decode('utf-8')) + int(os.popen("date +%s%3N ").readline().strip()) - int(final_receive_delay) + 7 #+final_delay)/2) # + 126230400000# 4 years date packge is able to set time. Weird bug where it cannot set time into past since boot....

#setdatestring = str(datestring)[:len(str(datestring))-3] + '.' + str(datestring)[len(str(datestring))-3:]

#print (os.popen("date +%s%3N").readline().strip())
#print (setdatestring, "delayed")
			
