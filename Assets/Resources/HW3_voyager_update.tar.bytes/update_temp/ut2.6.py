#Revision 3 voyager

#Andro 2018.06.19
#old ut2 script, now the main UDP communication between the outside world
#scrapped version of reinvented mesh mess

#massive while loop, polls for udp and serial received with timeouts. Needs a cleanup
#activates periodic polling at the start, every POLLING_DELAY, reads again and starts sending new packet.

# - maybe remove delay and add refresh telemetry packet, controlled delay

VERSION=[0, 75] # 2 byte values
CLIENT_PING_DELAY = 5 # for led status, how often tries to ping, inbetween sends previous state
POLLING_DELAY = 5 # how often reads info from LPC when receives polling state.
SSIDLIST_POLL_DELAY = 20 # ssidlist polling time
NETWORK_CHANGE_DELAY = 20 # wait before accecpting another network change

import time
import serial
import sys
import socket
import os
import json
import netifaces


toHex = lambda x: " ".join("{:02X}".format(c) for c in x)

ser = serial.Serial(
        port='/dev/ttyS1',
        baudrate=750000,	  # 115200 in versions v0.00.1 - v0.02.0. 750000 from version v0.02.1 on.
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        rtscts=True,
        timeout=0               # Rx timeout, debugging only, adds delay
)

ser.flushInput()
ser.flushOutput()

serNumberOfBytesRx = 0
serReceivedData = []

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
PORT  = 30000
HOST = ""                       #listen to all IPs
sock.bind((HOST,PORT))
sock.settimeout(0.1)			#socket timeout, tries to read serial inbetween udp timeouts.

udp_data = bytearray(5)

#color status
#short
rgbw0 = bytearray()
rgbw0[0:16] = 0xd5, 0x0a, 0x10, 0x08, 0x02, 0x00, 0x28, 0x00, 0x28, 0x00, 0x00, 0x00, 0x00, 0xef, 0xfe, 0x00
#long
rgbw1 = bytearray()
rgbw1[0:16] = 0xd5, 0x0a, 0x10, 0x08, 0x02, 0x00, 0x50, 0x00, 0x50, 0x00, 0x00, 0x00, 0x00, 0xef, 0xfe, 0x00

#full length
rgbw2 = bytearray()
rgbw2[0:8] = 0xD5, 0x0A, 0x10, 0x03, 0x00, 0x00, 0x00, 0x52
for x in range(0, 330, 4):
 rgbw2[x+8:x+8+4] = 0x00, 0x00, 0x00, 0x00  #RGBW
rgbw2[340:343] = 0xEF, 0xFE, 0x00

#dirty fix for timesync, adds 4 years since epoch, cannot set time back since boot.. not sure whats blocking.. timesync
current_time = os.popen("date +%s%3N").readline().strip()
if int(current_time) < 1262304000:
	os.system("date -s 'Tue Jan  1 00:00:00 UTC 1974'")

# time delays how often some action
client_start_time = time.time() - CLIENT_PING_DELAY
start_time_polling = time.time() - POLLING_DELAY
start_time_ssidlist = time.time() - SSIDLIST_POLL_DELAY
start_time_network_change = time.time() - NETWORK_CHANGE_DELAY

ping_response = 0
#for timesync package, values above need reset
	
#Reading passive(1) or active(0) mode,export PE0 pin
os.system("echo 128 > /sys/class/gpio/export")
os.system("echo in > /sys/class/gpio/gpio128/direction")

UDPResponse = {}

#poll info or states for which need to be read only once
length_read_flag = 0
lpc_read_flag = 0
chip_read_flag = 0
animation_read_flag = 0
serial_read_flag = 0
mac_read_flag = 0

ap_mode=0
client_mode=0

UDPResponseJSON=0
led_number=0

rawscan = ""
ssidlist_counter = 0

#read lamp length from file
try:
	if os.path.isfile("/mnt/data/led_number.txt"):
		led_number = int(os.popen("cat /mnt/data/led_number.txt").readline().strip())
		if led_number == 42 or led_number == 83:
			length_read_flag = 1
except:
	pass

#CRC
crctab = bytearray([0x00,0x5e,0xbc,0xe2,0x61,0x3f,0xdd,0x83,0xc2,0x9c,0x7e,0x20,0xa3,0xfd,0x1f,0x41,0x9d,0xc3,0x21,0x7f,0xfc,0xa2,0x40,0x1e,0x5f,0x01,0xe3,0xbd,0x3e,0x60,0x82,0xdc,0x23,0x7d,0x9f,0xc1,0x42,0x1c,0xfe,0xa0,0xe1,0xbf,0x5d,0x03,0x80,0xde,0x3c,0x62,0xbe,0xe0,0x02,0x5c,0xdf,0x81,0x63,0x3d,0x7c,0x22,0xc0,0x9e,0x1d,0x43,0xa1,0xff,0x46,0x18,0xfa,0xa4,0x27,0x79,0x9b,0xc5,0x84,0xda,0x38,0x66,0xe5,0xbb,0x59,0x07,0xdb,0x85,0x67,0x39,0xba,0xe4,0x06,0x58,0x19,0x47,0xa5,0xfb,0x78,0x26,0xc4,0x9a,0x65,0x3b,0xd9,0x87,0x04,0x5a,0xb8,0xe6,0xa7,0xf9,0x1b,0x45,0xc6,0x98,0x7a,0x24,0xf8,0xa6,0x44,0x1a,0x99,0xc7,0x25,0x7b,0x3a,0x64,0x86,0xd8,0x5b,0x05,0xe7,0xb9,0x8c,0xd2,0x30,0x6e,0xed,0xb3,0x51,0x0f,0x4e,0x10,0xf2,0xac,0x2f,0x71,0x93,0xcd,0x11,0x4f,0xad,0xf3,0x70,0x2e,0xcc,0x92,0xd3,0x8d,0x6f,0x31,0xb2,0xec,0x0e,0x50,0xaf,0xf1,0x13,0x4d,0xce,0x90,0x72,0x2c,0x6d,0x33,0xd1,0x8f,0x0c,0x52,0xb0,0xee,0x32,0x6c,0x8e,0xd0,0x53,0x0d,0xef,0xb1,0xf0,0xae,0x4c,0x12,0x91,0xcf,0x2d,0x73,0xca,0x94,0x76,0x28,0xab,0xf5,0x17,0x49,0x08,0x56,0xb4,0xea,0x69,0x37,0xd5,0x8b,0x57,0x09,0xeb,0xb5,0x36,0x68,0x8a,0xd4,0x95,0xcb,0x29,0x77,0xf4,0xaa,0x48,0x16,0xe9,0xb7,0x55,0x0b,0x88,0xd6,0x34,0x6a,0x2b,0x75,0x97,0xc9,0x4a,0x14,0xf6,0xa8,0x74,0x2a,0xc8,0x96,0x15,0x4b,0xa9,0xf7,0xb6,0xe8,0x0a,0x54,0xd7,0x89,0x6b,0x35])
def CalcCrc8(packet, length):
	length = int(length) & 0xff
	temp = 0xff	# seed value
	for i in range(0, length):
		temp = temp ^ crctab[temp ^ packet[i]]
	return temp

def wifi_reset():
	#AP config
	#os.system("cp /etc/net_orig/hostapd.conf /mnt/data/net/hostapd.conf")
	#set active ssid to system default
	serial = os.popen("cat /mnt/data/serial.txt").readline().strip()
	if serial != "":
		os.system("echo %s > /mnt/data/active_ssid.txt" % serial)
		os.system("echo 'dsputnik' >> /mnt/data/active_ssid.txt")
	#Default ssid to connect to
	os.system("echo '\"voyager_router\" dsputnik' > /mnt/data/ssidlist.txt")
	
	#start AP
	ap_start()

def connect_client():
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	
	os.system("echo client_mode > /mnt/data/network_mode")
	#kill AP
	os.system("/etc/init.d/S99_hostapd stop")
	os.system("/etc/init.d/S80dnsmasq stop")
	os.system("ifdown wlan1")
	os.system("ifconfig wlan1 0.0.0.0 down")
	os.system("iplink set wlan1 down")
	#restart client
	os.system("/etc/init.d/S45connman restart")
	time.sleep(2)
	os.system("rfkill unblock all")
	
	#set pattern in /mnt/data/ssidlist.txt
	try:
		# bytearray is translated into dictionary
		# is string, not bytearray, needsto be bytearray for writing
		pattern_ssid = network_dict['set_pattern']
		pattern_ps = network_dict['set_pattern_ps']
		if pattern_ssid != "":

			# translation to bytes is necessary for CHIP-pro. otherwise encoding error occurs
			# UnicodeEncodeError: 'ascii' codec can't encode characters in position 1-2: ordinal not in range(128)
			# Removal of first character necessary due to format b<> is done using $ infront of %s ($%s)
			os.system('echo "$(echo -e \\"$%s\\")"  "$(echo -e $%s)" > /mnt/data/ssidlist.txt' % (bytes(pattern_ssid, 'utf-8'), bytes(pattern_ps, 'utf-8')))
			#os.system('echo -e \\"%s\\" | cut -c2- > /mnt/data/ssidlist.txt' % bytes(pattern_ssid_str, 'utf-8'))
			#os.system('echo \\"$(echo -e %s | cut -c2-)\\" $(echo -e %s | cut -c2-) > /mnt/data/ssidlist.txt' % (bytes(pattern_ssid, 'utf-8'), bytes(pattern_ps, 'utf-8')))
	except Exception as e:
		print ("no new pattern: %s" % e)
	
	time.sleep(7)
	
	#print ("start connection")
	os.system("echo 0 > /mnt/data/timesyncflag")
	os.system("sh /mnt/data/connect_cm_v2.sh &")
	#set flag
	
def ap_start():
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")

	# another dirty fix to enable AP to AP connections.
	os.system("/etc/init.d/S99_hostapd stop")
	os.system("/etc/init.d/S80dnsmasq stop")
	os.system("ifdown wlan1")
	os.system("ifconfig wlan1 0.0.0.0 down")
	os.system("iplink set wlan1 down")
	#restart client
	os.system("/etc/init.d/S45connman restart")
	time.sleep(2)
	os.system("rfkill unblock all")
	
	time.sleep(4)

	os.system("echo ap_mode > /mnt/data/network_mode")
	#reset AP config
	os.system("cp /etc/net_orig/hostapd.conf /mnt/data/net/hostapd.conf")
	
	serial = os.popen("cat /mnt/data/serial.txt").readline().strip()
	if serial != "":
		os.system("sed -i '4 s/.*/ssid=%s/' /mnt/data/net/hostapd.conf" % serial)
	
	os.system("sed -i '/channel=/c\channel=6' /mnt/data/net/hostapd.conf")
	os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=dsputnik' /mnt/data/net/hostapd.conf")
	os.system("sed -i '/wpa=/c\wpa=2' /mnt/data/net/hostapd.conf")

	#restore ssid from backup txt
	try:
		if os.path.isfile("/mnt/data/active_ssid.txt"):
			with open("/mnt/data/active_ssid.txt") as f:
				templist = f.readlines()
				os.system("sed -i '4 s/.*/ssid=%s/' /mnt/data/net/hostapd.conf" % templist[0].strip())
				if templist[1].strip() != "":
					os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /mnt/data/net/hostapd.conf" % templist[1].strip())
				else:
					#no password
					os.system("sed -i '/wpa=/c\wpa=0' /mnt/data/net/hostapd.conf")
					os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /mnt/data/net/hostapd.conf" % templist[1].strip())
	except:
		print ("active ssid file error")

	### SET SSID AND PASSWORD
	try:
		ssid = network_dict['set_ssid']
		password = network_dict['set_password']
		#ssid
		if ssid != "":
			os.system("sed -i '4 s/.*/ssid=%s/' /mnt/data/net/hostapd.conf" % ssid) #kinda danger, replaces by line number
			os.system("echo %s > /mnt/data/active_ssid.txt" % ssid)
			#open network settings..
			if password != "":
				os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /mnt/data/net/hostapd.conf" % password)
				os.system("sed -i '/wpa=/c\wpa=2' /mnt/data/net/hostapd.conf")
				os.system("echo %s >> /mnt/data/active_ssid.txt" % password)
			else:
				os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /mnt/data/net/hostapd.conf" % password)
				os.system("sed -i '/wpa=/c\wpa=0' /mnt/data/net/hostapd.conf")
				os.system("echo %s >> /mnt/data/active_ssid.txt" % password)
	except:
		print ("no ssid, password")	

	### SET CHANNEL
	try:
		channel = network_dict['set_channel']
		if channel >= 1 and channel <= 11:
			os.system("sed -i '/channel=/c\channel=%s' /mnt/data/net/hostapd.conf" % channel)
	except:
		print ("no channel")


	#kill client
	os.system("ls /var/lib/connman/*| grep -v settings| xargs rm -rf")
	os.system("/etc/init.d/S45connman stop")
	os.system("ifdown wlan0")
	os.system("ifconfig wlan0 down")
	os.system("ps ax | grep -v grep | grep wpa_supplicant | awk -F ' ' '{print $1}' | xargs kill -9")
	#restart AP
	os.system("ip link set arp off dev wlan1")
	os.system("ip link set arp on dev wlan1")
	os.system("ifconfig wlan1 0.0.0.0")
	os.system("/etc/init.d/S80dnsmasq stop")
	os.system("/etc/init.d/S99_hostapd stop")
	os.system("ifdown wlan1")
	os.system("ifconfig wlan1 down")
	os.system("rm /var/lib/misc/dnsmasq.leases")
	os.system("touch /var/lib/misc/dnsmasq.leases")
	time.sleep(4)
	os.system("ifconfig wlan1 up")
	os.system("ifup wlan1")
	time.sleep(1)
	os.system("/etc/init.d/S80dnsmasq start")
	os.system("/etc/init.d/S99_hostapd start")
	os.system("ifconfig wlan1 172.20.0.1 netmask 255.255.255.0")
	#set flag
	os.system("echo 1 > /mnt/data/timesyncflag")

#send start polling signal to LPC
periodic_update_length = 10
periodic_update = bytearray()
periodic_update = bytearray([0xD5, 0x0A, 0x50, 0x0A, 0x30, 0x01, 0x30, 0xEF, 0xFE, 0x00])
periodic_update[9] = CalcCrc8(periodic_update, periodic_update_length-1)
#print (list(periodic_update))

poll_info = 0
time.sleep(0.1)
periodic_update_ok = 0
"""
while periodic_update_ok == 0:

	ser.write(periodic_update)
	time.sleep(0.05)
	periodic_update_answer = ser.read(20)
	#print ("periodic", list(periodic_update_answer))

	if len(periodic_update_answer) > 4:
		#enabled
		if periodic_update_answer[0] == 0xD5 and periodic_update_answer[1] == 0x0A and periodic_update_answer[2] == 0x50 and periodic_update_answer[3] == 0x0A and periodic_update_answer[4] == 0x31:
			periodic_update_ok = 1
		
		#already enabled, poll packet
		if periodic_update_answer[0] == 0xD5 and periodic_update_answer[1] == 0x0A and periodic_update_answer[2] == 0x50 and periodic_update_answer[3] == 0x0B:
			periodic_update_ok = 1
			poll_info=serReceivedData=periodic_update_answer
			udp_data[0:4] = 0xD5, 0x0A, 0x80, 0x10
	
	time.sleep(0.1)
"""
while True:
	try:

		try:
			if periodic_update_ok == 0:
				ser.write(periodic_update)
				time.sleep(0.05)
				periodic_update_answer = ser.read(20)
				#print ("periodic", listc(periodic_update_answer))

				if len(periodic_update_answer) > 4:
					#enabled
					if periodic_update_answer[0] == 0xD5 and periodic_update_answer[1] == 0x0A and periodic_update_answer[2] == 0x50 and periodic_update_answer[3] == 0x0A and periodic_update_answer[4] == 0x31:
						periodic_update_ok = 1
					
					#already enabled, poll packet
					if periodic_update_answer[0] == 0xD5 and periodic_update_answer[1] == 0x0A and periodic_update_answer[2] == 0x50 and periodic_update_answer[3] == 0x0B:
						periodic_update_ok = 1
						poll_info=serReceivedData=periodic_update_answer
						udp_data[0:4] = 0xD5, 0x0A, 0x80, 0x10
				
				time.sleep(0.1)
		except:
			pass

		try:
			udp_data, addr = sock.recvfrom(4096)
		except KeyboardInterrupt:
			sock.close()
			ser.close()
			sys.exit()
		except:
			pass
			#print ("no udp packets")
		#print (udp_data)
		#print (UDPResponseJSON)

		# Checks flag bytes
		if ((udp_data[0] == 0xD5) and (udp_data[1]== 0x0A) ) :
			
			#COLOR PACKET
			if (udp_data[2] == 0x10):
				ser.write(udp_data[:len(udp_data)])
				#print("Forwarding length = ", len(udp_data));
				udp_data = bytearray(5)
				
				#print(list(ser.read(len(udp_data))))

			#SSID LIST PACKET RESPONSE
			if (udp_data[2] == 0x87 and udp_data[3] == 0x10):
				try:
					wlan1_interface=os.popen("ifconfig | grep wlan1").readline().strip()
					
					if (time.time() - start_time_ssidlist > SSIDLIST_POLL_DELAY or time.time() - start_time_ssidlist < 0):
						#if ssidlist_counter >= 3:
						#	start_time_ssidlist=time.time()
						#	ssidlist_counter = 0
						#else:
						#	ssidlist_counter += 1
					
						#fix for stuck iwlist scan
						os.system("ps ax | grep -v grep | grep 'iwlist' | awk -F ' ' '{print $1}' | xargs kill -9 2> /dev/null ")
						os.system("echo "" > /tmp/temp_scanlist 2> /dev/null ")
							
						if wlan1_interface == "":
							os.system('echo -e "$(iwlist wlan0 scan | grep SSID: | grep -Eo \'".*"\' | tr -d \'"\')" >> /tmp/temp_scanlist &')
							#rawscan_temp = os.popen("nice --19 iw dev wlan0 scan | grep 'SSID:' | column -t | tr -s ' ' &").read()
							
							#include dbm
							#rawscan_temp  = os.popen("iw dev wlan0 scan | grep 'SSID:\|signal:' | awk '{ ORS = (NR%2 ? FS : RS) } 1' | column -t | tr -s ' ' | grep -E '^.{26,}$' &").read()
						
						else:
							os.system('echo -e "$(iwlist wlan1 scan | grep SSID: | grep -Eo \'".*"\' | tr -d \'"\')" >> /tmp/temp_scanlist &')
							#rawscan_temp = os.popen("nice --19 iw dev wlan1 scan | grep 'SSID:' | column -t | tr -s ' ' &").read()
							
							#include dbm
							#rawscan_temp  = os.popen("iw dev wlan1 scan | grep 'SSID:\|signal:' | awk '{ ORS = (NR%2 ? FS : RS) } 1' | column -t | tr -s ' ' | grep -E '^.{26,}$' &").read()

						#include dbm
						#ssidlist = rawscan.replace('SSID:', '').replace('SSID:', '').replace('signal:', '').replace('dBm ', '').replace('.00 ', '').replace(' -','').strip().replace('\n\n','\n').splitlines()
						
						
						time.sleep(3)
						
						with open("/tmp/temp_scanlist", 'r', encoding="utf-8") as f: 
							rawscan_temp = f.read()
						
						if rawscan_temp != "":
							rawscan = rawscan_temp

						ssidlist=rawscan.replace('SSID: ', '').replace('SSID:', '').strip().replace('\n\n','\n').splitlines()

						if (len(ssidlist)) > 0:
							start_time_ssidlist=time.time()
							sock.sendto(json.dumps(ssidlist).encode() , addr)
						else:
							start_time_ssidlist=time.time()-30
						
					else:
						if (len(ssidlist)) > 0:
							#print(ssidlist)
							#send old packet, clears buffer..
							sock.sendto(json.dumps(ssidlist).encode() , addr)
				except:

					pass
					#print ("ssidlist sending failed")
				
			#RESET PACKET
			if (udp_data[2] == 0x82 and udp_data[3] == 0x10):
				#reset animation
				os.system("rm /mnt/data/animation/strokedata.dat")
				
				#Default ssid to connect to
				os.system("echo '\"voyager_router\" dsputnik' > /mnt/data/ssidlist.txt")
			
				#Restart PythonReceiver
				os.system("ps ax | grep PythonReceiver | grep -v grep | awk -F ' ' '{print $1}' | xargs kill -9")
				os.system("python3 /mnt/data/animation/PythonReceiver.py &")
			
				#reply
				reset = bytearray()
				reset[0:7] = 0xD5, 0x0A, 0x82, 0x20, 0xEF, 0xFE, 0x00
				sock.sendto(reset, addr)
				udp_data = bytearray(5)
			
				#start AP
				ap_start()
			
			#TIME SYNC PACKET
			if (udp_data[2] == 0x83 and udp_data[3] == 0x10):
				#print ("Timesync respond")
				
				#send current time
				time_start = bytearray()
				time_start[0:4] = 0xD5, 0x0A, 0x83, 0x20
				#current_time = os.popen("date +%s%3N").readline().strip()
				current_time = str(time.time())
				time_start[4:] = bytearray(current_time, "ascii")
				#print (time.time())
				#print (list(time_start))
				sock.sendto(time_start, addr)
				udp_data = bytearray(5)
			
			#DUMMY TIME SYNC PACKET - testing timedelays.
			if (udp_data[2] == 0x84 and udp_data[3] == 0x10):
				#send current time
				time_start = bytearray()
				time_start[0:4] = 0xD5, 0x0A, 0x84, 0x20
				#current_time = os.popen("date +%s%3N").readline().strip()
				current_time = str(time.time())
				time_start[4:] = bytearray(current_time, "ascii")
				#print (list(time_start))
				sock.sendto(time_start, addr)
				udp_data = bytearray(5)
			#TIMESYNC FLAGED PACKET - using router. Time has been set or first one in network 
			if (udp_data[2] == 0x85 and udp_data[3] == 0x10):
				#send current time
				if os.popen("cat /mnt/data/timesyncflag").readline().strip() == "1":
					time_start = bytearray()
					time_start[0:4] = 0xD5, 0x0A, 0x85, 0x20
					current_time = str(time.time())
					time_start[4:] = bytearray(current_time, "ascii")
					sock.sendto(time_start, addr)
					udp_data = bytearray(5)
				
			### POLL INFO COLLECTION ###
			#POLL PACKET FROM UDP DEVICE OUTSIDE
			if (udp_data[2] == 0x80 and udp_data[3] == 0x10):
			
				#print ("poll")
				#not an empty packet from LPC
				if poll_info != 0:
				
					#timedelay how often reads and calculates poll, incase timesync sets time back...
					if (time.time() - start_time_polling > POLLING_DELAY or time.time() - start_time_polling < 0):
						start_time_polling=time.time()
					
						#crc check for lpc sent packet
						poll_info_crc = CalcCrc8(poll_info, len(poll_info)-1)
						if poll_info[16] == CalcCrc8(poll_info, len(poll_info)-1):

							### IP
							#sets client wlan0 by default
							try:
								if len(netifaces.ifaddresses('wlan0')) >= 3:
									UDPResponse["IP"] = list(socket.inet_aton(netifaces.ifaddresses('wlan0')[2][0]['addr']))
								else:
									UDPResponse["IP"] = list(socket.inet_aton(netifaces.ifaddresses('wlan1')[2][0]['addr']))
							except:
								pass
								#no ip.. still fails length check..
							
							### NUMBER OF LEDS
							if length_read_flag == 0:
								UDPResponse["length"] = poll_info[12]
								led_number = poll_info[12]
								length_read_flag = 1
								os.system("echo %s > /mnt/data/led_number.txt" % led_number)
							else:
								UDPResponse["length"] = poll_info[12]
							
							### BATTERY LEVEL
							UDPResponse["battery_level"] = poll_info[5]
							
							### BQ TEMPERATURE
							try:
								kelvin = float(int.from_bytes(poll_info[6:8], byteorder='big'))
								celsius = kelvin/10 - 273.15
								UDPResponse["BQ_temp"] = int(str(celsius)[:2]), int(str(celsius)[3:4])
							except:
								pass
								#need to overlook this temp calculation..
							
							### CHARGING
							UDPResponse["charging_status"] = list(poll_info[8:10])
							
							### LPC VERSION
							UDPResponse["LPC_version"] = list(poll_info[10:12])
							
							### Voyager Hardware version
							UDPResponse["hardware_version"] = poll_info[13]
							
							### CHIP VERSION
							if chip_read_flag == 0: 
								UDPResponse["CHIP_version"] = VERSION
								chip_read_flag = 1
							
							### ANIMATION VERSION 
							if animation_read_flag == 0:
								if os.path.isfile("/mnt/data/animation/version"):
									animation_ver_read = os.popen("cat /mnt/data/animation/version").readline().strip().split('.')
									animation_ver_read  = [int(i) for i in animation_ver_read ]
									UDPResponse["animation_version"] = animation_ver_read
									animation_read_flag = 1
								else:
									UDPResponse["animation_version"] = [0,0]
									animation_read_flag = 1
									
							### LAST 6 MAC addr
							if mac_read_flag == 0:
								UDPResponse["MAC_last6"] = os.popen("ip addr show wlan1 | sed -n 2p | tr -d : | cut -d ' ' -f 6 | cut -c 7-").readline().strip()
								mac_read_flag = 1
							
							### PASSIVE/ACTIVE MODE
							try:
								with open("/sys/class/gpio/gpio128/value") as f:
									UDPResponse["passive_active_mode"] = int(f.read())
							except:
								pass

							### ACTIVE SSID PATTERN TO CONNECT TO ###
							try:
								if os.path.isfile("/mnt/data/ssidlist.txt"):
									with open("/mnt/data/ssidlist.txt", "r", encoding='utf-8') as f:
										temp_pattern = f.readline()
									splitActivePattern = temp_pattern[1:].split("\" ")

									if len(splitActivePattern) > 0:
										UDPResponse["active_pattern"] = splitActivePattern[0].strip()
										UDPResponse["active_pattern_ps"] = ""
										if len(splitActivePattern) > 1:
											UDPResponse["active_pattern_ps"] = splitActivePattern[1].strip()
									else:
										UDPResponse["active_pattern"] = ""
										UDPResponse["active_pattern_ps"] = ""

							except:
								pass
	
							### ACTIVE SSID AND CHANNEL ###
							try:
								with open("/mnt/data/net/hostapd.conf") as f:
									templist = f.readlines()[3:12]
								UDPResponse["active_ssid"] = templist[0].strip()[5:]
								UDPResponse["active_channel"] = templist[1].strip()[8:]
								UDPResponse["active_password"] = templist[8].strip()[15:]
								templist = ""
							except:
								pass

							### ACTIVE NETWORK MODE ###
							try:
								with open("/mnt/data/network_mode") as f:
									UDPResponse["active_mode"] = f.readline().strip()
							except:
								pass
						
							### SERIAL NAME
							if serial_read_flag == 0:
								UDPResponse["serial_name"] = os.popen("cat /mnt/data/serial.txt").readline().strip()
								serial_read_flag = 1
								
							### END POLL PACKET RESPONSE
							UDPResponseJSON = json.dumps(UDPResponse)
							try:
								sock.sendto(UDPResponseJSON.encode(), addr)
							except:
								pass
							#print ("POLL", UDPResponseJSON)
							#print ("POLL")
							#time.sleep(0.1)
					else:
						try:
							sock.sendto(UDPResponseJSON.encode(), addr)
						except:
							pass
					
				serReceivedData = []
				serNumberOfBytesRx = 0
				ser.flushInput()
				ser.flushOutput()
			udp_data = bytearray(5)

		### Needs a better way to listen for JSON and filter it###
		#Network mode 22.05.18
		elif len(udp_data) > 6:
			#print (time.time() - start_time_network_change)
			if time.time() - start_time_network_change > NETWORK_CHANGE_DELAY or time.time() - start_time_network_change < 0:
				try:
					start_time_network_change=time.time()
				
					network_dict = json.loads(udp_data.decode('utf-8'))
					
					#print (network_dict)
					
					if 'network_mode' in network_dict:				
						if network_dict['network_mode'] == "ap_mode":	
							network_response = bytearray()
							network_response[0:8] = 0xD5, 0x0A, 0x86, 0x01, 0x20, 0xEF, 0xFE, 0x00
							sock.sendto(network_response, addr)
							udp_data = bytearray(5)
							
							ap_start()
							
						elif network_dict['network_mode'] == "client_mode":
							network_response = bytearray()
							network_response[0:8] = 0xD5, 0x0A, 0x86, 0x02, 0x20, 0xEF, 0xFE, 0x00
							sock.sendto(network_response, addr)
							udp_data = bytearray(5)
						
							connect_client()
				except:
					pass
				

			#else:
			#	print ("igno")

			udp_data = bytearray(5)
			network_dict = {}
			
		### READ SERIAL INFO on ttyS1 ###
		if(ser.in_waiting != 0):
			serReceivedData = ser.read(50)
			
			#print (list(serReceivedData))
			if len(serReceivedData) > 2:
				if (serReceivedData[0] == 0xD5 and serReceivedData[1] == 0x0A and serReceivedData[2] == 0x50 and serReceivedData[3] == 0x0B):
					poll_info = serReceivedData
					#dirty fix to create first poll packet, get lampserial.
					if UDPResponseJSON==0:
						udp_data[0:4] = 0xD5, 0x0A, 0x80, 0x10			
		
			### SIDE BUTTON ###
			if len(serReceivedData) > 4 and led_number != 0:
				if serReceivedData[0] == 0xD5  and serReceivedData[1]== 0x0A and serReceivedData[2] == 0x50 and serReceivedData[3] == 0x04:
					
					sidebutton_press_time = int.from_bytes(serReceivedData[5:7], byteorder='big')
					#print (sidebutton_press_time)
					
					counter=0
					if sidebutton_press_time >=5000 and sidebutton_press_time < 11000:
						#pause pythonreceiver
						os.system("kill -STOP $(ps ax | grep PythonReceiver.py | grep -v grep |awk 'NR==1{print $1}')")
						
						#reads side button with timeout
						while counter<10:
							if (ser.in_waiting != 0):
								serReceivedData = ser.read(50)
								#print (list(serReceivedData))
								
								if len(serReceivedData) > 4:
									if serReceivedData[0] == 0xD5  and serReceivedData[1]== 0x0A and serReceivedData[2] == 0x50 and serReceivedData[3] == 0x04:
										counter=0
										sidebutton_press_time = int.from_bytes(serReceivedData[5:7], byteorder='big')
										
										#print (sidebutton_press_time)
										
										### short press, switching between modes 3-5s
										if sidebutton_press_time < 10000 and sidebutton_press_time >=5000:
											
											#color reset
											rgbw3 = list(rgbw2)
									
											if led_number == 42:
												rgbw3[168:172] = 0x00, 0x00, 0xFF
											elif led_number == 83:
												rgbw3[332:336] = 0x00, 0x00, 0xFF
											ser.write(rgbw3[:len(rgbw3)])
										
											#print (list(serReceivedData))
										
											#2 packets in one.. old way of reading serial issues
											if len(list(serReceivedData)) == 20:
												if serReceivedData[14] == 0x03:
													
													#print ("AP CLIENT CHANGE 1")
													
													if os.popen("ps ax | grep -v grep | grep connmand | awk -F ' ' 'NR==1{print $3, $4, $5, $6, $7}'").readline().strip() == "/usr/sbin/connmand -n --nodnsproxy -i wlan0":
														ap_start()
													elif os.popen("ps ax | grep -v grep | grep hostapd | awk -F ' ' 'NR==1{print $4}'").readline().strip() == "/etc/hostapd.conf":
														connect_client()
													else:
														ap_start()
													counter = 10000
																							
											elif serReceivedData[4] == 0x03:

												#print ("AP CLIENT CHANGE 2")
											
												if os.popen("ps ax | grep -v grep | grep connmand | awk -F ' ' 'NR==1{print $3, $4, $5, $6, $7}'").readline().strip() == "/usr/sbin/connmand -n --nodnsproxy -i wlan0":
													ap_start()
												elif os.popen("ps ax | grep -v grep | grep hostapd | awk -F ' ' 'NR==1{print $4}'").readline().strip() == "/etc/hostapd.conf":
													connect_client()
												else:
													ap_start()										
												counter = 10000
													
										### long press, switching 
										if sidebutton_press_time >=10000:
											
											rgbw3 = list(rgbw2)														

											#print ("WIFI RESET")

											if led_number == 42:
												rgbw3[168:172] = 0xFF, 0xFF, 0xFF
											elif led_number == 83:
												rgbw3[332:336] = 0xFF, 0xFF, 0xFF
												
											ser.write(rgbw3[:len(rgbw3)])
																
											wifi_reset()
											
											#exit while loop
											counter = 10000
							else:
								counter+=1
								time.sleep(0.1)
								#print (counter, "exit loop")
								
								#print ("AP CLIENT CHANGE 3")
								
								if counter > 8:
									if os.popen("ps ax | grep -v grep | grep connmand | awk -F ' ' 'NR==1{print $3, $4, $5, $6, $7}'").readline().strip() == "/usr/sbin/connmand -n --nodnsproxy -i wlan0":
										ap_start()
									elif os.popen("ps ax | grep -v grep | grep hostapd | awk -F ' ' 'NR==1{print $4}'").readline().strip() == "/etc/hostapd.conf":
										connect_client()
									else:
										ap_start()
									counter = 10000
								
						#resume python player	
						os.system("kill -CONT $(ps ax | grep PythonReceiver.py | grep -v grep |awk 'NR==1{print $1}')")
						os.system("kill -CONT $(ps ax | grep PythonReceiver.py | grep -v grep |awk 'NR==1{print $1}')")
						os.system("kill -CONT $(ps ax | grep PythonReceiver.py | grep -v grep |awk 'NR==1{print $1}')")
						
					sidebutton_press_time=0
		
			###TOP BATTERY BUTTON###
			if len(serReceivedData) > 5:
				# Checks flag bytes
				if ((serReceivedData[0] == 0xD5)  and (serReceivedData[1]== 0x0A) and (serReceivedData[2]== 0x50) and (serReceivedData[3]== 0x05)) :
					### INSTANT PRESS ###
					if (serReceivedData[2] == 0x50 and serReceivedData[3] == 0x05 and serReceivedData[4] == 0x01 ):
		
						#print ("instant press")
						
						#print (list(rgbw0))
						#print (list(serReceivedData))
						
						#dumb ap, hostapd running. display yellow
						if (os.popen("ip addr | egrep -i 'inet.+wlan1' | awk -F[\ /] '{print $6}'").readline().strip() == "172.20.0.1" and 
							os.popen("ps ax | grep -v grep | grep hostapd | awk -F ' ' 'NR==1{print $4}'").readline().strip() == "/etc/hostapd.conf" 
							):
							rgbw0[9:12] = rgbw1[9:12] = 0xFF, 0x70, 0x00
							ser.write(rgbw0[:len(rgbw0)])
							time.sleep(0.05)
							ser.write(rgbw1[:len(rgbw1)])
							time.sleep(0.05)
								 
						# connected client mode. tries to ping host. pings again in CLIENT_PING_DELAY
						elif (os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip() != ''):
							if (time.time() - client_start_time > CLIENT_PING_DELAY or time.time() - client_start_time < 0):
							
								#ping ok, display green
								if (os.system("ping -c 1 -W 1 -I wlan0 $(ip route | awk 'NR==1{print $3}') > /dev/null") == 0 ):
									client_start_time=time.time()
									ping_response = 1
									rgbw0[9:12] = rgbw1[9:12] = 0x00, 0xFF, 0x00
									ser.write(rgbw0[:len(rgbw0)])
									time.sleep(0.05)
									ser.write(rgbw1[:len(rgbw1)])
									
								#no ping response, displays red
								else:
									ping_response = 0
									rgbw0[9:12] = rgbw1[9:12] = 0x70, 0x00, 0x00
									ser.write(rgbw0[:len(rgbw0)])
									time.sleep(0.05)
									ser.write(rgbw1[:len(rgbw1)])
									
							#display green		
							elif( ping_response == 1):
								rgbw0[9:12] = rgbw1[9:12] = 0x00, 0xFF, 0x00
								ser.write(rgbw0[:len(rgbw0)])
								time.sleep(0.05)
								ser.write(rgbw1[:len(rgbw1)])
								
						#not connected client, displays red
						else:
							rgbw0[9:12] = rgbw1[9:12] = 0x70, 0x00, 0x00
							ser.write(rgbw0[:len(rgbw0)])
							time.sleep(0.05)
							ser.write(rgbw1[:len(rgbw1)])
						
			serReceivedData = []
			serNumberOfBytesRx = 0
			ser.flushInput()
			ser.flushOutput()
		#udp_data = bytearray(5)

	except KeyboardInterrupt:
		sock.close()
		ser.close()
		sys.exit()
	except:
		pass

			
sock.close()
ser.close()
exit()

#legacy crap
"""					
#flash led when activating master _M
#for x in range(0, 330, 4):
#	rgbw2[x+8:x+8+4] = 0x80, 0x80, 0x80, 0x80  #RGBW					
#ser.write(rgbw2)
#time.sleep(0.1)

for x in range(0, 330, 4):
	rgbw2[x+8:x+8+4] = 0x00, 0x00, 0x00, 0x00  #RGBW					
ser.write(rgbw2)

#Stops client mode
os.system("ls /var/lib/connman/*| grep -v settings| xargs rm -rf")

#Stop autoconnect
os.system("ps ax | grep autoconnect | awk -F ' ' '{print $1}' | xargs kill -9")

#Starts AP _M
os.system("sh /mnt/data/netchanger.sh 1 &")
					
counter = 0
while counter < 24:
	time.sleep(0.25)
	rgbw0[9:12] = rgbw1[9:12] = 0x00, 0x00, 0xFF
	ser.write(rgbw0[:len(rgbw0)])
	time.sleep(0.05)
	ser.write(rgbw1[:len(rgbw1)])
	counter += 1
	"""		
#legacy
"""
#AP PACKET - start _M access point
if (udp_data[2] == 0x81 and udp_data[3] == 0x10):
#print ("start AP _M")

AP_start_reply = bytearray()
AP_start_reply[0:7] = 0xD5, 0x0A, 0x81, 0x20, 0xEF, 0xFE, 0x00
sock.sendto(AP_start_reply, addr)
udp_data = bytearray(5)

#print ("start |AP")

#flash led when activating master _M
#for x in range(0, 330, 4):
#	rgbw2[x+8:x+8+4] = 0x80, 0x80, 0x80, 0x80  #RGBW					
#ser.write(rgbw2)
#time.sleep(0.1)

for x in range(0, 330, 4):
	rgbw2[x+8:x+8+4] = 0x00, 0x00, 0x00, 0x00  #RGBW					
ser.write(rgbw2)


#Stops client mode
os.system("ls /var/lib/connman/*| grep -v settings| xargs rm -rf")

#Stop autoconnect
os.system("ps ax | grep autoconnect | awk -F ' ' '{print $1}' | xargs kill -9")

#Starts AP _M
os.system("sh /mnt/data/netchanger.sh 1 &")

counter = 0
while counter < 24:
	time.sleep(0.25)
	rgbw0[9:12] = rgbw1[9:12] = 0x00, 0x00, 0xFF
	ser.write(rgbw0[:len(rgbw0)])
	time.sleep(0.05)
	ser.write(rgbw1[:len(rgbw1)])
	counter += 1
	"""	

"""		
#Network mode 21.05.18
#reads packet from outside, if parameters correct, will respond and set new parameters
if (udp_data[2] == 0x91 and udp_data[3] == 0x10):
pass
#AP only
if udp_data[4] == 0x31 and udp_data[5] == 0x10:
	if channel 1-11, ssid != ""
	
	#IP. ip cutting!
	#os.system("sed -i '/address /c\ address %s' /mnt/data/net/interfaces" % IP)
	#os.system("sed -i '/network /c\ network %s.0' /mnt/data/net/interfaces" % IP)#cut
	#os.system("sed -i '/broadcast /c\ broadcast %s.255' /mnt/data/net/interfaces" % IP)#cut
	#os.system("sed -i '/dhcp-range/c\dhcp-range=%s.100,%s.250,168h' /mnt/data/net/dnsmasq.conf" % IP)#cut
	
	#SSID 
	os.system("sed -i '4 s/.*/ssid=%s/' /mnt/data/net/hostapd.conf" % SSID) #kinda danger, replaces by line number

	#channel
	os.system("sed -i '/channel=/c\channel=%s' /mnt/data/net/hostapd.conf" % channel)

	#kill client
	os.system("/etc/init.d/S45connman stop")
	os.system("ifdown wlan0")
	os.system("ifconfig wlan0 down")

	#restart AP
	os.system("ip link set arp off dev wlan1")
	os.system("ip link set arp on dev wlan1")
	os.system("ifconfig wlan1 0.0.0.0")
	os.system("/etc/init.d/S80dnsmasq stop")
	os.system("/etc/init.d/S99_hostapd stop")
	os.system("ifdown wlan1")
	os.system("ifconfig wlan1 down")
	os.system("ps ax | grep connmand | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("ps ax | grep wpa_supplicant | awk -F ' ' '{print $1}' | xargs kill -9")
	os.system("rm /var/lib/misc/dnsmasq.leases")
	os.system("touch /var/lib/misc/dnsmasq.leases")
	
	time.sleep(4)
	os.system("ifconfig wlan1 up")
	os.system("ifup wlan1")
	time.sleep(1)
	os.system("/etc/init.d/S80dnsmasq start")
	os.system("/etc/init.d/S99_hostapd start")
	#os.system("ifconfig wlan1 & netmask 255.255.255.0" + IP)#cut
	
#Client only
if udp_data[4] == 0x32 and udp_data[5] == 0x10:
	if pattern_ssid != ""
	pattern = ssid + "" + password
	os.system("echo %s > /mnt/data/ssidlist.txt" % pattern)
	os.system("ip link set arp off dev wlan1")
	os.system("ip link set arp on dev wlan1")
	os.system("ifconfig wlan1 0.0.0.0")
	os.system("/etc/init.d/S80dnsmasq stop")
	os.system("/etc/init.d/S99_hostapd stop")
	os.system("ifdown wlan1")
	os.system("ifconfig wlan1 down")

	os.system("sh /mnt/data/connect_cm.sh")

#Both
if udp_data[4] == 0x33 and udp_data[5] == 0x10:
	pass
	#IP
	#SSID
	#channel
	#pattern + password
"""
