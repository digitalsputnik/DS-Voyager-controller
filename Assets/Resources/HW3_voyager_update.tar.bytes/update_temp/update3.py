#Main update script for CHIP system and LPC. Andro 10.07.2018

### IMPORTANT ###

#to generate md5sum file on chip, make sure no checklist file exists! : 
#md5sum /mnt/data/update_temp/* > /mnt/data/update_temp/checklist.chk
#remove ssidlist.txt from checklisk.chk
#For LPC update, don't forget to update LPC NEW VERSION number!

import time
import os
import sys
import serial

reboot_needed = 0
NEW_VERSION = 200


def active_mode():
	time.sleep(1)
	ser = serial.Serial(
		port='/dev/ttyS1',
		baudrate=750000,
		parity=serial.PARITY_NONE,
		stopbits=serial.STOPBITS_ONE,
		bytesize=serial.EIGHTBITS,
		rtscts=True,
		timeout=0
	)
	
	ser.flushInput()
	ser.flushOutput()
	ser.write([0xD5, 0x0A, 0x50, 0x09, 0x30, 0x04, 0xEF, 0xFE, 0x57])
	ser.close()



#Just in case if multiple apps should start updating one voyager simultaneously
#exits script
ps = os.popen("ps ax | grep -v grep | grep update3.py | wc -l").read().strip()
if int(ps) > 1:
        print ("UPDATE RUNNING ALREADY")
        sys.exit(1)

#kill processes that use ttyS1
os.system("kill -9 $(ps ax | grep PythonReceiver.py | grep -v grep |awk 'NR==1{print $1}') 2> /dev/null")
os.system("kill -9 $(ps ax | grep ut2.6.py | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")

#kill old legacy autoconnect,timesync. just in case
os.system("kill -9 $(ps ax | grep autoconnect.sh | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")
os.system("kill -9 $(ps ax | grep timecompare.py | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")

###MOVING FILES. CHIP UPDATES###

#check that serial.txt exists.
if os.popen("sh /mnt/data/update_temp/serial_check_1.sh").readline().strip() != "serial_check_1 ok" :
	print ("SERIAL FAIL")
	os.system("setsid python3 /mnt/data/ut2.6.py &")
	sys.exit()

#check md5sum
if "FAILED" in os.popen("md5sum  -c /mnt/data/update_temp/checklist.chk 2> /dev/null ").read().strip():
	print ("MD5SUM FAIL")
	os.system("setsid python3 /mnt/data/ut2.6.py &")
	sys.exit()


#move new files, check new location md5sum
os.system("mv /mnt/data/ssidlist.txt /mnt/data/ssidlist.txt.bak")
os.system("mv /mnt/data/update_temp/* /mnt/data/")
time.sleep(0.1)
os.system("sed -i 's#update_temp/##g' /mnt/data/checklist.chk")
os.system("mv /mnt/data/ssidlist.txt.bak /mnt/data/ssidlist.txt")
time.sleep(0.4)
if "FAILED" in os.popen("md5sum  -c /mnt/data/checklist.chk 2> /dev/null ").read().strip():
	print ("MD5SUM FAIL")
	os.system("setsid python3 /mnt/data/ut2.6.py &")
	sys.exit()

#check if serial update applied
if os.popen("sh /mnt/data/serial_check_2.sh").readline().strip() != "serial_check_2 ok":
	if os.popen("sh /mnt/data/update1.sh").readline().strip() == "update successful":
		reboot_needed = 1
	else:
		print("UPDATE1 FAIL, SERIAL NOT SET")
		os.system("setsid python3 /mnt/data/ut2.6.py &")
		sys.exit()

###LPC###

#Tries to flash twice, if fails 1st.
try:
	lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version.py").readline().strip()[-3:]
	#LPC MAIN FLASHING
	if int(lpc_version) < NEW_VERSION:
		
		#version that supports disable shutdown
		if int(lpc_version) >= 167:
			os.system("python3 /mnt/data/aux_disable_shutdown_30_sec.py")
			time.sleep(0.1)

		os.system("sh /mnt/data/lpc_firmware_update_hw3.sh /mnt/data/voyager_lpc_release_user_update.bin > /dev/null 2> /dev/null")
		time.sleep(0.2)
		
		lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version.py").readline().strip()[-3:]
		#print ("LPC VERSION:", int(lpc_version))
		#reboot_needed = 1 #not needed since 173
		active_mode()
except:
	os.system("sh /mnt/data/lpc_firmware_update_hw3.sh /mnt/data/voyager_lpc_release_user_update.bin > /dev/null 2> /dev/null")
	try:
		lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version.py").readline().strip()[-3:]
		print ("LPC VERSION:", int(lpc_version))
		#reboot_needed = 1 #not needed since 173
		active_mode()
		
	except:
		print ("FAIL. LPC NEEDS REFLASHING")
		os.system("setsid python3 /mnt/data/ut2.6.py &")
		sys.exit()
		
if reboot_needed == 1:
	print ("UPDATE SUCCESSFUL, REBOOT NEEDED")
else:
	print ("UPDATE SUCCESSFUL")

	
#Default ssid replacement. Checks for old placeholder exampleSSID and password
if os.path.isfile("/mnt/data/ssidlist.txt"):
	f = open("/mnt/data/ssidlist.txt", "r")
	temp_ssid = f.readline()
	if len(temp_ssid.split()) > 1:
		if temp_ssid.split()[0] == "exampleSSID" and temp_ssid.split()[1] == "password":
			os.system("echo 'voyager_router dsputnik' > /mnt/data/ssidlist.txt")
	f.close
	

#Update from old legacy version, checks if network_file mode exists. All this or just reboot after update.
if os.path.isfile("/mnt/data/network_mode"):
	#print ("already updated")
	pass
else:

	ap_ssid=os.popen("cat /mnt/data/net/hostapd.conf | grep '\<DS026.........._M\>'").readline().strip()
	ap_ip=os.popen("cat /mnt/data/net/interfaces | grep address | awk '{print $2}'").readline().strip()

	#Old Client mode
	if os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip() != '':
		os.system("echo client_mode > /mnt/data/network_mode")
		os.system("python3 /mnt/data/client_only.py &")
		os.system("echo 0 > /mnt/data/timesyncflag")

	### WIFI RESET FROM OLD _M CONFIG ### 
	#check if master with _M and 172.20.1.1
	elif ap_ssid != "" and ap_ip == "172.20.1.1":	
	
		#reset wifi settings
		os.system("cp /etc/net_orig/interfaces /mnt/data/net/interfaces")
		os.system("cp /etc/net_orig/dnsmasq.conf /mnt/data/net/dnsmasq.conf ")
		os.system("cp /etc/net_orig/hostapd.conf /mnt/data/net/hostapd.conf")
		os.system("sed -i '/channel=/c\channel=6' /mnt/data/net/hostapd.conf")
		os.system("sed -i '/wpa=3/c\wpa=2' /mnt/data/net/hostapd.conf")
		os.system("sed -i '/dhcp-range/c\dhcp-range=172.20.0.100,172.20.0.250,168h' /mnt/data/net/dnsmasq.conf")
		
		#add _M back
		os.system("sed -i '/^ssid=DS026/ s/$/_M/' /mnt/data/net/hostapd.conf")
		
		#restart interface
		os.system("ifconfig wlan1 0.0.0.0")
		os.system("/etc/init.d/S80dnsmasq stop")
		os.system("/etc/init.d/S99_hostapd stop")
		time.sleep(1)
		os.system("ifdown wlan1")
		os.system("ifconfig wlan1 down")
		time.sleep(4)
		os.system("ifconfig wlan1 up")
		os.system("ifup wlan1")
		time.sleep(1)
		os.system("/etc/init.d/S80dnsmasq start")
		os.system("/etc/init.d/S99_hostapd start")
		os.system("ifconfig wlan1 172.20.0.1 netmask 255.255.255.0")
		
		os.system("python3 /mnt/data/ap_only.py")
		os.system("echo 1 > /mnt/data/timesyncflag")
		os.system("echo ap_mode > /mnt/data/network_mode")
	
	#regular ap mode
	else:
		os.system("python3 /mnt/data/ap_only.py")
		os.system("echo ap_mode > /mnt/data/network_mode")
		os.system("echo 1 > /mnt/data/timesyncflag")	
		
		
#backup of a backup. In case hostapd conf goes missing and SSID has been changed.
if not os.path.isfile("/mnt/data/active_ssid.txt"):
	ap_ssid = os.popen("cat /mnt/data/net/hostapd.conf | grep '\<DS026..........\>'").readline().strip()
	serial_ssid = os.popen("cat /mnt/data/serial.txt").readline().strip()
	ap_password = os.popen("cat /mnt/data/net/hostapd.conf | grep passphrase").readline().strip()
	if ap_ssid != "ssid="+serial_ssid or "wpa_passphrase=dsputnik" != ap_password:
		os.system("echo %s > /mnt/data/active_ssid.txt" % ap_ssid)
		os.system("echo %s >> /mnt/data/active_ssid.txt" % ap_password)


### RELAUNCH processes ###
os.system("nice -11 setsid python3 /mnt/data/animation/PythonReceiver.py &")
os.system("setsid python3 /mnt/data/ut2.6.py &")

os.system("kill -9 $(ps ax | grep timesync_service | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")
os.system("setsid python3 /mnt/data/timesync_service.py &")
