#!/bin/sh

kill -9 $(ps ax | grep ut2. | awk 'NR==1{print $1}')
kill -9 $(ps ax | grep PythonReceiver | awk 'NR==1{print $1}')

stty -F /dev/ttyS1 -crtscts                     # Release CTS & DTR pins

echo 205 > /sys/class/gpio/export               # Export ISP pin. 
echo out > /sys/class/gpio/gpio205/direction    # ISP pin output
echo 0 > /sys/class/gpio/gpio205/value          # Set ISP pin low

sleep .2                                        # Wait .2 sec

echo 34 > /sys/class/gpio/export                # Export RESET pin
echo out > /sys/class/gpio/gpio34/direction     # RESET pin output
echo 0 > /sys/class/gpio/gpio34/value           # Set RESET pin low. Do not ever set RESET pin low when ISP is not low! Instant brick!

sleep .2                                        # Wait .2 sec

echo 1 > /sys/class/gpio/gpio34/value           # Set RESET pin high. LPC15xx goes to UART ISP mode.

echo "Flashing user update main program"
/mnt/data/mxli -N LPC1549 -A0x00000000 -B256,512,1024,4096 -F4kix64 -M3ki@0x2000000 -I0x00001549 -P BINARY -S8@7 -f256ki -a 0x19000 -v -E -d /dev/ttyS1 $1
echo "Flashing user update main program complete"

sleep 0.2                                       # Wait .2 sec
echo 1 > /sys/class/gpio/gpio205/value          # Set ISP pin high. Next LPC15xx reset leads to normal boot process.
sleep .2                                        # Wait .2 sec

echo 34 > /sys/class/gpio/unexport              # Unexport RESET pin
echo 205 > /sys/class/gpio/unexport             # Unexport ISP pin

python3 /mnt/data/lpc_firmware_exit_from_bootloader_hw3.py    # Resets LPC15xx