import os
import time

os.system("/etc/init.d/S80dnsmasq stop")
os.system("/etc/init.d/S99_hostapd stop")
os.system("ifdown wlan1")
os.system("ifconfig wlan1 0.0.0.0 down")
os.system("iplink set wlan1 down")

#os.system("/etc/init.d/S45connman start")
#time.sleep(2)
#os.system("rfkill unblock all")
#time.sleep(4)

os.system("sh /mnt/data/connect_cm_v2.sh")

