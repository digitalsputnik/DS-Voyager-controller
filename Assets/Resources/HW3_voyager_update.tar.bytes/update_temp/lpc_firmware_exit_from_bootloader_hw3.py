import time
import serial

ser = serial.Serial(
        port='/dev/ttyS1',
        baudrate=115200,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=1
)

ser.flushInput()
ser.flushOutput()

'''
Reset function written to RAM:

void boot_jump(void)
{
   __asm__("MOV R0, #0x0"); // load vector base address
   __asm__("LDR SP, [R0]"); // Load new stack pointer address
   __asm__("LDR PC, [R0, #4]"); // Load new program counter address
}

'''

write = [0x57, 0x20, 0x33, 0x33, 0x35, 0x35, 0x35, 0x30, 0x35, 0x36, 0x20, 0x31, 0x36, 0x0D, 0x0A]
data = [0x80, 0xB4, 0x00, 0xAF, 0x4F, 0xF0, 0x00, 0x00, 0xD0, 0xF8, 0x00, 0xD0, 0xD0, 0xF8, 0x04, 0xF0]
go = [0x47, 0x20, 0x33, 0x33, 0x35, 0x35, 0x35, 0x30, 0x35, 0x36, 0x20, 0x54, 0x0D, 0x0A]

ser_received_data = []
for i in range(50):
    ser_received_data.append(0)


ser.write(write[:len(write)])
time.sleep(0.1)
ser_received_data = (ser.readline)

ser.write(data[:len(data)])
time.sleep(0.1)
ser_received_data = (ser.readline)

ser.write(go[:len(go)])
time.sleep(0.1)
ser_received_data = (ser.readline)

print('LPC restarting...')

ser.close()

time.sleep(5)

firmware_version = [0xd5, 0x0a, 0x30, 0x01, 0x20, 0xef, 0xfe, 0x37]

ser = serial.Serial(
        port='/dev/ttyS1',
        baudrate=750000,          # 115200 in versions v0.00.1 - v0.02.0. 750000 from version v0.02.1 o$
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=0               # Rx timeout, debugging only, adds delay. Defau
)

for n in range (0, 2):
        ser.write(firmware_version[:len(firmware_version)])

        time.sleep(0.01)
        ser_received_data = []
        for i in range(50):
            ser_received_data.append(0)
        ser_received_data = (ser.read(24))

        start_flag1 = ser_received_data[0:1]
        start_flag1 = int.from_bytes(start_flag1, byteorder = 'big')
        start_flag2 = ser_received_data[1:2]
        start_flag2 = int.from_bytes(start_flag2, byteorder = 'big')
        packet_definition1 = ser_received_data[2:3]
        packet_definition1 = int.from_bytes(packet_definition1, byteorder = 'big')
        packet_definition2 = ser_received_data[3:4]
        packet_definition2 = int.from_bytes(packet_definition2, byteorder = 'big')

        if  start_flag1 == 0xD5 and start_flag2 == 0x0A and packet_definition1 == 0x30 and packet_definition2 == 0x01:
                firmware_ver = ser_received_data[5:7]
                firmware_ver = int.from_bytes(firmware_ver, byteorder = 'big')
                print('LPC ready. Firmware version ' + str(firmware_ver) + '.')
                break
        elif n == 1:
                print('Firmware version unknown.')

ser.close()
exit()

