#!/bin/bash

#14.06.2018. Old autoconnect script.
#For priority listing probably need to port it to python3.


LOCATION=/mnt/data/
TIMEOUT=10
PASSWORD=dsputnik

SSID_FILTER='\<DS026.........._M\>'
SSID_FILTER=$SSID_FILTER'\|''\<voyager_......_M\>'

#old implementation from reading multiple ssids from 
#Makes searchable string from ssidlist.txt, ignores empty lines
number_of_APs=$(wc -l < $LOCATION'ssidlist.txt')
while [ $number_of_APs -gt 0 ]
do
	read_ssid="$(awk NR==$number_of_APs $LOCATION'ssidlist.txt' | cut -d "\"" -f 2)"
	if [ "$read_ssid" != "" ]; then
		#SSID_FILTER=$SSID_FILTER'\|'$read_ssid
		read_ssid=$read_ssid
	fi
	number_of_APs=$(($number_of_APs-1)) 	
done

#enable scanning for "iw dev", otherwise scans clash. Needed for signal strength.
/etc/init.d/S45connman stop

while true
do
	### SCAN and FILTER ###
	
	#reset
	ssid=""
	signal_level=""

	#remove old before adding new confs
	ls /var/lib/connman/*| grep -v settings| xargs rm -rf

	rawscan=$(echo -e "$(nice --19 iwlist wlan0 scan | grep "SSID"  | grep -Eo '".*"')" | grep -w "$(echo -e "$read_ssid")")
	ssid=$(echo "$rawscan" | grep -Eo '".*"' | tr -d '"' )
	

	#second priority from classic _M
	if [ "${#ssid}" -lt 2 ]; then
		rawscan=$(echo -e $(nice --19 iwlist wlan0 scan | grep "SSID"  | grep -Eo '".*"' | grep -w "$SSID_FILTER"))
		ssid=$(echo "$rawscan" | grep -Eo '".*"' | tr -d '"' )
	fi

	
	### MAIN CONNECTION LOOP ###
	#if [[  "${#ssid}" -gt 1  && "$signal_level" -lt 80 ]]; then
	if [ "${#ssid}" -gt 1 ]; then
		#echo "connection loop"

		/etc/init.d/S45connman start
		sleep 2
		rfkill unblock all
		sleep 2
		
		#check if SSID is from ssidlist.txt document and sets the password from there

		password_temp=$(echo -e "$(echo -e "$(cat $LOCATION'ssidlist.txt')" | grep -w "$ssid" | cut -d "\"" -f 3 | cut -c 2-)")
		ssid_temp=$(echo -e "$(echo -e "$(cat $LOCATION'ssidlist.txt')" | grep -w "$ssid" | cut -d "\"" -f 2)")

		if [ "$ssid_temp" == "" ]; then
			PASSWORD=$PASSWORD
		#listed in file, not empty password
		elif [ "$password_temp" != "" ]; then
			PASSWORD=$password_temp
		elif [ "$password_temp" == "" ]; then
			PASSWORD="NONE"
		fi
		
		connmanctl scan wifi
		#get hash from connmanctl, filters by given ssid and looking for start: "wifi_"
		hash=$(connmanctl services | grep -w "$ssid" | grep -o '\bwifi_\w*')

		#echo  $hash
		#echo $ssid_temp
		#echo $password_temp
		#echo $PASSWORD		

		connmanReadableSSIDName=$(python3 - << EOF 
import sys
with open('/mnt/data/ssidlist.txt', 'r', encoding='utf-8') as f:
    read = f.readline()
    data=read[1:].split("\" ")[0].encode()
    print(data)
EOF)
		connmanReadableSSIDName=$(echo "$connmanReadableSSIDName" | cut -c3- | rev | cut -c2- | rev)
		

		if [ "$PASSWORD" == "NONE" ]; then
			cat << EOF > /var/lib/connman/"$connmanReadableSSIDName"-psk.config
			[service_$hash]
			Type = wifi
			Name = $ssid
EOF
		else
			cat << EOF > /var/lib/connman/"$connmanReadableSSIDName"-psk.config
			[service_$hash]
			Type = wifi
			Name = $ssid
			Passphrase = $PASSWORD
EOF
		fi
	
	
		sleep 1.3
		#connmanctl config $hash --autoconnect off > /dev/null
		connmanctl connect $hash > /dev/null &
		sleep 8
		ps ax | grep connmanctl | grep -v grep | awk -F ' ' '{print $1}' | xargs kill -9

		counter_ping=0
		#As soon as get IP or loop 8 cycles
		while [ $counter_ping -lt 10 ]
		do
			#check ip or ping...?
			#if [ "$(ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}')" != "" ]; then
			if ping -c 1 -I wlan0 $(ip route | awk 'NR==1{print $3}') > /dev/null; then
				#echo "connection ok!"

				counter_ping=0
				
				#flag=$(cat /mnt/data/timesyncflag)
				#if [ "$flag" == "0" ]; then
				#	python3 /mnt/data/timesync_router.py
				#	#echo "timesync router"
				#fi
				
				sleep 5
			fi
			sleep 2
			
			counter_ping=$(($counter_ping+1))
			#echo $counter_ping
		done
		
		#echo "connection fail"
		
		
		/etc/init.d/S45connman stop

		#reset timesyncflag
		echo 0 > /mnt/data/timesyncflag
		
	fi
	sleep 15
	#counter=$(($counter+1))
	#echo $counter
done
