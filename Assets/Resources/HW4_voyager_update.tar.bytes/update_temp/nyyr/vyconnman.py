import time
from threading import Thread
import json
import os
import sys
import traceback


class CRawPacket:
    """
        header, payload data, crc8 and footer
        """

    def __init__(self, headerBytes: bytearray = b'', rawdata: bytearray = b'', footerBytes: bytearray = b''):
        self.headerBytes = bytearray(headerBytes)  # type: bytearray
        self.rawdata = rawdata
        self.footerBytes = bytearray(footerBytes)  # type: bytearray
        self.crctab = bytearray(
            [0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41, 0x9d, 0xc3,
             0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc, 0x23, 0x7d, 0x9f, 0xc1,
             0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62, 0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81,
             0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff, 0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,
             0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07, 0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47,
             0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a, 0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45,
             0xc6, 0x98, 0x7a, 0x24, 0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05,
             0xe7, 0xb9, 0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
             0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50, 0xaf, 0xf1,
             0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee, 0x32, 0x6c, 0x8e, 0xd0,
             0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73, 0xca, 0x94, 0x76, 0x28, 0xab, 0xf5,
             0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b, 0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,
             0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16, 0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75,
             0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8, 0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54,
             0xd7, 0x89, 0x6b, 0x35])
        self.crc8 = self.calculateCrc8()

    @staticmethod
    def fromBytearray(packetData, headerSize, footerSize):
        """
        returns CPacket object
        data contained in packet can be invalid when broken data received

        :param packetData: raw data of packet as bytearray
        :type packetData: bytearray
        :param headerSize: size of footer in bytes as int
        :type headerSize: int
        :param footerSize: size of footer in bytes as int
        :type footerSize: int
        :rtype: CRawPacket
        """
        tmpheaderBytes = packetData[:headerSize]
        tmprawdata = packetData[headerSize:len(packetData) - footerSize - 1]
        tmpcrc8 = packetData[len(packetData) - 1]
        tmpfooterBytes = packetData[len(packetData) - footerSize - 1: len(packetData) - 1]
        tmppacket = CRawPacket(tmpheaderBytes, tmprawdata, tmpfooterBytes)

        tmppacket.crc8 = tmpcrc8.to_bytes(1, byteorder='big')

        return tmppacket

    def getPacketGroundID(self):
        """
        :return: packet grounp id (1 packet)
        :type: bytearray
        """
        return self.getpayload()[0:1]

    def iscrc8valid(self):
        """
                returns true when set CRC8 same as newly calculated CRC8, false otherwise

                Use in conjunction with fromBytearray to validate crc8, returning false on crc8 mismatch
                """
        return self.calculateCrc8() == self.crc8

    def getCrc8(self):
        """
                :return: stored crc8 as byte
                """
        return self.crc8

    def getpayload(self):
        """
                returns serialized payload data payload as bytearray.
                """
        return self.rawdata

    def calculateCrc8(self) -> bytes:
        """
        calculates crc8 from whole packet(not crc8)
        :return: calculated crc8 as byte
        """
        fullpacketdata = self.headerBytes + self.getpayload() + self.footerBytes
        payload = fullpacketdata  # subtract crc8
        length = len(payload)
        length = int(length) & 0xff
        temp = 0xff  # seed value
        for i in range(0, length):
            temp = temp ^ self.crctab[temp ^ payload[i]]
        return temp.to_bytes(1, byteorder='big')

    def getbytearray(self) -> bytearray:
        """
        returns serialized packet with calculated crc8 as bytearray
        """
        serializedData = self.headerBytes + self.getpayload() + self.footerBytes + self.getCrc8()

        return serializedData


class CJsonPacket(CRawPacket):
    def __init__(self, headerBytes, packetGroup, jsonData, footerBytes):
        """

        :param headerBytes: header bytes
        :type headerBytes: bytearray
        :param packetGroup: packet group byte (Usually 1 byte)
        :type packetGroup: bytearray
        :param jsonData: json data as python dictionary
        :type jsonData: dict
        :param footerBytes: footer bytes
        :type footerBytes: bytearray
        """
        CRawPacket.__init__(self,
                            headerBytes,
                            packetGroup + str.encode(
                                json.dumps(
                                    jsonData,
                                    separators=(',', ':'),
                                    sort_keys=True)),
                            footerBytes)

    @staticmethod
    def fromRawPacket(packet, headerSize, footerSize):
        """
        :param packet:
        :type packet CRawPacket
        :param headerSize: length of footer size
        :type headerSize int
        :param footerSize: length of header size
        :type footerSize int
        """
        ba = packet.getbytearray()
        return CJsonPacket.fromBytearray(ba, headerSize, footerSize)

    @staticmethod
    def fromBytearray(packetData, headerSize, footerSize):
        """
        returns CPacket object
        data contained in packet can be invalid when broken data received
        """
        tmpheaderBytes = packetData[:headerSize]
        tmpgroupid = packetData[headerSize: headerSize + 1]
        tmprawdata = packetData[headerSize + 1:len(packetData) - footerSize - 1]
        tmpcrc8 = packetData[len(packetData) - 1]
        tmpfooterBytes = packetData[len(packetData) - footerSize - 1: len(packetData) - 1]
        tmppacket = CJsonPacket(tmpheaderBytes, tmpgroupid, json.loads(tmprawdata.decode('utf-8')), tmpfooterBytes)

        tmppacket.crc8 = tmpcrc8.to_bytes(1, byteorder='big')

        return tmppacket

    def getJson(self):
        return json.loads(self.getpayload()[1:].decode('utf-8'))


class CSerialConnectionManager(Thread):
    """
        This receiver handles all incoming and outgoing traffic on serial AMA4
        Checks validity of packet and adds packet to queue.
        Packets are queued by packet id

        packetQueue map of integer packet id and list of full packet object
        """
    headerBytes = bytearray()  # type: bytearray
    footerBytes = bytearray()  # type: bytearray
    packetQueue = {int: [CRawPacket]}
    overallBuffer = bytearray()
    packetBuffer = bytearray()
    constructingPacket = False

    def __init__(self, serialconnection, headerBytes, footerBytes):
        Thread.__init__(self)
        self.packetQueue = {}
        self.headerBytes = headerBytes  # type: bytearray
        self.footerBytes = footerBytes  # type: bytearray

        self.connection = serialconnection

        self.connection.flushInput()
        self.connection.flushOutput()

        self.running = True  # Set running false to stop while loop

    def run(self):
        self.startListening()

    def getPacketCount(self, packetGroupID):
        """
                :param packetGroupID: group id of queue
                :return: numer of packets in queue with group id
                """
        queue = self.packetQueue.get(packetGroupID, None)
        if queue is not None and len(queue) > 0:
            return len(queue)

        return 0

    def clearAllPacketQueues(self):
        """

                :return: None
                """
        self.packetQueue = {}

        return None

    def clearPacketQueue(self, packetGroupID):
        """
                Clears packet queue with given packet group id
                :param packetGroupID: group id of packet to clear
                :return: None
                """

        queue = self.packetQueue.get(packetGroupID, None)
        if queue is not None and len(queue) > 0:
            queue[packetGroupID] = []

        return None

    def popBack(self, packetGroupID):
        """
                :param packetGroupID: group id of packet
                :type: byte
                :return: CRawPacket: packet
                :return: None when none in queue
                """
        queue = self.packetQueue.get(packetGroupID, None)
        if queue is not None and len(queue) > 0:
            return queue.pop(0)
        return None

    def popFront(self, packetGroupID):
        """
                Pop most recent packet with group id in queue
                :param packetGroupID: group id of packet
                :type: byte
                :return: CRawPacket: packet
                :return: None when none in queue
                """
        queue = self.packetQueue.get(packetGroupID, None)
        if queue is not None and len(queue) > 0:
            return queue.pop(len(queue) - 1)
        return None

    def startListening(self):
        while self.running:
            try:
                inBytes = self.connection.inWaiting()
                if inBytes > 0:
                    self.overallBuffer += self.connection.read(inBytes + 1)

                    self.doConstructPacket()
                time.sleep(0.01)
            except KeyboardInterrupt:
                raise
            except Exception as e:

                exc_info = sys.exc_info()

                traceback.print_exception(*exc_info)

                os.system("echo \"Connection manager Exception: %s\" >> /mnt/data/vymain_log.txt" %
                          str(e))
                self.clearAllPacketQueues()

    def doConstructPacket(self):
        """
        Loops over overall buffer and pops first byte.
        on header byte match, begin packet construction
        on footer byte match, end packet construction and add to queue with given packet type ID
        When constructing packet, all bytes popped are added to packetBuffer. (Along with header and footer
        """

        i = 0
        while i < len(self.overallBuffer):
            if not self.constructingPacket:
                headerTestByte = self.overallBuffer[i:i + len(self.headerBytes)]
                if headerTestByte == self.headerBytes:
                    self.constructingPacket = True
                    # Packet buffer is cleared here
                    self.packetBuffer = headerTestByte
                self.overallBuffer = self.overallBuffer[i + len(self.headerBytes):]

            else:
                footerTestBytes = self.overallBuffer[i:i + len(self.footerBytes) + 1]  # footer bytes with crc8
                if footerTestBytes[:len(footerTestBytes) - 1] == self.footerBytes:
                    self.constructingPacket = False
                    self.packetBuffer += footerTestBytes
                    for i in range(0, len(self.footerBytes)):
                        self.overallBuffer.pop(0)

                    newPacket = CRawPacket.fromBytearray(self.packetBuffer,
                                                         len(self.headerBytes),
                                                         len(self.footerBytes))

                    if not newPacket.iscrc8valid() and newPacket.getCrc8() != b'\x00':
                        rawPacketData = newPacket.getbytearray()
                        print("CRC8 not valid - (%s): %s" % (len(rawPacketData), rawPacketData))
                    else:
                        payload = newPacket.getpayload()
                        packetGroupID = payload[0].to_bytes(1, byteorder='big')
                        if len(self.packetQueue.get(packetGroupID, '')) == 0:
                            self.packetQueue[packetGroupID] = []
                        self.packetQueue[packetGroupID].append(newPacket)
                    self.overallBuffer = self.overallBuffer[i + len(self.footerBytes) + 1:]
                else:
                    self.packetBuffer += footerTestBytes[i: i + 1]
                    self.overallBuffer = self.overallBuffer[i + 1:]

    def write(self, packet: CRawPacket) -> int:
        """
        :param packet:
        :type packet: CRawPacket
        :return: number of bytes written in int
        """
        outData = packet.getbytearray()
        outData[-1] = 0  # Fix for some longer packet not being accepted by LPC
        written = self.connection.write(outData)
        return written
