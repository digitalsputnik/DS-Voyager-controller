artik_configuration = {
    'device': 'ARTIK',
    'lpcserial': '/dev/ttyAMA0',
    'dodcserial': '/dev/ttyAMA4',
    'mutepin': 'gpio94'
}
chip_configuration = {
    'device': 'CHIP',
    'lpcserial': '/dev/ttyS1',
    'dodcserial': '/dev/ttyS0',
    'mutepin': 'gpio128'
}

current_configuration = artik_configuration