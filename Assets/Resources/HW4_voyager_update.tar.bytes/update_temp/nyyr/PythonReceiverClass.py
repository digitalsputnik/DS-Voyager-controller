# V0.25

# Use from here
import AnimationPlayer
import json
import socket
import os.path
import serial
import time
import numpy as np
import threading
import colorsys
import sys
import traceback
import datetime
import logging

# emergency!
import uuid


vylogger = logging.getLogger('vylogger')


class ArtNetListener(threading.Thread):
    def __init__(self, scene, ColorCalibrator):
        self.ArtNetSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ArtNetSocket.bind(("", 6454))
        self.ArtNetSocket.settimeout(0.5)
        self.Scene = scene
        self.ColorCalibrator = ColorCalibrator
        self.Active = False
        self.running = True  # Set running false to stop while loop
        threading.Thread.__init__(self)

    def run(self):
        lastTime = time.time()
        rate = 1 / 25
        DMXOffset = 0
        lastDMXdata = []
        while self.running:
            if self.Active == False:
                time.sleep(1)
                continue

            try:
                ArtNetData, ArtNetControllerAddr = self.ArtNetSocket.recvfrom(1024)

                if self.Active == False:
                    continue

                # if time.time() - lastTime <= rate:
                #    continue

                lastTime = time.time()

                if (len(ArtNetData) > 0):
                    # NOTE: This is a strongly prototype implementation! Does not support layer structure
                    # Make sure it is ArtNet or sACN

                    if ArtNetData[0:8] != b'Art-Net' + 0x00.to_bytes(1, 'big'):
                        continue
                    # make sure right opcode
                    if ArtNetData[8:10] != 0x5000.to_bytes(2, 'little'):
                        continue
                    # make sure right version
                    if ArtNetData[10:12] != int(14).to_bytes(2, 'big'):
                        continue

                    DMXData = ArtNetData[18:]

                    if np.array_equal(DMXData, lastDMXdata):
                        continue
                    else:
                        lastDMXdata = DMXData

                    # Change stroke properties accordingly (loop through visible layer's strokes)
                    if len(self.Scene.Layers) <= 1:
                        continue

                    CurrentLayer = self.Scene.Layers[1].Strokes
                    StrokeStep = 18  # 3 color and 2 integer values
                    strokeIndex = 0
                    # Assign colors
                    # Looping strokes from top to bottom TODO: Check if stroke has been doubled?
                    for stroke in CurrentLayer:
                        if stroke.StrokeID == "BottomBlackStroke":
                            continue

                        if "DMX offset" in stroke.Properties:
                            DMXOffset = stroke.DMXOffset - 1  # stroke.Properties["DMX offset"][0] - 1

                        # if len(DMXData) < DMXOffset + StrokeStep:
                        #    break

                        if stroke.Animation == "DMX":
                            colorIndex = 0
                            StrokeColors = stroke.Colors

                            # Get universe
                            Universe = int.from_bytes(ArtNetData[14:16], 'little')
                            UniverseOffset = stroke.Universe  # stroke.Properties["Universe offset"][0]
                            UniverseDifference = Universe - UniverseOffset

                            # Check indices
                            # Start index
                            ColorIndexStart = max(int((UniverseDifference * 512 - DMXOffset) / 4), 0)
                            # End index calculation!
                            ColorIndexEnd = min(len(StrokeColors), ColorIndexStart + 127)

                            DefaultColor = stroke.Properties["Color1"]
                            DefaultRGB = colorsys.hsv_to_rgb(DefaultColor[3] / 360, DefaultColor[2] / 120,
                                                             DefaultColor[0] / 100)

                            if UniverseDifference < 0:
                                continue
                            elif ColorIndexStart > len(StrokeColors):
                                continue

                            if UniverseDifference > 0:
                                DMXOffset = 0

                            for ci in range(ColorIndexStart, ColorIndexEnd):
                                DMXindex = DMXOffset + colorIndex * 4
                                FinalITSH = np.array(StrokeColors[ci])

                                ArtNetColor = np.frombuffer(DMXData[DMXindex:DMXindex + 4], dtype=np.uint8)
                                colorIndex = colorIndex + 1
                                if len(ArtNetColor) < 4:
                                    continue

                                # Format picking!
                                if stroke.Properties["Format"][0] == 0:
                                    # ITSH
                                    FinalITSH[0] = ArtNetColor[0] * (100 / 255) or DefaultColor[0]
                                    FinalITSH[1] = ArtNetColor[1] * (8500 / 255) + 1500
                                    FinalITSH[2] = ArtNetColor[2] * (120 / 255) or DefaultColor[2]
                                    FinalITSH[3] = ArtNetColor[3] * (359 / 255) or DefaultColor[3]
                                else:
                                    # RGBT
                                    RGB = ArtNetColor[0:3] / 255
                                    HSV = colorsys.rgb_to_hsv(RGB[0] or DefaultRGB[0], RGB[1] or DefaultRGB[1],
                                                              RGB[2] or DefaultRGB[2])
                                    FinalITSH[0] = HSV[2] * 100
                                    FinalITSH[1] = ArtNetColor[3] * (8500 / 255) + 1500
                                    FinalITSH[2] = HSV[1] * 120
                                    FinalITSH[3] = HSV[0] * 359

                                if FinalITSH[1] == 1500:
                                    FinalITSH[1] = DefaultColor[1]

                                for i in range(0, len(ArtNetColor)):
                                    StrokeColors[ci][i] = FinalITSH[i]
                                # RGBWColor = self.ColorCalibrator.NormalizedITSHtoRGBW(FinalITSH)
                                # StrokeColors[ci] = RGBWColor.astype(np.uint8)

                            stroke.ChangeProperties(colors=StrokeColors, properties=stroke.Properties)

                            # else:
                            '''
                            #Other strokes are ignored!
                            # Check universe
                            #TODO: Redo universe settings -> Check if universe is in permitted list or not
                            if ArtNetData[14:16] != int(0).to_bytes(2, 'big'):
                                continue

                            #Assessing colors with transformation 
                            colorIndex = 0
                            StrokeColors = stroke.Colors

                            for ci in range(0, len(StrokeColors)):
                            #for color in StrokeColors:
                                DMXindex = DMXOffset + colorIndex*4
                                ArtNetColor = np.frombuffer(DMXData[DMXindex:DMXindex+4], dtype = np.uint8)/255
                                FinalITSH = self.ColorCalibrator.PreprocessITSHValue(stroke.Properties["Color" + str(ci+1)])
                                for i in range(0, len(ArtNetColor)):
                                    FinalITSH[i] = ArtNetColor[i] or FinalITSH[i]
                                RGBWColor = self.ColorCalibrator.NormalizedITSHtoRGBW(FinalITSH)
                                StrokeColors[ci] = RGBWColor.astype(np.uint8)
                                #color = RGBWColor.astype(np.uint8)
                                colorIndex = colorIndex + 1

                            #Assessing properties
                            DMXindex = DMXOffset + len(StrokeColors)*4
                            if stroke.Properties != None:
                                if ("Speed" in stroke.Properties and DMXData[DMXindex] > 0):
                                    stroke.Properties["Speed"][0] = DMXData[DMXindex]
                                if ("Width" in stroke.Properties and DMXData[DMXindex + 1] > 0):
                                    stroke.Properties["Width"][0] = DMXData[DMXindex + 1]
                            strokeIndex = strokeIndex + 1
                            stroke.ChangeProperties(colors = StrokeColors, properties = stroke.Properties)
                            '''
            except socket.timeout:  # expected to happen
                pass
            except Exception as e:
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

                vylogger.exception("[%s] [PythonReceiverClass] [ArtNetListener] Exception: %s" % (timestamp, str(e)))
                pass


class sACNListener(threading.Thread):
    def __init__(self, scene, ColorCalibrator):
        self.sACNSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sACNSocket.bind(("", 5568))
        self.sACNSocket.settimeout(0.5)
        self.Scene = scene
        self.ColorCalibrator = ColorCalibrator
        self.Active = False
        self.running = True  # Set running false to stop while loop
        threading.Thread.__init__(self)

    def run(self):
        lastTime = time.time()
        rate = 1 / 25
        DMXOffset = 0
        lastDMXdata = []
        while self.running:
            if self.Active == False:
                time.sleep(1)
                continue

            try:
                sACNData, sACNControllerAddr = self.sACNSocket.recvfrom(1024)

                if self.Active == False:
                    continue

                if time.time() - lastTime <= rate:
                    continue

                lastTime = time.time()

                if (len(sACNData) > 0):
                    # NOTE: This is a strongly prototype implementation! Does not support layer structure
                    # Make sure it is sACN
                    if sACNData[4:13] != b'ASC-E1.17':
                        continue

                    # Make sure it is data package
                    if sACNData[18:22] != bytes([0, 0, 0, 4]):
                        continue

                    # Check universe = 0
                    # if sACNData[113:115] != int(0).to_bytes(2, 'big'):
                    #    continue

                    DMXData = sACNData[126:]

                    if np.array_equal(DMXData, lastDMXdata):
                        continue
                    else:
                        lastDMXdata = DMXData

                    # Change stroke properties accordingly (loop through visible layer's strokes)
                    if len(self.Scene.Layers) <= 1:
                        continue

                    CurrentLayer = self.Scene.Layers[1].Strokes
                    StrokeStep = 18  # 3 color and 2 integer values
                    strokeIndex = 0
                    # Assign colors
                    # Looping strokes from top to bottom TODO: Check if stroke has been doubled?
                    for stroke in CurrentLayer:
                        if stroke.StrokeID == "BottomBlackStroke":
                            continue

                        if "DMX offset" in stroke.Properties:
                            DMXOffset = stroke.DMXOffset - 1  # stroke.Properties["DMX offset"][0] - 1

                        if stroke.Animation == "DMX":
                            colorIndex = 0
                            StrokeColors = stroke.Colors

                            # Get universe
                            Universe = int.from_bytes(sACNData[113:115], 'little')
                            UniverseOffset = stroke.Universe  # stroke.Properties["Universe offset"][0]
                            UniverseDifference = Universe - UniverseOffset

                            # Check indices
                            # Start index
                            ColorIndexStart = max(int((UniverseDifference * 512 - DMXOffset) / 4), 0)
                            # End index calculation!
                            ColorIndexEnd = min(len(StrokeColors), ColorIndexStart + 127)

                            DefaultColor = stroke.Properties["Color1"]
                            DefaultRGB = colorsys.hsv_to_rgb(DefaultColor[3] / 360, DefaultColor[2] / 120,
                                                             DefaultColor[0] / 100)

                            if UniverseDifference < 0:
                                continue
                            elif ColorIndexStart > len(StrokeColors):
                                continue

                            if UniverseDifference > 0:
                                DMXOffset = 0

                            for ci in range(ColorIndexStart, ColorIndexEnd):
                                DMXindex = DMXOffset + colorIndex * 4
                                FinalITSH = np.array(StrokeColors[ci])

                                ArtNetColor = np.frombuffer(DMXData[DMXindex:DMXindex + 4], dtype=np.uint8)
                                colorIndex = colorIndex + 1
                                if len(ArtNetColor) < 4:
                                    continue

                                # Format picking!
                                if stroke.Properties["Format"][0] == 0:
                                    # ITSH
                                    FinalITSH[0] = ArtNetColor[0] * (100 / 255) or DefaultColor[0]
                                    FinalITSH[1] = ArtNetColor[1] * (8500 / 255) + 1500
                                    FinalITSH[2] = ArtNetColor[2] * (120 / 255) or DefaultColor[2]
                                    FinalITSH[3] = ArtNetColor[3] * (359 / 255) or DefaultColor[3]
                                else:
                                    # RGBT
                                    RGB = ArtNetColor[0:3] / 255
                                    HSV = colorsys.rgb_to_hsv(RGB[0] or DefaultRGB[0], RGB[1] or DefaultRGB[1],
                                                              RGB[2] or DefaultRGB[2])
                                    FinalITSH[0] = HSV[2] * 100
                                    FinalITSH[1] = ArtNetColor[3] * (8500 / 255) + 1500
                                    FinalITSH[2] = HSV[1] * 120
                                    FinalITSH[3] = HSV[0] * 359

                                if FinalITSH[1] == 1500:
                                    FinalITSH[1] = DefaultColor[1]

                                for i in range(0, len(ArtNetColor)):
                                    StrokeColors[ci][i] = FinalITSH[i]
                                # RGBWColor = self.ColorCalibrator.NormalizedITSHtoRGBW(FinalITSH)
                                # StrokeColors[ci] = RGBWColor.astype(np.uint8)

                            stroke.ChangeProperties(colors=StrokeColors, properties=stroke.Properties)
            except socket.timeout:  # expected to happen
                pass
            except Exception as e:
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
                vylogger.exception("[%s] [PythonReceiverClass] [sACNListener] Exception: %s" % (timestamp, str(e)))
                pass


class ColorCalibration:
    def __init__(self, path=""):
        TemperatureCalibrationTable = np.genfromtxt(path + "TemperatureCalibration.csv", skip_header=1, delimiter=',')
        HueCalibrationTable = np.genfromtxt(path + "HueCalibration.csv", skip_header=1, delimiter=',')
        IntensityCalibrationTable = np.genfromtxt(path + "IntensityCalibration.csv", skip_header=1, delimiter=',')

        # Transform data
        self.TemperatureNodes = TemperatureCalibrationTable.transpose()[0]
        self.TemperatureNodesFull = TemperatureCalibrationTable.transpose()[0] * 8500 + 1500
        self.TemperatureRGBW = TemperatureCalibrationTable.transpose()[1:]
        self.HueNodes = HueCalibrationTable.transpose()[0]
        self.HueNodesFull = HueCalibrationTable.transpose()[0] * 360
        self.HueRGBW = HueCalibrationTable.transpose()[1:]
        self.IntensityNodes = IntensityCalibrationTable.transpose()[0]
        self.IntensityNodesFull = IntensityCalibrationTable.transpose()[0] * 100
        self.IntensityValues = IntensityCalibrationTable.transpose()[1]
        self.GammaCorrectionLookup = {}
        self.GenerateGammaCorrectionLookup()
        self.TemperatureRGBWlut = {}
        self.HueRGBWlut = {}
        self.Ilut = {}
        self.Slut = {}
        self.GenerateITSHLookupTables()

    def GenerateITSHLookupTables(self):
        # Temperature
        for T in range(1500, 10001):
            RGBW = np.zeros(4).astype(np.uint8)
            for i in range(0, 4):
                RGBW[i] = np.interp(T, self.TemperatureNodesFull, self.TemperatureRGBW[i])
            self.TemperatureRGBWlut[T] = RGBW

        # Hue
        for H in range(0, 360):
            RGBW = np.zeros(4).astype(np.uint8)
            for i in range(0, 4):
                RGBW[i] = np.interp(H, self.HueNodesFull, self.HueRGBW[i])
            self.HueRGBWlut[H] = RGBW

        # Intensity and Saturation
        for S in range(0, 121):
            self.Slut[S] = (np.arange(256) * (S / 120)).astype(np.uint8)

        for I in range(0, 101):
            self.Ilut[I] = (np.arange(256) * (I / 100)).astype(np.uint8)

    def PreprocessITSHValue(self, rawITSH=np.zeros_like(4)):
        '''
        Transforms raw ITSH value to range 0.0 to 1.0
        ITSH - 4-element numpy array
        '''
        ITSHout = np.zeros(4)
        ITSHout[0] = rawITSH[0] / 100.0
        ITSHout[1] = (rawITSH[1] - 1500.0) / 8500.0  # From 1 500-10 000 to 0-1
        ITSHout[2] = rawITSH[2] / 100.0  # or 120?
        ITSHout[3] = rawITSH[3] / 360.0
        # Foolproofing if any of the values are out of range
        minThreshold = np.zeros(4)
        maxThreshold = np.ones(4)
        ITSHout = np.minimum(np.maximum(ITSHout, minThreshold), maxThreshold)
        return ITSHout

    def ITSHtoRGBWFull(self, ITSH=np.zeros(4).astype(np.uint8)):
        # RGBW = np.zeros(4).astype(np.uint8)
        # for i in range(0,4):
        #    RGBW[i] = (np.interp(ITSH[1],self.TemperatureNodesFull,self.TemperatureRGBW[i])*(1.0 - ITSH[2]/100) + np.interp(ITSH[3],self.HueNodesFull,self.HueRGBW[i])*ITSH[2])*np.interp(ITSH[0],self.IntensityNodesFull,self.IntensityValues)
        RGBW = self.Ilut[ITSH[0]][
            (self.Slut[120 - ITSH[2]][self.TemperatureRGBWlut[ITSH[1]]] + self.Slut[ITSH[2]][self.HueRGBWlut[ITSH[3]]])]
        return RGBW

    def ITSHtoRGBW(self, ITSH=np.zeros(4)):
        '''
        Transforms ITSH value to RGBW
        ITSH - 4-element numpy array
        '''
        ProcessedITSH = self.PreprocessITSHValue(ITSH)
        RGBW = self.NormalizedITSHtoRGBW(ProcessedITSH)
        return RGBW

    def NormalizedITSHtoRGBW(self, ITSH=np.zeros(4)):
        '''
        Transforms ITSH value to RGBW
        ITSH - 4-element numpy array in range 0.0 to 1.0
        '''
        RGBW = np.zeros(4)
        for i in range(0, 4):
            RGBW[i] = (np.interp(ITSH[1], self.TemperatureNodes, self.TemperatureRGBW[i]) * (1.0 - ITSH[2]) + np.interp(
                ITSH[3], self.HueNodes, self.HueRGBW[i]) * ITSH[2]) * np.interp(ITSH[0], self.IntensityNodes,
                                                                                self.IntensityValues)
        return RGBW

    def GenerateGammaCorrectionLookup(self):
        for g in range(10, 41):
            self.GammaCorrectionLookup[g] = (np.power(np.arange(256) / 255, 10 / g) * 255).astype(np.uint8)


class PythonReceiver(threading.Thread):
    def __init__(self, LampOutput, LampPixelCount):
        self.LampPixelCount = LampPixelCount
        self.LampLEDOutput = LampOutput

        # Retrieve lamp serial
        self.LampMac = self.ReadFile("/mnt/data/serial.txt").strip()
        if self.LampMac == "":
            # Rev2
            self.LampMac = os.popen(
                "ip addr show wlan1 | sed -n 2p | tr -d : | cut -d ' ' -f 6 | cut -c 7-").readline().strip()

        # Set up stroke receival from UI
        self.Sock = self.CreateSocket()
        self.ReceiveBufferSize = 60000

        # Saving data to lamp
        self.AnimationPath = ""
        self.StrokesFilename = ""
        self.SetupPaths()

        # Color calibration
        self.ColorCalibrator = ColorCalibration(self.AnimationPath)

        # Lamp scene initialization
        # TODO: Overview output sending!
        self.LampScene = AnimationPlayer.Scene(frameDuration=1 / 200.0,
                                               outputs=[AnimationPlayer.OutputToVoyager(self.LampLEDOutput)],
                                               lampPixelCount=LampPixelCount,
                                               colorCalibrator=self.ColorCalibrator)  # , AnimationPlayer.OutputToController()])

        # Create bottom black stroke
        bottomLayer = AnimationPlayer.Layer("BottomBlack", self.LampScene)
        self.GenerateBottomBlack(bottomLayer)

        # Get previous strokes or generate white stroke if missing
        self.PreviousStrokesJSON = self.ReadFile(self.StrokesFilename)
        if self.PreviousStrokesJSON == "":
            self.PreviousStrokesJSON = self.InitializeBaseWhiteStroke()

        # Registered UI devices
        self.RegisteredDevices = []

        # Detection timeout
        self.DetectionTime = 0
        self.DetectionTimeoutInSeconds = 5

        # Controller output timeout
        self.ControllerTimes = {}
        self.ControllerTimeoutInSeconds = 60

        # ArtNet and sACN
        self.ANetListener = ArtNetListener(self.LampScene, self.ColorCalibrator)
        self.ANetListener.start()
        self.ACNListener = sACNListener(self.LampScene, self.ColorCalibrator)
        self.ACNListener.start()

        threading.Thread.__init__(self)

        self.running = True  # Set running false to stop while loop
        self.Active = True

    def __del__(self):
        self.ANetListener.running = False
        self.ACNListener.running = False
        self.LampScene.running = False

        self.ANetListener.join()
        self.ACNListener.join()
        self.LampScene.join()

    def activate(self):
        self.Active = True
        self.ANetListener.Active = True
        self.ACNListener.Active = True
        self.LampScene.Active = True

    def deactivate(self):
        self.Active = False
        self.ANetListener.Active = False
        self.ACNListener.Active = False
        self.LampScene.Active = False


    def CreateSocket(self):
        '''
        Creates socket for stroke receival
        '''
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.5)
        port = 30001
        host = ""  # Listen to all IPs
        sock.bind((host, port))
        return sock

    def ReadFile(self, filename):
        '''
        Reads file contents and returns them as a string
        '''
        FileContents = ""
        if os.path.isfile(filename):
            file = open(filename, "r")
            FileContents = file.read()
            file.close()
        return FileContents

    def SetupPaths(self):
        '''
        Sets up paths to animation folder and stroke data file
        '''
        if os.path.isdir("/mnt/data/animation"):
            # Rev3
            self.AnimationPath = "/mnt/data/animation/"
            self.StrokesFilename = "/mnt/data/animation/strokedata.dat"
        else:
            # Rev2
            self.AnimationPath = "/media/animation/"
            self.StrokesFilename = "/media/animation/strokedata.dat"

    def GeneratePixelDictionary(self):
        '''
        Generates pixel dictionary for json and animation player
        '''
        bottomPixelDict = {}
        for x in range(0, self.LampPixelCount):
            bottomPixelDict[x] = x
        bottomDict = {}
        bottomDict[self.LampMac] = bottomPixelDict
        return bottomDict

    def InitializeBaseWhiteStroke(self):
        '''
        Creates white stroke JSON
        '''
        whiteColorDict = {}
        whiteColorDict['TimeStamp'] = 1.0
        StrokeDict = {'Animation': 'Single Color', 'Colors': [[42, 76, 81, 85]], 'CreationTimestamp': 0.0,
                      'Duration': 2000.0, 'PixelQueueToControlledPixel': self.GeneratePixelDictionary(),
                      'Properties': {'Color1': [50, 5600, 0, 0]}, 'StartTime': 0.0, 'StrokeID': str(uuid.uuid4()),
                      'TimeStamp': 1.0, 'TotalPixelCount': self.LampPixelCount}
        whiteColorDict['Layers'] = [{'LayerActive': True, 'LayerID': 'Layer', 'Strokes': [StrokeDict]}]
        BaseWhiteStrokeJSON = json.dumps(whiteColorDict)
        return BaseWhiteStrokeJSON

    def GenerateBottomBlack(self, bottomLayer):
        '''
        Generates bottom black stroke so if strokes on top are deleted, lamp will be black
        '''
        bottomDict = self.GeneratePixelDictionary()

        bottomStroke = AnimationPlayer.Stroke(bottomLayer, "BottomBlackStroke", pixelDictionary=bottomDict,
                                              totalPixelCount=len(bottomDict), colors=[[0, 0, 0, 0], [0, 0, 0, 0]],
                                              LampMac=self.LampMac)

    # Detection control
    def CheckDetectionOff(self):
        # Detection timeout
        if self.DetectionTime > 0:
            if time.time() - self.DetectionTime >= self.DetectionTimeoutInSeconds:
                self.LampScene.SetSceneActive(True)
                self.DetectionTime = 0

    def run(self):
        while self.running:
            UDPData = ""
            DecodedMessage = ""
            addr = ()

            if self.Active == False:
                time.sleep(1)
                continue

            if self.PreviousStrokesJSON == "":
                try:
                    UDPData, addr = self.Sock.recvfrom(self.ReceiveBufferSize)
                except socket.timeout as e:
                    pass

            try:
                if (len(UDPData) > 0 or self.PreviousStrokesJSON != ""):
                    # Decode data
                    if self.PreviousStrokesJSON != "":
                        DecodedMessage = self.PreviousStrokesJSON
                        self.PreviousStrokesJSON = ""
                    else:
                        DecodedMessage = UDPData.decode("utf-8")
                    # Deserialize json data
                    jsonDict = json.loads(DecodedMessage)

                    if 'ArtNetMode' in jsonDict:
                        self.ANetListener.Active = jsonDict['ArtNetMode']

                    if 'sACNMode' in jsonDict:
                        self.ACNListener.Active = jsonDict['sACNMode']

                    if 'VideoStream' in jsonDict:
                        self.LampScene.Layers[1].VideoStream = np.array(jsonDict['VideoStream'])

                    # Determine the type of the json message
                    if 'Layers' in jsonDict:
                        if 'TimeStamp' in jsonDict:
                            if jsonDict['TimeStamp'] <= self.LampScene.TimeStamp:
                                continue
                            else:
                                self.LampScene.TimeStamp = jsonDict['TimeStamp']

                        useMessage = False
                        for controllerLayer in jsonDict['Layers']:
                            Layer = next((layer for layer in self.LampScene.Layers if
                                          layer.LayerID == controllerLayer['LayerID']), False)
                            if Layer:
                                VisibleStrokeIDs = []
                                # TODO: Sort strokes by creation timestamp!
                                controllerLayer['Strokes'].sort(key=lambda s: s["CreationTimestamp"])
                                for controllerStroke in controllerLayer['Strokes']:
                                    if controllerStroke['PixelQueueToControlledPixel'] == None:
                                        continue

                                    if self.LampMac in controllerStroke['PixelQueueToControlledPixel']:
                                        useMessage = True

                                    VisibleStrokeIDs.append(controllerStroke['StrokeID'])

                                    if not Layer.ChangeStrokeByID(controllerStroke['StrokeID'],
                                                                  startTime=controllerStroke['StartTime'],
                                                                  pixelDictionary=controllerStroke[
                                                                      'PixelQueueToControlledPixel'],
                                                                  totalPixelCount=controllerStroke['TotalPixelCount'],
                                                                  colors=controllerStroke['Colors'],
                                                                  properties=controllerStroke['Properties'],
                                                                  animation=controllerStroke['Animation'],
                                                                  duration=controllerStroke['Duration'],
                                                                  timeStamp=controllerStroke['TimeStamp'],
                                                                  lampMac=self.LampMac,
                                                                  Universe=controllerStroke['Universe'],
                                                                  DMXOffset=controllerStroke['DMXOffset']):
                                        # print("Adding new stroke!")
                                        NewStroke = AnimationPlayer.Stroke(Layer, controllerStroke['StrokeID'],
                                                                           controllerStroke['TimeStamp'],
                                                                           controllerStroke['StartTime'],
                                                                           controllerStroke[
                                                                               'PixelQueueToControlledPixel'],
                                                                           controllerStroke['TotalPixelCount'],
                                                                           controllerStroke['Colors'],
                                                                           controllerStroke['Properties'],
                                                                           controllerStroke['Animation'],
                                                                           duration=controllerStroke['Duration'],
                                                                           LampMac=self.LampMac,
                                                                           Universe=controllerStroke['Universe'],
                                                                           DMXOffset=controllerStroke['DMXOffset'])
                                Layer.RemoveInvisibleStrokes(VisibleStrokeIDs)
                            else:
                                # Create layer and its strokes
                                NewLayer = AnimationPlayer.Layer(controllerLayer['LayerID'], self.LampScene,
                                                                 layerActive=controllerLayer['LayerActive'])
                                controllerLayer['Strokes'].sort(key=lambda s: s["CreationTimestamp"])
                                for controllerStroke in controllerLayer['Strokes']:
                                    if self.LampMac in controllerStroke['PixelQueueToControlledPixel']:
                                        NewStroke = AnimationPlayer.Stroke(NewLayer, controllerStroke['StrokeID'],
                                                                           controllerStroke['TimeStamp'],
                                                                           controllerStroke['StartTime'],
                                                                           controllerStroke[
                                                                               'PixelQueueToControlledPixel'],
                                                                           controllerStroke['TotalPixelCount'],
                                                                           controllerStroke['Colors'],
                                                                           controllerStroke['Properties'],
                                                                           controllerStroke['Animation'],
                                                                           duration=controllerStroke['Duration'],
                                                                           LampMac=self.LampMac,
                                                                           Universe=controllerStroke['Universe'],
                                                                           DMXOffset=controllerStroke['DMXOffset'])
                        # Save to file
                        if useMessage:
                            file = open(self.StrokesFilename, "w")
                            file.write(DecodedMessage)
                            file.close()

                        # Send structure to lamps
                        for output in self.LampScene.Outputs:
                            if output is AnimationPlayer.OutputToController:
                                if addr != output.Address:
                                    self.Sock.sendto(UDPData, output.Address)

                    elif 'DeleteLayerID' in jsonDict:
                        print("TODO: Delete layer with corresponding ID")
                    elif 'PollLayers' in jsonDict:
                        # Send layers back as JSON
                        # TODO: Better handling of no message
                        try:
                            savedStrokes = self.ReadFile(self.StrokesFilename)
                            # print(savedStrokes)
                            if savedStrokes != "":
                                addrL = list(addr)
                                addrL[1] = 30001
                                # print(tuple(addrL))
                                EncodedMessage = savedStrokes.encode()
                                self.Sock.sendto(EncodedMessage, tuple(addrL))
                        except:
                            pass

                    elif 'DetectionMode' in jsonDict:
                        self.LampScene.SetSceneActive(not jsonDict['DetectionMode'])
                        if jsonDict['DetectionMode'] == True:
                            self.DetectionTime = time.time()
                            t = threading.Timer(self.DetectionTimeoutInSeconds, self.CheckDetectionOff)
                            t.start()
                        else:
                            self.DetectionTime = 0
                    elif 'RegisterDevice' in jsonDict:
                        lIP = list(addr)[0]
                        if jsonDict['RegisterDevice'] and not (lIP in self.RegisteredDevices):
                            # print("Registering!")
                            # print(RegisteredDevices)
                            self.LampScene.Outputs.append(AnimationPlayer.OutputToController(addr, 10))
                            self.RegisteredDevices.append(lIP)
                            self.ControllerTimes[lIP] = time.time()
                    # Start scene if not active
                    if not self.LampScene.isAlive():
                        self.LampScene.start()

            except KeyError as error:
                pass
            except Exception as e:
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
                vylogger.exception("[%s] [PythonReceiverClass] [PythonReceiver] Exception: %s" % (timestamp, str(e)))
                pass