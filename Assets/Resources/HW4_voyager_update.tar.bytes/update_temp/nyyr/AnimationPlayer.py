﻿#V0.25

import threading
import time
from enum import Enum
import abc
import random
import numpy as np
import sys
import traceback
import logging
import datetime

#Voyager specific - outputs
import serial
import socket

vylogger = logging.getLogger('vylogger')

class PlayMode(Enum):
    Pause = 0
    Play = 1
    Stop = 2

class RepeatMode(Enum):
    Hold = 0
    Loop = 1
    

class Pixel:
    '''Smallest controllable unit
    QueueNumber - Pixel number in the stroke
    PixelNumber - Pixel number on the lamp
    PixeColor - Color (ITSH or RGBW) to be set to pixel
    '''
    def __init__(self, QueueNumber, PixelNumber, PixelColor = None):
        self.QueueNumber = QueueNumber
        self.PixelNumber = PixelNumber
        self.PixelColor = np.array(PixelColor)

#Hold only one scene class in lamp!
#TODO: Should scene have an ID as well?
class Scene(threading.Thread):
    '''Scene is the broadest view, which consists of layers
    Only one scene is stored within the lamp
    layers - Layers in the scene
    outputs - Outputs (lamp, controller) for colors
    frameDuration - Frame duration in seconds (default is 1/60 s)
    '''
    def __init__(self, layers = [], outputs = [], frameDuration = 1.0/30.0, active = True, lampPixelCount = 0, timestamp = 0.0, colorCalibrator = None):
        self.Layers = layers
        self.CurrentSceneFrame = {}
        self.Time = 0.0
        self.Outputs = outputs
        self.FrameDuration = frameDuration
        self.SceneActive = active
        self.LampPixelCount = lampPixelCount
        self.TimeStamp = timestamp
        self.ColorCalibrator = colorCalibrator
        self.running = True  # Set running false to stop while loop
        self.Active = True
        threading.Thread.__init__(self)
    
    def SetSceneActive(self, active):
        self.SceneActive = active

    def SendOutputs(self):
        for output in self.Outputs:
            output.Send(self.CurrentSceneFrame, self.LampPixelCount)

    def UpdateLayers(self):
        for layer in self.Layers:
            if layer.LayerActive:
                layer.Update()
                self.CurrentSceneFrame.update(layer.CurrentLayerFrame)

    def Update(self):
        if len(self.Layers) > 0:
            self.UpdateLayers()
        if len(self.Outputs) > 0:
            self.SendOutputs()
    
    def ChangeLayerByID(self, layerID, scene = None, strokes = None, layerActive = None):
        '''Changes layer properties by ID'''
        for layer in self.Layers:
            if layer.LayerID == layerID:
                layer.ChangeLayer(scene, strokes, layerActive)

    #TODO: Remove?
    def ChangeStrokeByID(self, timeStamp = 0, pixelDictionary = {}, totalPixelCount = 0, colors = None, properties = None, animation = "", playMode = None, repeatMode = None, duration = 0.0, lampMac = ""):
        '''Finds and changes stroke by its StrokeID'''
        for layer in self.Layers:
            if layer.ChangeStrokeByID(strokeID, timeStamp, pixelDictionary, totalPixelCount, colors, properties, animation, playMode, repeatMode, duration, lampMac):
                break

    def AddOrChangeLayer(self, layerID, scene = None, strokes = None, layerActive = None):
        if any(layer.LayerID == newLayer.LayerID for layer in self.Layers):
            #if exists, change
            self.ChangeLayerByID(layerID, scene, strokes, layerActive)
        else:
            #Add layer
            self.Layers.append(Layer(layerID, self, strokes, layerActive))

    def DeleteLayerByID(self, LayerID):
        '''Deletes layer by its ID'''
        for layer in self.Layers:
            if layer.LayerID == LayerID:
                self.Layers.remove(layer)

    def run(self):
        #TODO: Better scheduling!
        lastTimePoint = time.time()
        while self.running:

            if self.Active == False:
                time.sleep(1)
                continue

            try:
                currentTime = time.time()
                timePassed = currentTime - lastTimePoint
                isNewFrame = abs(timePassed) > self.FrameDuration
                #if timePassed/self.FrameDuration >= 2.0:
                    #print(timePassed/self.FrameDuration)
                if isNewFrame and self.SceneActive:
                    lastTimePoint = currentTime
                    self.Update()
            except Exception as e:
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
                vylogger.exception("[%s] [AnimationPlayer] [Scene] Exception: %s" % (timestamp, str(e)))
                pass
            

class Layer:
    '''Layer consists of Strokes
    LayerID - Unique layerID to identify layer
    '''
    def __init__(self, layerID = "", scene = None, strokes = [], layerActive = True):
        self.LayerID = layerID
        self.Scene = scene
        self.Scene.Layers.append(self)
        self.Strokes = strokes
        self.Time = time.time()
        self.LayerActive = layerActive
        #TODO: Numpy
        self.CurrentLayerFrame = {}
        self.VideoStream = np.repeat([[0,0,0,0]],scene.LampPixelCount,axis = 0)

    def ChangeLayer(self, scene, strokes, layerActive):
        self.Scene = scene or self.Scene
        self.Strokes = strokes or self.Strokes
        if layerActive != None:
            self.LayerActive = layerActive

    def AddStroke(self, stroke):
        '''Adds stroke to layer'''
        self.Strokes.append(stroke)

    def ChangeStrokeByID(self, strokeID, timeStamp = 0, startTime = 0, pixelDictionary = {}, totalPixelCount = 0, colors = None, properties = None, animation = "", playMode = None, repeatMode = None, duration = 0.0, lampMac = "", Universe = 0, DMXOffset = 0):
        '''Finds and changes stroke by its StrokeID'''
        for stroke in self.Strokes:
            if stroke.StrokeID == strokeID:
                stroke.ChangeStroke(timeStamp, startTime, pixelDictionary, totalPixelCount, colors, properties, animation, playMode, repeatMode, duration, lampMac, Universe, DMXOffset)
                return True

    def RemoveInvisibleStrokes(self, VisibleStrokeIDs):
        for stroke in self.Strokes:
            if not stroke.StrokeID in VisibleStrokeIDs:
                self.Strokes.remove(stroke)

    def Update(self):
        '''Layer update is called upon each frame by scene'''
        #Update all strokes and get Current frame!
        #Since all strokes are rendered in the order they have been created, 
        for stroke in self.Strokes:
            stroke.Update() #Render all strokes in frame
            #Update current frame
            #TODO: Numpy!
            for pixel in stroke.ControlledPixels:
                self.CurrentLayerFrame[pixel.PixelNumber] = pixel.PixelColor

class Stroke:
    def __init__(self, layer = None, strokeID = "", timeStamp = time.time(), startTime = time.time(), pixelDictionary = {}, totalPixelCount = 0, colors = None, properties = None, animation = "", playMode = PlayMode.Play, repeatMode = RepeatMode.Loop, duration = 0.0, LampMac = "", Universe = 0, DMXOffset = 0):
        '''Stroke consists of pixels, with the same shader
        strokeID - Unique strokeID to identify stroke
        timeStamp - UTC timestamp of stroke alteration to 
        pixels - dictionary int int, where key is queue number and value is the pixel number,
        colors - list of colors as list(int)
        properties - dictionary string, object, where shader properties are defined
        playmode - PlayMode.Play/Pause/Stop
        repeatmode = RepeatMode.Loop/Hold
        '''

        #Identification
        self.LampMac = LampMac
        self.StrokeID = strokeID
        self.Layer = layer
        self.TimeStamp = timeStamp 
        #Add stroke to corresponding layer
        self.Layer.AddStroke(self)

        #Playmodes
        self.PlayMode = playMode
        self.RepeatMode = repeatMode

        #Time variables
        self.StartTime = startTime
        self.DeltaTime = 0.0
        self.LastTime = time.time()
        self.Time = time.time() - self.StartTime #Time of animation
        self.Duration = duration
        self.UpdateStationary = True #NOTE: Temporary fix for gradient rendering

        #Animation
        self.Animation = animation

        #Stroke properties
        self.Properties = properties
        self.Colors = np.array(colors)
        #Initialize a bitmap(time, pixels, color)
        self.StrokeBitmap = np.zeros((2,self.Layer.Scene.LampPixelCount,4))

        #Pixels
        self.TotalPixelCount = totalPixelCount #max(totalPixelCount, len(pixelDictionary.keys())) #NOTE: This is not the most foolproof method for determining the count!
        self.PixelDictionary = pixelDictionary
        self.ControlledPixels = []
        self.SetPixels(pixelDictionary)

        #DMX
        self.Universe = Universe
        self.DMXOffset = DMXOffset

    def SetTime(self, StartTime = 0.0):
        '''Sets stroke relative time'''
        self.StartTime = StartTime
        self.Time = time.time() - self.StartTime

    def SetPixels(self, pixelDictionary = {}):
        '''Adds pixels to stroke'''
        if self.LampMac in pixelDictionary:
            CurrentLampPixelDictionary = pixelDictionary[self.LampMac]
            controlledPixels = []
            for pixelQueueNumber, pixelNumber in CurrentLampPixelDictionary.items():
                controlledPixels.append(Pixel(int(pixelQueueNumber), int(pixelNumber)))
            self.ControlledPixels = controlledPixels

    def ChangeStroke(self, timeStamp = 0, startTime = 0, pixelDictionary = {}, totalPixelCount = 0, colors = None, properties = None, animation = "", playMode = None, repeatMode = None, duration = 0.0, lampMac = "", Universe = 0, DMXOffset = 0):
        '''Changes stroke pixels, colors, properties or animation'''
        if timeStamp > self.TimeStamp:
            self.SetTime(startTime or self.StartTime)
            #self.ControlledPixels = []
            self.SetPixels(pixelDictionary or self.PixelDictionary)
            self.TotalPixelCount = totalPixelCount or self.TotalPixelCount
            self.Properties = properties or self.Properties
            self.Colors = np.array(colors or self.Colors)
            self.Duration = duration or self.Duration
            self.Animation = animation or self.Animation
            self.PlayMode = playMode or self.PlayMode
            self.RepeatMode = repeatMode or self.RepeatMode
            self.LampMac = lampMac or self.LampMac
            self.UpdateStationary = True
            #DMX
            self.Universe = Universe
            self.DMXOffset = DMXOffset

    def ChangeProperties(self, colors = None, properties = None):
        if type(colors) != None:
            self.Colors = colors
        if type(properties) != None:
            self.Properties = properties
        self.UpdateStationary = True

    def Update(self):
        '''Update defines what happens on each frame'''
        if self.PlayMode == PlayMode.Stop :
            return

        currentTime = time.time()
        self.Time = currentTime - self.StartTime

        self.DeltaTime = currentTime - self.LastTime
        self.LastTime = currentTime
        self.UpdatePixels()

    def Play(self):
        #From Stop
        if self.PlayMode == PlayMode.Stop:
            self.SetTime(0.0)

        #From Pause
        if self.PlayMode == PlayMode.Pause:
            self.SetTime(self.Time)

        self.PlayMode = PlayMode.Play

    def Pause(self):
        self.PlayMode = PlayMode.Pause

    def Stop(self):
        self.PlayMode = PlayMode.Stop

    def UpdatePixels(self):
        try:
            flicker = random.randint(0,1)

            #TODO: Safely change bitmap!
            if self.UpdateStationary:
                # Calculate colors!
                if self.Animation != "DMX" and self.Animation != "Video Stream" and self.Properties != None:
                    c = 1
                    while("Color" + str(c) in self.Properties):
                        self.Colors[c - 1] = self.Layer.Scene.ColorCalibrator.ITSHtoRGBWFull(self.Properties["Color" + str(c)])
                        c += 1

                # Calculate bitmaps!
                if self.Animation == "Chaser Grad1":
                    self.StrokeBitmap = np.zeros((2,max(self.TotalPixelCount,self.Properties["Width"][0]),4))
                    # Chaser
                    for p in range(0,self.Properties["Width"][0]):
                        percent = float(p)/float(self.Properties["Width"][0])
                        invPercent = 1 - percent
                        for i in range(0, len(self.Colors[0])):
                            self.StrokeBitmap[1][p][i] = int(percent*self.Colors[0][i] + invPercent*self.Colors[1][i])
                    # Background
                    for pixel in self.ControlledPixels:
                        percent = float(pixel.QueueNumber)/float(self.TotalPixelCount)
                        invPercent = 1 - percent
                        for i in range(0, len(self.Colors[0])):
                            self.StrokeBitmap[0][pixel.QueueNumber][i] = int(percent*self.Colors[2][i] + invPercent*self.Colors[3][i])
                elif self.Animation == "Chaser Grad2":
                    self.StrokeBitmap = np.zeros((2,max(self.TotalPixelCount,self.Properties["Width"][0]),4))
                    # Background
                    for pixel in self.ControlledPixels:
                        percent = float(pixel.QueueNumber)/float(self.TotalPixelCount)
                        invPercent = 1 - percent
                        for i in range(0, len(self.Colors[0])):
                            self.StrokeBitmap[1][pixel.QueueNumber][i] = int(percent*self.Colors[0][i] + invPercent*self.Colors[1][i])
                            self.StrokeBitmap[0][pixel.QueueNumber][i] = int(percent*self.Colors[2][i] + invPercent*self.Colors[3][i])
                elif self.Animation == "Fire":
                    col = []
                    for i in range(0, len(self.Colors[0])):
                        col.append(np.random.randint(min(self.Colors[0][i],self.Colors[1][i]),max(self.Colors[0][i],self.Colors[1][i]) + 1,(200,self.TotalPixelCount, 1)))
                    self.StrokeBitmap = np.concatenate((col), axis = 2)
                elif self.Animation == "Gradient":
                    self.StrokeBitmap = np.zeros((1,self.TotalPixelCount,4))
                    for pixel in self.ControlledPixels:
                        percent = float(pixel.QueueNumber)/float(self.TotalPixelCount)
                        invPercent = 1 - percent
                        for i in range(0, len(self.Colors[0])):
                            self.StrokeBitmap[0][pixel.QueueNumber][i] = int(percent*self.Colors[0][i] + invPercent*self.Colors[1][i])
                elif self.Animation == "DMX":
                    self.StrokeBitmap = np.zeros((1,self.TotalPixelCount,4))
                    #if self.Properties["Unit size"] == "All" or self.Properties["Unit size"] == "Lamp":
                    #    for pixel in self.ControlledPixels:
                    #        if int(self.Properties["Format"][0]) == 0:
                    #            self.StrokeBitmap[0][pixel.QueueNumber] = self.Layer.Scene.ColorCalibrator.ITSHtoRGBWFull(self.Colors[0])
                    #        else:
                    #            self.StrokeBitmap[0][pixel.QueueNumber] = self.Colors[0]
                    #else:
                    UnitSize = int(self.Properties["Unit size"][0])

                    CalibratedColors = []
                    InputColors = np.array(self.Colors)
                    for color in InputColors:
                        CalibratedColors.append(self.Layer.Scene.ColorCalibrator.ITSHtoRGBWFull(color))
                    CalibratedColors = np.array(CalibratedColors)

                    if UnitSize == -1: #Lamp
                        DivSize = max(1, len(self.ControlledPixels)/self.Properties["Division"][0])
                        ColorIndex = 0
                        Index = 0
                        ColorIndices = (np.arange(len(self.ControlledPixels))/DivSize).astype(np.uint8)
                        for pixel in self.ControlledPixels:
                            self.StrokeBitmap[0][pixel.QueueNumber] = CalibratedColors[ColorIndices[Index]]
                            Index += 1
                    elif UnitSize == 0: #Stroke
                        DivSize = max(1, self.TotalPixelCount/self.Properties["Division"][0])
                        ColorIndices = (np.arange(self.TotalPixelCount)/DivSize).astype(np.uint8)
                        Index = 0
                        for pixel in self.ControlledPixels:
                            #ColorIndex = int(pixel.QueueNumber/DivSize)
                            self.StrokeBitmap[0][pixel.QueueNumber] = CalibratedColors[ColorIndices[pixel.QueueNumber]]
                            Index += 1
                    else:
                        for pixel in self.ControlledPixels:
                            self.StrokeBitmap[0][pixel.QueueNumber] = self.Layer.Scene.ColorCalibrator.ITSHtoRGBWFull(self.Colors[int(pixel.QueueNumber/UnitSize)])

            for pixel in self.ControlledPixels:
                    #TODO: Better implementation on animation
                    if self.Animation == "Chaser":
                        #chaserQueueNumber = int(self.Time * float(self.Properties["Speed"][0])) % (self.TotalPixelCount + self.Properties["Width"][0] - 1)
                        chaserQueueNumber = int(((self.Time + (self.Properties["Time offset"][0]/1000)) * float(self.Properties["Speed"][0])) % (self.TotalPixelCount + self.Properties["Width"][0] - 1 + (self.Properties["Hold"][0]/1000)*self.Properties["Speed"][0]))
                        if pixel.QueueNumber > chaserQueueNumber - self.Properties["Width"][0] and pixel.QueueNumber <= chaserQueueNumber:
                            pixel.PixelColor = self.Colors[0]
                        else:
                            pixel.PixelColor = self.Colors[1]

                    elif self.Animation == "Fire":
                        pixel.PixelColor = self.StrokeBitmap[int(self.Time * float(self.Properties["Speed"][0]) % 200)][pixel.QueueNumber]

                    elif self.Animation == "Gradient":
                        if self.TotalPixelCount > 0:
                            pixel.PixelColor = self.StrokeBitmap[0][pixel.QueueNumber]

                    elif self.Animation == "Chaser Grad1":
                        #chaserQueueNumber = int(self.Time * float(self.Properties["Speed"][0])) % (self.TotalPixelCount + self.Properties["Width"][0] - 1)
                        chaserQueueNumber = int(((self.Time + (self.Properties["Time offset"][0]/1000)) * float(self.Properties["Speed"][0])) % (self.TotalPixelCount + self.Properties["Width"][0] - 1 + (self.Properties["Hold"][0]/1000)*self.Properties["Speed"][0]))
                        if pixel.QueueNumber > chaserQueueNumber - self.Properties["Width"][0] and pixel.QueueNumber <= chaserQueueNumber:
                            if self.Properties["Width"][0] > 0:
#                                print(chaserQueueNumber)
#                                print(pixel.QueueNumber)
#                                print(self.StrokeBitmap)
                                pixel.PixelColor = self.StrokeBitmap[1][chaserQueueNumber - pixel.QueueNumber]
                        else:
                            #Gradient calculation with totalpixels as length!
                            if self.TotalPixelCount > 0:
                                pixel.PixelColor = self.StrokeBitmap[0][pixel.QueueNumber]

                    elif self.Animation == "Chaser Grad2":
                        chaserQueueNumber = int(((self.Time + (self.Properties["Time offset"][0]/1000)) * float(self.Properties["Speed"][0])) % (self.TotalPixelCount + self.Properties["Width"][0] - 1 + (self.Properties["Hold"][0]/1000)*self.Properties["Speed"][0]))
                        if pixel.QueueNumber > chaserQueueNumber - self.Properties["Width"][0] and pixel.QueueNumber <= chaserQueueNumber:
                            #Peek background gradient!
                            if self.TotalPixelCount > 0:
                                pixel.PixelColor = self.StrokeBitmap[1][pixel.QueueNumber]
                        else:
                            #Background color!
                            if self.TotalPixelCount > 0:
                                pixel.PixelColor = self.StrokeBitmap[0][pixel.QueueNumber]

                    elif self.Animation == "Draw On":
                        index = int(self.Time * float(self.Properties["Speed"][0]) % (self.TotalPixelCount + (self.Properties["Hold"][0]/1000)*self.Properties["Speed"][0]))
                        if pixel.QueueNumber <= index:
                            pixel.PixelColor = self.Colors[0]
                        else:
                            pixel.PixelColor = self.Colors[1]

                    elif self.Animation == "Police":
                        #Speed = BPM -> default = 60
                        # 4s = 1.5s = 
                        if pixel.QueueNumber > self.TotalPixelCount/2:
                            if (self.Time % (60/float(self.Properties["Speed"][0])) > 30/float(self.Properties["Speed"][0]) and flicker):
                                pixel.PixelColor = self.Colors[1]
                            else:
                                pixel.PixelColor = self.Colors[2]
                        else:
                            if (self.Time % (60/float(self.Properties["Speed"][0])) <= 30/float(self.Properties["Speed"][0]) and flicker):
                                pixel.PixelColor = self.Colors[0]
                            else:
                                pixel.PixelColor = self.Colors[2]
                    elif self.Animation == "Video Stream":
                        #ITSH conversion TODO: Move to separate file!
                        VideoPixel = np.array(self.Layer.VideoStream[pixel.PixelNumber])
                        #pixel.PixelColor = np.array(self.Layer.VideoStream[pixel.PixelNumber])
                        #VideoPixel[0] = VideoPixel[0] * self.Properties["Color1"][0]/100 #self.Layer.Scene.ColorCalibrator.Ilut[self.Properties["Color1"][0]][pixel.PixelColor[0]]
                        #VideoPixel[1] = self.Properties["Color1"][1]
                        #VideoPixel[2] = VideoPixel[2] * self.Properties["Color1"][2]/120 #self.Layer.Scene.ColorCalibrator.Slut[self.Properties["Color1"][2]][pixel.PixelColor[2]]
                        #VideoPixel[3] = VideoPixel[3] + self.Properties["Color1"][3] % 360

                        ##ITSH to RGBW
                        VideoPixel = self.Layer.Scene.ColorCalibrator.ITSHtoRGBWFull(VideoPixel)

                        #Gamma correction (lookup table)
                        pixel.PixelColor = np.array(self.Layer.Scene.ColorCalibrator.GammaCorrectionLookup[self.Properties["Gammax10"][0]][VideoPixel])
                    elif self.Animation == "DMX":
                        if self.TotalPixelCount > 0:
                            pixel.PixelColor = self.StrokeBitmap[0][pixel.QueueNumber]
                    else:
                        if self.UpdateStationary:
                            pixel.PixelColor = np.array(self.Colors[0]) #Initialization/ugly            
                        
            if self.UpdateStationary:
                self.UpdateStationary = False

        except Exception as e:
            exc_info = sys.exc_info()
            traceback.print_exception(*exc_info)
            del exc_info
            timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
            vylogger.exception("[%s] [AnimationPlayer] [Scene] Exception: %s" % (timestamp, str(e)))
            pass
        
           
#TODO: Move this to output file
#Base class
class OutputBaseClass:
    def Send(self, frame):
        pass

class OutputPrint(OutputBaseClass):
    def Send(self, frame):
        print(frame)

class OutputToVoyager(OutputBaseClass):
    def __init__(self, OutputSerialPort = None):
        if OutputSerialPort == None:
            self.SerialPort = serial.Serial(
                port='/dev/ttyS1',
                baudrate=750000,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1
            )
        else:
            self.SerialPort = OutputSerialPort
        
        self.SerialPort.flushInput()
        self.SerialPort.flushOutput()

    def Send(self, frame, lampPixelCount):
        try:
            start = np.array([0xD5, 0x0A, 0x10, 0x03, 0x00, 0x00, 0x00, lampPixelCount-1], dtype = np.uint8)
            end = np.array([0xEF,0xFE,0x00], dtype = np.uint8)
            pixelColors = np.zeros(lampPixelCount*4, dtype = np.uint8)
            for pixelNumber, color in frame.items():
                pixelColors[pixelNumber*4:pixelNumber*4+4] = color
            serialMessage = np.concatenate((start, pixelColors, end),0)
            self.SerialPort.write(serialMessage)
        except Exception as e:
            exc_info = sys.exc_info()
            traceback.print_exception(*exc_info)
            del exc_info
            timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
            vylogger.exception("[%s] [AnimationPlayer] [OutputToVoyager] Exception: %s" % (timestamp, str(e)))
            pass
        
class OutputToFile(OutputBaseClass):
    #TODO: Implement functionality
    def Send(self, frame):
        return super().Send(frame)

class OutputToDS(OutputBaseClass):
    def __init__(self):
        self.SerialPort = serial.Serial(
            port='/dev/ttyUSB0',
            baudrate=250000,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_TWO,
            bytesize=serial.EIGHTBITS,
            timeout=1
        )
    
    def Send(self, frame, lampPixelCount):
        self.SerialPort.send_break(0.0002)
        time.sleep(0.0001)
        pixelColors = np.zeros(513, dtype = np.uint8)
        for pixelNumber, color in frame.items():
            index = pixelNumber*5 + 1 
            pixelColors[index:index+4] = color
            pixelColors[index+4] = 50
        self.SerialPort.write(pixelColors)

class OutputToController(OutputBaseClass):
    def __init__(self, address, fps = -1):
        self.Socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.Socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
        self.Socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
        self.Socket.bind(("", 31000))
        self.Address = address
        self.TimePeriod = 1/fps
        self.LastTime = time.time()
        self.CurrentTime = time.time()

    def Send(self, frame, lampPixelCount):
        try:
            if self.TimePeriod > 0:
                self.CurrentTime = time.time()
                timePassed = self.CurrentTime - self.LastTime
                if not abs(timePassed) > self.TimePeriod:
                    return
                else:
                    self.LastTime = time.time()
            start = np.array([0xD5, 0x0A, 0x50, 0x03, 0x00, 0x00, lampPixelCount, 0x00], dtype = np.uint8)
            end = np.array([0xEF,0xFE,0x00], dtype = np.uint8)
            pixelColors = np.zeros(lampPixelCount*4, dtype = np.uint8)
            for pixelNumber, color in frame.items():
                pixelColors[pixelNumber*4:pixelNumber*4+4] = color
            serialMessage = np.concatenate((start, pixelColors, end),0)
            destination = list(self.Address)
            destination[1] = 31000
            try:
                self.Socket.sendto(bytes(serialMessage), tuple(destination))
            except:
                pass
        except Exception as e:
            exc_info = sys.exc_info()
            traceback.print_exception(*exc_info)
            del exc_info
            timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
            vylogger.exception("[%s] [AnimationPlayer] [OutputToController] Exception: %s" % (timestamp, str(e)))
            pass
