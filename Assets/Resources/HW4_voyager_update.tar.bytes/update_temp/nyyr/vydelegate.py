import netifaces
import os
import socket
import sys
import json
import time
import logging
import datetime
import traceback
from threading import Thread
import time


# global variables
VERSION = [0, 78]  # 2 byte values
network_dict = {}
lampIdentity = bytearray()
wifiModeChangeThread = Thread()
wifiSSIDScanThread = Thread()

vylogger = logging.getLogger('vylogger')


#full length
fullColorPacket = bytearray()
fullColorPacket[0:8] = 0xD5, 0x0A, 0x10, 0x03, 0x00, 0x00, 0x00, 0x52
for x in range(0, 330, 4):
    fullColorPacket[x+8:x+8+4] = 0x00, 0x00, 0x00, 0x00  #RGBW
fullColorPacket[340:343] = 0xEF, 0xFE, 0x00

# Classes
class CVYUDPDelegate(Thread):
    def __init__(self, serialwritefunc, latestLampIdentity):
        Thread.__init__(self)

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("", 30000))
        self.sock.settimeout(0.5)
        self.last_poll_time = 0
        self.POLLING_DELAY = 10

        self.SSIDLIST_POLL_DELAY = 20
        self.last_ssid_poll_time = 0
        self.ssidlist_counter = 0
        self.ssidlist = ""

        self.serialWrite = serialwritefunc

        # poll info or states for which need to be read only once
        self.chip_read_flag = 0
        self.animation_read_flag = 0
        self.serial_read_flag = 0
        self.mac_read_flag = 0

        self.UDPResponse = {}

        global lampIdentity
        lampIdentity = latestLampIdentity

    def run(self):
        self.startListening()

    def startListening(self):
        """
        Infinite loop, received and handles udp
        :return:
        """
        while True:
            try:
                udp_data, addr = self.sock.recvfrom(4096)
                self.handleUDPData(udp_data, addr)

            except socket.timeout:  # expected to happen
                pass
            except KeyboardInterrupt:
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
                vylogger.exception("[%s] [CVYUDPDelegate] Keyboard Exception: %s" % (timestamp, str(e)))
                self.sock.close()
                sys.exit()
                raise
            except Exception as e:  # unexpected
                exc_info = sys.exc_info()
                traceback.print_exception(*exc_info)
                del exc_info
                timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
                vylogger.exception("[%s] [CVYUDPDelegate] Exception: %s" % (timestamp, str(e)))
                pass

    def configAP(self):
        """

        :return:
        """

        serial = os.popen("cat /mnt/data/serial.txt").readline().strip()
        if serial != "":
            os.system("sed -i '6 s/.*/ssid=%s/' /etc/hostapd/hostapd.conf" % serial)

        os.system("sed -i '/channel=/c\channel=6' /etc/hostapd/hostapd.conf")
        os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=dsputnik' /etc/hostapd/hostapd.conf")
        os.system("sed -i '/wpa=/c\wpa=2' /etc/hostapd/hostapd.conf")

    def handleUDPData(self, udp_data, addr):
        global wifiModeChangeThread
        global wifiSSIDScanThread

        # Checks flag bytes
        if (udp_data[0] == 0xD5) and (udp_data[1] == 0x0A):
            # COLOR PACKET
            if udp_data[2] == 0x10:
                self.serialWrite(udp_data[:len(udp_data)])
            # RESET PACKET
            elif udp_data[2] == 0x82 and udp_data[3] == 0x10:
                # reset animation
                os.system("rm /mnt/data/animation/strokedata.dat")

                # AP config
                self.configAP()

                # Default ssid to connect to
                with open("/mnt/data/ssidlist.txt", "w") as f:
                    f.write("\"voyager_router\" dsputnik\n")  # newline must be added, connect cm v2 uses newline count

                reset = bytearray()
                reset[0:7] = 0xD5, 0x0A, 0x82, 0x20, 0xEF, 0xFE, 0x00
                self.sock.sendto(reset, addr)

                # start AP
                if not wifiModeChangeThread.isAlive():
                    wifiModeChangeThread = Thread(target=enable_ap, args=(None, ))
                    wifiModeChangeThread.start()

            #SSID LIST PACKET RESPONSE
            elif (udp_data[2] == 0x87 and udp_data[3] == 0x10):
                #print (time.time() - self.last_ssid_poll_time)

                # keeps timer and counter..
                # 4 ssid scan readings and responses, after that for 10 seconds responds instantly with last successful scan.
                if (time.time() - self.last_ssid_poll_time> self.SSIDLIST_POLL_DELAY or time.time() - self.last_ssid_poll_time< 0):

                    #if self.ssidlist_counter >= 3:
                    #    self.last_ssid_poll_time = time.time()
                    #    self.ssidlist_counter = 0
                    #else:
                    #    self.ssidlist_counter += 1

                    if not wifiSSIDScanThread.isAlive():
                        wifiSSIDScanThread = Thread(target=self.wifiSsidScan, args = (addr,))
                        wifiSSIDScanThread.start()
                    else:
                        pass
                        # print ("scanning already running")

                # sending out already scanned list, 10 second time period
                elif (len(self.ssidlist)) > 0:  # to avoid sending empty lists
                    self.sock.sendto(json.dumps(self.ssidlist).encode() , addr)

            # TIME SYNC PACKET
            elif udp_data[2] == 0x83 and udp_data[3] == 0x10:
                print("Timesync respond")

                # send current time
                time_start = bytearray()
                time_start[0:4] = 0xD5, 0x0A, 0x83, 0x20
                # current_time = os.popen("date +%s%3N").readline().strip()
                current_time = str(time.time())
                time_start[4:] = bytearray(current_time, "ascii")
                # print (time.time())
                # print (list(time_start))
                self.sock.sendto(time_start, addr)
            # DUMMY TIME SYNC PACKET - testing timedelays.
            elif udp_data[2] == 0x84 and udp_data[3] == 0x10:
                # send current time
                time_start = bytearray()
                time_start[0:4] = 0xD5, 0x0A, 0x84, 0x20
                # current_time = os.popen("date +%s%3N").readline().strip()
                current_time = str(time.time())
                time_start[4:] = bytearray(current_time, "ascii")
                # print (list(time_start))
                self.sock.sendto(time_start, addr)
            # TIMESYNC FLAGED PACKET - using router. Time has been set or first one in network
            elif udp_data[2] == 0x85 and udp_data[3] == 0x10:
                # send current time
                if os.popen("cat /mnt/data/timesyncflag").readline().strip() == "1":
                    time_start = bytearray()
                    time_start[0:4] = 0xD5, 0x0A, 0x85, 0x20
                    current_time = str(time.time())
                    time_start[4:] = bytearray(current_time, "ascii")
                    self.sock.sendto(time_start, addr)
            # POLL INFO COLLECTION
            # POLL PACKET FROM UDP DEVICE OUTSIDE
            elif udp_data[2] == 0x80 and udp_data[3] == 0x10:

                global lampIdentity
                poll_info = lampIdentity

                # not an empty packet from LPC
                if len(poll_info) > 0:
                    # timedelay how often reads and calculates poll
                    if ((time.time() - self.last_poll_time) > self.POLLING_DELAY) or self.last_poll_time == 0 or (time.time() - self.last_poll_time) < 0:
                        self.last_poll_time = time.time()

                        # crc check for lpc sent packet
                        if poll_info[16] == self.calcCrc8(poll_info, len(poll_info) - 1):

                            # IP
                            # sets client wlan0 by default
                            if len(netifaces.ifaddresses('wlan0')) >= 3:
                                self.UDPResponse["IP"] = list(
                                    socket.inet_aton(
                                        netifaces.ifaddresses('wlan0')[2][0][
                                            'addr']))

                            # NUMBER OF LEDS
                            self.UDPResponse["length"] = poll_info[12]

                            # BATTERY LEVEL
                            self.UDPResponse["battery_level"] = poll_info[5]

                            # BQ TEMPERATURE
                            try:
                                kelvin = float(
                                    int.from_bytes(poll_info[6:8], byteorder='big'))
                                celsius = kelvin / 10 - 273.15
                                self.UDPResponse["BQ_temp"] = int(str(celsius)[:2]), int(
                                    str(celsius)[3:4])
                            except:
                                pass
                            # need to overlook this temp calculation..

                            # CHARGING
                            self.UDPResponse["charging_status"] = list(poll_info[8:10])

                            # LPC VERSION
                            self.UDPResponse["LPC_version"] = list(poll_info[10:12])

                            # Voyager Hardware version
                            self.UDPResponse["hardware_version"] = poll_info[13]

                            # CHIP VERSION
                            if self.chip_read_flag == 0:
                                self.UDPResponse["CHIP_version"] = VERSION
                                self.chip_read_flag = 1

                            # ANIMATION VERSION
                            if self.animation_read_flag == 0:
                                if os.path.isfile("/mnt/data/animation/version"):
                                    animation_ver_read = os.popen(
                                        "cat /mnt/data/animation/version").readline().strip().split(
                                        '.')
                                    animation_ver_read = [int(i) for i in
                                                          animation_ver_read]
                                    self.UDPResponse[
                                        "animation_version"] = animation_ver_read
                                    self.animation_read_flag = 1
                                else:
                                    self.UDPResponse["animation_version"] = [0, 0]
                                    self.animation_read_flag = 1

                            # LAST 6 MAC addr
                            if self.mac_read_flag == 0:
                                self.UDPResponse["MAC_last6"] = os.popen(
                                    "ip addr show wlan0 |"
                                    "sed -n 2p |"
                                    "tr -d : |"
                                    "cut -d ' ' -f 6 |"
                                    "cut -c 7-").readline().strip()
                                self.mac_read_flag = 1

                            # PASSIVE/ACTIVE MODE
                            f = open("/sys/class/gpio/gpio94/value", "r")  # 94 for ARTIK, 128 for chip
                            self.UDPResponse["passive_active_mode"] = int(f.read())
                            f.close()

                            # ACTIVE SSID PATTERN TO CONNECT TO ###
                            f = open("/mnt/data/ssidlist.txt", "r")
                            templist = f.readline()

                            # Removes first quotation mark to make sure, when first character is space,
                            #   pattern isnt split from there.
                            # Splits according to second quotation mark followed by space
                            splitActivePattern = templist[1:].split("\" ")
                            try:
                                self.UDPResponse["active_pattern"] = splitActivePattern[0].strip()
                                self.UDPResponse["active_pattern_ps"] = splitActivePattern[1].strip()
                            except UnboundLocalError:
                                pass

                            f.close()

                            # ACTIVE SSID AND CHANNEL
                            f = open("/etc/hostapd/hostapd.conf", "r")
                            templist = f.readlines()
                            self.UDPResponse["active_channel"] = templist[7].strip()[8:]
                            self.UDPResponse["active_ssid"] = templist[5].strip()[5:]
                            self.UDPResponse["active_password"] = templist[10].strip()[15:]

                            f.close()

                            # ACTIVE NETWORK MODE ###
                            f = open("/mnt/data/network_mode", "r")
                            self.UDPResponse["active_mode"] = f.readline().strip()
                            f.close()

                            # SERIAL NAME
                            if self.serial_read_flag == 0:
                                self.UDPResponse["serial_name"] = os.popen(
                                    "cat /mnt/data/serial.txt").readline().strip()
                                self.serial_read_flag = 1

                            # END POLL PACKET RESPONSE
                            UDPResponseJSON = json.dumps(self.UDPResponse)
                            # self.recentUDPResponseJSON = UDPResponseJSON
                            self.sock.sendto(UDPResponseJSON.encode(), addr)
                    else:
                        UDPResponseJSON = json.dumps(self.UDPResponse)
                        self.sock.sendto(UDPResponseJSON.encode(), addr)

        # Network mode 22.05.18
        # Needs a better way to listen for udp JSON and filter it
        elif len(udp_data) > 6:
            global network_dict
            network_dict = json.loads(udp_data.decode('utf-8'))

            if 'network_mode' in network_dict:
                if network_dict['network_mode'] == "ap_mode":
                    network_response = bytearray()
                    network_response[0:8] = 0xD5, 0x0A, 0x86, 0x01, 0x20, 0xEF, 0xFE, 0x00
                    self.sock.sendto(network_response, addr)
                    print("Enable AP from App")
                    if not wifiModeChangeThread.isAlive():
                        wifiModeChangeThread = Thread(target=enable_ap, args=(None, ))
                        wifiModeChangeThread.start()
                    else:
                        print("Already changing WiFi mode")

                elif network_dict['network_mode'] == "client_mode":

                    network_response = bytearray()
                    network_response[0:8] = 0xD5, 0x0A, 0x86, 0x02, 0x20, 0xEF, 0xFE, 0x00
                    self.sock.sendto(network_response, addr)
                    print("Enable Wlan from App")
                    if not wifiModeChangeThread.isAlive():
                        wifiModeChangeThread = Thread(target=enable_wlan, args=(None, ))
                        wifiModeChangeThread.start()
                    else:
                        print("Already changing WiFi mode")

            # reset network settings received
            # network_dict = {}

    @staticmethod
    def calcCrc8(packet, length):
        crctab = bytearray(
            [0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41, 0x9d, 0xc3,
             0x21,
             0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc, 0x23, 0x7d, 0x9f, 0xc1, 0x42,
             0x1c,
             0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62, 0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,
             0x7c,
             0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff, 0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38,
             0x66,
             0xe5, 0xbb, 0x59, 0x07, 0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26,
             0xc4,
             0x9a, 0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24, 0xf8,
             0xa6,
             0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9, 0x8c, 0xd2, 0x30, 0x6e,
             0xed,
             0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd, 0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc,
             0x92,
             0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50, 0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33,
             0xd1,
             0x8f, 0x0c, 0x52, 0xb0, 0xee, 0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91,
             0xcf,
             0x2d, 0x73, 0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
             0x57,
             0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16, 0xe9, 0xb7, 0x55,
             0x0b,
             0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8, 0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b,
             0xa9,
             0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35])
        length = int(length) & 0xff
        temp = 0xff  # seed value
        for i in range(0, length):
            temp = temp ^ crctab[temp ^ packet[i]]
        return temp

    def wifiSsidScan(self, addr):
        #os.system("ps ax | grep -v grep | grep 'iw dev' | awk -F ' ' '{print $1}' | xargs kill -9 2> /dev/null ")
        os.system("ps ax | grep -v grep | grep 'iwlist' | awk -F ' ' '{print $1}' | xargs kill -9 2> /dev/null ")
        os.system("ps ax | grep -v grep | grep 'iwlist' | awk -F ' ' '{print $1}' | xargs kill -9 2> /dev/null ")
        # clean last scan result
        os.system("echo "" > /tmp/temp_scanlist 2> /dev/null ")

        # scan to /tmp/temp_scanlist
        #os.system("nice --19 iw dev p2p0 scan | grep 'SSID:' | column -t | tr -s ' ' >> /tmp/temp_scanlist & ")
        # iwlist p2p0 scan | grep SSID: |  grep -Eo '".*"' | tr -d '"' >> /tmp/temp_scanlist &
        # echo -e $(iwlist p2p0 scan | grep SSID: |  grep -Eo '".*"' | tr -d '"') # should be used - fixes weird characters, also removed newline
        # echo -e "$(iwlist p2p0 scan | grep SSID: | grep -Eo '".*"' | tr -d '"')" # retains newline
        #os.system('iwlist p2p0 scan | grep ssid: |  grep -eo \'".*"\' | tr -d \'"\' >> /tmp/temp_scanlist &')

        # Removed starting in another process along with sleep
        # Due to scanning not being complete after sleep
        os.system('echo -e "$(iwlist p2p0 scan | grep SSID: | grep -Eo \'".*"\' | tr -d \'"\')" >> /tmp/temp_scanlist')

        # include dbm possibly in future.. older scan implementation
        # rawscan_temp = os.popen("iw dev wlan0 scan | grep 'SSID:\|signal:' | awk '{ ORS = (NR%2 ? FS : RS) } 1' | column -t | tr -s ' ' | grep -E '^.{26,}$' &").read()
        # ssidlist = rawscan.replace('SSID:', '').replace('SSID:', '').replace('signal:', '').replace('dBm ', '').replace('.00 ', '').replace(' -','').strip().replace('\n\n','\n').splitlines()

        # timeout for waiting scan results
        #time.sleep(5.5)

        f = open("/tmp/temp_scanlist", "r")
        rawscan_temp = f.read()
        f.close
        # print (rawscan_temp)

        if rawscan_temp != "":
            rawscan = rawscan_temp

        # Remove empty lines
        self.ssidlist=rawscan.strip().replace('\n\n', '\n').splitlines()
        # print (self.ssidlist)

        if (len(self.ssidlist)) > 0:  # to avoid sending empty lists
            start_time_ssidlist=time.time()
            self.sock.sendto(json.dumps(self.ssidlist).encode() , addr)
        else:
            start_time_ssidlist=time.time()-30

            #time.sleep(2)  # avoids scanning too often.. crashes 'iw dev...'

class CVyLPCDelegate:
    def __init__(self, serialwritefunc, latestLampIdentity, pixelCount, animationManager):
        """
        :param serialWriteFunc(bytearray()): function used for writing to serial port
        """
        self.pixelCount = pixelCount
        self.animationManager = animationManager
        self.serialWrite = serialwritefunc
        self.lastSideButtonTime = 0

        print("vy_delegate")
        global lampIdentity
        lampIdentity = latestLampIdentity

    def tick(self):
        if ((self.lastSideButtonTime + 500) < int(round(time.time() * 1000))) and self.lastSideButtonTime != 0:
            self.lastSideButtonTime = 0
            self.switchWiFiMode()


    def handleSerialData(self, data):
        """
        Handles serial data
        handleSerialData(bytearray()) -> none

        :param data: data to handle as bytearray - input of serial
        """
        print("handle serial data: %s" % data)

        # Lamp identity
        if data[:4] == b'\xD5\x0A\x50\x0B':
            print("VY_Delegate - New lamp identity received.")
            global lampIdentity
            lampIdentity = data

        # Side button
        elif data[:4] == b'\xD5\x0A\x50\x04':
            buttonType = data[4:4 + 1]
            timeButtonHeld = int.from_bytes(data[5:5 + 2], byteorder='big')

            self.handleSideButton(buttonType, timeButtonHeld)

        # Top battery button
        elif data[:5] == b'\xD5\x0A\x50\x05\x01':
            self.handleInstantBatteryClick()

    @staticmethod
    def isHostapdrunning():
        return os.popen("ps ax | grep -v grep | grep hostapd |\
                awk -F ' ' 'NR==1{print $5, $6}'").readline().strip() == "/usr/sbin/hostapd -B"

    @staticmethod
    def isWlanRunning():
        """
        :return: bool
        """
        return "/sbin/wpa_supplicant -c /etc/wpa_supplicant/wpa_supplicant.conf -u -iwlan0 -Dnl80211 -s" == \
               os.popen(
                   "ps ax |"
                   "grep -v grep |"
                   "grep wpa_supplicant |"
                   "awk -F ' ' 'NR==1{print $5, $6, $7, $8, $9, $10, $11}'"
               ).readline().strip()

    @staticmethod
    def isApRunning():
        """
        :return: bool
        """
        return "/usr/sbin/hostapd -B" == os.popen(
            "ps ax |"
            "grep -v grep |"
            "grep hostapd |"
            "awk -F ' ' 'NR==1{print $5, $6}'").readline().strip()

    def handleSideButton(self, buttonType, heldtime):
        """
        :heldtime: time button has been held down
        type: int
        """

        # Temporary solution only for wifi mode change
        global wifiModeChangeThread
        global fullColorPacket


        # release between 5 and 10 sec when not switching WiFi mode
        if 5000 <= heldtime <= 10000:
            if self.animationManager.Active and not wifiModeChangeThread.isAlive():  # do set blue button and disable animation
                self.animationManager.deactivate()  # activation is done after mode change
            if not self.animationManager.Active:
                colorData = bytearray(fullColorPacket)
                if self.pixelCount == 42:
                    colorData[168:172] = 0x00, 0x00, 0xFF
                elif self.pixelCount == 83:
                    colorData[332:336] = 0x00, 0x00, 0xFF
                self.serialWrite(colorData)
            self.lastSideButtonTime = int(round(time.time() * 1000))

            if buttonType == b'\x03' or buttonType == b'\x02' and not wifiModeChangeThread.isAlive():  # on release
                self.lastSideButtonTime = 0
                self.switchWiFiMode()


        # release between 10 and 12 sec when not switching WiFi mode - switch wifi mode immediately without reset.
        #   This due to no release packet from LPC
        elif 10000 < heldtime < 12000:
            if self.animationManager.Active and not wifiModeChangeThread.isAlive():  # do set blue button and disable animation
                self.animationManager.deactivate()  # activation is done after mode change
            if not self.animationManager.Active:
                colorData = bytearray(fullColorPacket)
                if self.pixelCount == 42:
                    colorData[168:172] = 0xFF, 0xFF, 0xFF
                elif self.pixelCount == 83:
                    colorData[332:336] = 0xFF, 0xFF, 0xFF
                self.serialWrite(colorData)

            if not wifiModeChangeThread.isAlive():
                wifiModeChangeThread = Thread(target=reset_wifi, args=(self.animationManager, ))
                wifiModeChangeThread.start()
            #if (buttonType == b'\x03' or buttonType == b'\x02') and \
            #        not wifiModeChangeThread.isAlive():
            #    wifiModeChangeThread = Thread(target=reset_wifi, args=(self.animationManager, ))
            #    wifiModeChangeThread.start()

        # 2.5 sec
        # Temporary solution fixed issue where release does not always reach
        # if buttonType == b'\x02' and 2000 <= heldtime <= 5000:  # release between 2 and  sec changes wifi mode
        #    self.sideButtonReleased = True
        #    self.switchWiFiMode()

    def switchWiFiMode(self):
        global wifiModeChangeThread
        if not wifiModeChangeThread.isAlive():
            if self.isWlanRunning():
                wifiModeChangeThread = Thread(target=enable_ap, args=(self.animationManager, ))
            elif self.isApRunning():
                wifiModeChangeThread = Thread(target=enable_wlan, args=(self.animationManager, ))
            else:
                wifiModeChangeThread = Thread(target=enable_ap, args=(self.animationManager, ))
            wifiModeChangeThread.start()

    def handleInstantBatteryClick(self):
        pixel = b'\x00'
        global lampIdentity

        # set pixel from lamp identity
        if lampIdentity[4:4 + 1] == b'\x01':  # Short voyager
            pixel = b'\x28'
        elif lampIdentity[4:4 + 1] == b'\x02':  # Long voyager
            pixel = b'\x50'

        global wifiModeChangeThread
        if not wifiModeChangeThread.isAlive():
            try:
                # dumb ap, hostapd running. display yellow
                if netifaces.ifaddresses('wlan0')[2][0]['addr'] == "172.20.0.1" and self.isHostapdrunning():
                    rgbwcolor = b'\xFF\x70\x00\x00'  # yellow

                # connected client mode. tries to ping host. pings again in CLIENT_PING_DELAY
                elif os.popen("ip addr | egrep -i 'inet.+wlan0' | awk -F[\ /] '{print $6}'").readline().strip() != '':
                    # ping ok, display green
                    if os.system("ping -c 1 -W 1 -I wlan0 $(ip route | awk 'NR==1{print $3}') > /dev/null") == 0:
                        rgbwcolor = b'\x00\xFF\x00\x00'  # green
                    # no ping response, displays red
                    else:
                        rgbwcolor = b'\x70\x00\x00\x00'  # red

                # not connected client, displays red
                else:
                    rgbwcolor = b'\x70\x00\x00\x00'  # red
            except:
                rgbwcolor = b'\xFF\x00\x00\x00'  # full red
        else:
            rgbwcolor = b'\x00\x00\xFF\x00'  # blue

        apstatuscolor = b'\xd5\x0a\x10\x08\x02' + \
                        b'\x00' + pixel + \
                        b'\x00' + pixel + \
                        rgbwcolor + \
                        b'\xEF\xFE\x00'
        self.serialWrite(apstatuscolor)


# Global functions

def resetWlanSSIDs():
    # set pattern in /mnt/data/ssidlist.txt
    try:
        pattern_ssid = network_dict['set_pattern']
        pattern_ps = network_dict['set_pattern_ps']

        if pattern_ssid != "":
            pattern = "\"" + pattern_ssid + "\" " + pattern_ps # Ei saa settida mitut patternit
            with open("/mnt/data/ssidlist.txt", "w") as f:
                f.write(pattern+"\n")  # newline must be added, connect cm v2 counts newlines
            #change wpa supplicant conf
            command='sed -i /"ssid=/c\	ssid=\\"'+pattern_ssid+'\\"\" /etc/wpa_supplicant/wpa_supplicant.conf'
            os.system(command)
            if pattern_ps != "":
               os.system('sed -i "/psk=/c\	psk=\\"%s\\"\" /etc/wpa_supplicant/wpa_supplicant.conf' % pattern_ps)
               os.system('sed -i "/key_mgmt=/c\	psk=\\"%s\\"\" /etc/wpa_supplicant/wpa_supplicant.conf' % pattern_ps)
            else:
               os.system('sed -i "/psk=/c\	key_mgmt=NONE" /etc/wpa_supplicant/wpa_supplicant.conf')
               os.system('sed -i "/key_mgmt=/c\	key_mgmt=NONE" /etc/wpa_supplicant/wpa_supplicant.conf')
    except Exception as e:
        print("ResetWlanSSID Exception: %s" %e)


def enable_wlan(animationManager):

    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
    # kill AP
    os.system("systemctl stop hostapd")
    os.system("systemctl stop dnsmasq")
    os.system("ifconfig wlan0 0.0.0.0 up")
    os.system("systemctl restart wpa_supplicant")
    time.sleep(4)
    os.system("dhclient &")
    time.sleep(2)

    # Why is setting wpa_supplicant in resetWlanSSIDs necessary, since connect_cm_v2 already does that
    resetWlanSSIDs()
    time.sleep(2)


    # start autoconnect to wifi network
    os.system("sh /mnt/data/connect_cm_v2.sh &")
    # set flag
    os.system("echo client_mode > /mnt/data/network_mode")
    os.system("echo 0 > /mnt/data/timesyncflag")

    if animationManager != None:
        animationManager.activate()

    return


def enable_ap(animationManager):
    # TO DO AC SETTINGS  !

    try:
        ssid = network_dict['set_ssid']
        password = network_dict['set_password']
        # ssid
        if ssid != "":
            os.system(
                "sed -i '6 s/.*/ssid=%s/' /etc/hostapd/hostapd.conf" % ssid)  # kinda danger, replaces by line number
        # open network settings..
        if password != "":
            os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /etc/hostapd/hostapd.conf" % password)
            os.system("sed -i '/wpa=/c\wpa=2' /etc/hostapd/hostapd.conf")
        else:
            os.system("sed -i '/wpa=/c\wpa=0' /etc/hostapd/hostapd.conf")
            os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=%s' /etc/hostapd/hostapd.conf" % password)
    except:
        print("no ssid, password")

    # SET CHANNEL
    try:
        channel = network_dict['set_channel']
        if 1 <= channel <= 11:
            os.system("sed -i '/channel=/c\channel=%s' /etc/hostapd/hostapd.conf" % channel)
    except:
        print("no channel")

    time.sleep(1)
    os.system("systemctl stop wpa_supplicant")
    os.system("pkill dhclient")
    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")
    os.system("ps ax | grep -v grep | grep connect_cm_v2 | awk -F ' ' '{print $1}' | xargs kill -9")

    os.system("ifconfig wlan0 0.0.0.0 ")
    os.system("ifconfig wlan0 172.20.0.1/24 up")
    os.system("systemctl restart dnsmasq")
    time.sleep(1)
    os.system("systemctl stop hostapd")
    time.sleep(1)
    os.system("systemctl start hostapd")

    # set flag
    os.system("echo ap_mode > /mnt/data/network_mode")

    time.sleep(2)

    if animationManager != None:
        animationManager.activate()
    return


def reset_wifi(animationManager):


    serial = os.popen("cat /mnt/data/serial.txt").readline().strip()

    # AP config
    if serial != "":
        os.system("sed -i '6 s/.*/ssid=%s/' /etc/hostapd/hostapd.conf" % serial)

    os.system("sed -i '/channel=/c\channel=6' /etc/hostapd/hostapd.conf")
    os.system("sed -i '/wpa_passphrase=/c\wpa_passphrase=dsputnik' /etc/hostapd/hostapd.conf")
    os.system("sed -i '/wpa=/c\wpa=2' /etc/hostapd/hostapd.conf")


    # Default ssid to connect to
    with open("/mnt/data/ssidlist.txt", "w") as f:
        f.write("\"voyager_router\" dsputnik\n")  # newline must be added, connect cm v2 uses newline count

    os.system('sed -i /"ssid=/c\	ssid=\\"voyager_router\\"\" /etc/wpa_supplicant/wpa_supplicant.conf')
    os.system('sed -i "/psk=/c\	psk=\\"dsputnik\\"\" /etc/wpa_supplicant/wpa_supplicant.conf')

    global network_dict
    network_dict = {}

    # start AP
    enable_ap(animationManager)

    return
