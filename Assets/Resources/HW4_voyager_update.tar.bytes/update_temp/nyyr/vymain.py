import time
from builtins import dict

import vydelegate
import vyconnman
import PythonReceiverClass
import serial
import os
import vydodc
import sys
import traceback
import datetime
import logging
from logging.handlers import RotatingFileHandler

LOG_FILENAME = '/mnt/data/vymain_log.log'
vylogger = logging.getLogger('vylogger')
vylogger.setLevel(logging.DEBUG)
handler = RotatingFileHandler(LOG_FILENAME, maxBytes=10000000, backupCount=2)
vylogger.addHandler(handler)


lpcSerialConnection = None
dodcSerialConnection = None

# LPC Serial connection
try:
    # serial connection between artik and lpc
    lpcSerialConnection = serial.Serial(
        port='/dev/ttyAMA0',
        baudrate=1500000,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        rtscts=False,
        timeout=0
    )

    # serial connection between artik and DODC
    dodcSerialConnection = serial.Serial(
        port='/dev/ttyAMA4',
        baudrate=750000,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        rtscts=False,
        timeout=0
    )
    # hack to fix first boot problems with dodc serial connection
    # where serial connection is reported to be open, but no data is received
    dodcSerialConnection.close()
    dodcSerialConnection.open()
except Exception as e:
    timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    logging.exception("[%s][FATAL] Serial Exception: %s" % (timestamp, str(e)))
    sys.exit(1)

lpcConnman = vyconnman.CSerialConnectionManager(lpcSerialConnection, b'\xD5\x0A', b'\xEF\xFE')
lpcConnman.start()
dodcConnman = vyconnman.CSerialConnectionManager(dodcSerialConnection, b'\xAA', b'\xEF\xFE')
dodcConnman.start()

#enable tx
def enable_tx():
    enable_tx = vyconnman.CRawPacket(b'\xD5\x0A', b'\x50\x07\x30\x01', b'\xEF\xFE')
    lpcConnman.write(enable_tx)
    time.sleep(0.1)
    lpcConnman.write(enable_tx)
    time.sleep(0.1)

    lpcSerialConnection.flushInput()
    lpcSerialConnection.flushOutput()

def wait_enable_periodic_identity_update():
    """
        Waits to Enable LPC sending of periodic identity packets.
        Returns when LPC confirms sending of periodic packets
        :return: lamp identity
        """
    while True:
        serial_write_LPC(bytearray(b'\xD5\x0A\x50\x0A\x30\x01\x30\xEF\xFE\x00'))  # DS_VOYAGER_AUX_PERIODIC_UPDATE_CONFIG
        response = lpcConnman.popFront(b'\x50')
        if response is not None:
            responsebytearray = response.getbytearray()
            if responsebytearray[0:5] == b'\xD5\x0A\x50\x0A\x31' \
                    or \
                    responsebytearray[0:5] == b'\xD5\x0A\x50\x0B\x31':
                return responsebytearray
        time.sleep(0.01)  # sleep 10ms


def get_pixel_count():
    while True:
        serial_write_LPC(bytearray(b'\xD5\x0A\x50\x03\xEF\xFE\x00'))
        response = lpcConnman.popFront(b'\x50')
        if response is not None:
            responsebytearray = response.getbytearray()
            if responsebytearray[0:4] == b'\xD5\x0A\x50\x03':
                return responsebytearray[4]
        time.sleep(0.01)  #Sleep 10ms


def serial_write_LPC(data):
    """
        expects data with 3 byte footer, EFFE + crc8
        crc8 can be \x00 - is caluclated automatically

        :param data: raw dat to send
        :type data: bytearray
        :return: None

        """
    lpcConnman.write(vyconnman.CRawPacket(data[0:2], data[2: len(data) - 3], data[len(data) - 3:len(data) - 1]))


def main():

    lpcSerialConnection.flushInput()
    lpcSerialConnection.flushOutput()
    dodcSerialConnection.flushInput()
    dodcSerialConnection.flushOutput()

    print("Enabling TX")
    enable_tx()

    print("Enable periodic identity update")
    initialLampIdentity = wait_enable_periodic_identity_update()
    pixelCount = get_pixel_count()
    print("Periodic update enabled")

    # Animation manager in another thread
    animationManager = PythonReceiverClass.PythonReceiver(lpcSerialConnection, pixelCount)
    animationManager.start()

    # delegates - ut rework
    lpcdelegate = vydelegate.CVyLPCDelegate(serial_write_LPC, initialLampIdentity, pixelCount, animationManager)
    # UDP delegate in another thread
    udpdelegate = vydelegate.CVYUDPDelegate(serial_write_LPC, initialLampIdentity)
    udpdelegate.start()

    # dodc
    fileUploadHandler = vydodc.CFileUpload_Handler(dodcConnman)
    shellCommandHandler = vydodc.CShellCommand_Handler(dodcConnman)

    time.sleep(0.1)  # sleep 100ms, wait for all replies from LPC
    lpcConnman.clearAllPacketQueues()
    dodcConnman.clearAllPacketQueues()

    while True:
        # read and delegate serial data.
        lpcdelegate.tick()
        try:
            # Handle LPC Packets
            while lpcConnman.getPacketCount(b'\x50') > 0:
                lpcPacket = lpcConnman.popFront(b'\x50')
                lpcdelegate.handleSerialData(lpcPacket.getbytearray())

            # Handle data over DC packets
            while dodcConnman.getPacketCount(b'\x00') > 0:
                dodcPacket = dodcConnman.popFront(b'\x00')
                shellCommandHandler.doHandle(vyconnman.CJsonPacket.fromRawPacket(dodcPacket, 1, 2))
            while dodcConnman.getPacketCount(b'\x01') > 0:
                dodcPacket = dodcConnman.popFront(b'\x01')
                fileUploadHandler.doHandle(vyconnman.CJsonPacket.fromRawPacket(dodcPacket, 1, 2))

            # Check start/stop animation player
            while dodcConnman.getPacketCount(b'\x02') > 0:
                killAnimationPacketBytes = dodcConnman.popFront(b'\x02').getbytearray()
                # Disable animation player
                if killAnimationPacketBytes[2:2 + 1] == b'\x00':
                    if animationManager.Active:  # Deactivate
                        animationManager.deactivate()
                        dodcConnman.write(vyconnman.CRawPacket(b'\xAB', b'\x02\x00', b'\xEF\xFE'))
                    elif animationManager is None:  # already deactivated
                        dodcConnman.write(vyconnman.CRawPacket(b'\xAB', b'\x02\x03', b'\xEF\xFE'))

                # Enable animation player
                elif killAnimationPacketBytes[2:2 + 1] == b'\x01':
                    if not animationManager.Active:  # Activate when killed
                        animationManager.activate()
                        dodcConnman.write(vyconnman.CRawPacket(b'\xAB', b'\x02\x01', b'\xEF\xFE'))
                    elif animationManager is not None:  # Already active
                        dodcConnman.write(vyconnman.CRawPacket(b'\xAB', b'\x02\x02', b'\xEF\xFE'))

            lpcConnman.clearAllPacketQueues()  # clear all packets that were not handled
            dodcConnman.clearAllPacketQueues()  # clear all packets that were not handled

            time.sleep(0.02)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            exc_info = sys.exc_info()
            traceback.print_exception(*exc_info)
            del exc_info
            timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
            vylogger.exception("[%s] [Main] Exception: %s" % (timestamp, str(e)))
            pass


if __name__ == "__main__":
    main()
