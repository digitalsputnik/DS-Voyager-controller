import serial
import threading
import time
import PythonReceiverClass

LampSerial = serial.Serial(
                port='/dev/ttyS1',
                baudrate=750000,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1
            )

LampSerial.flushInput()
LampSerial.flushOutput()

LampPixelCount = 0

while LampPixelCount == 0:
    LampSerial.write([0xd5, 0x0a, 0x50, 0x03, 0xef, 0xfe, 0x00])
    time.sleep(0.01)
    led_amount = LampSerial.read(10)
    if (len(led_amount) > 5):
        if (led_amount[0] == 0xD5 and led_amount[1] == 0x0A and led_amount[2] == 0x50 and led_amount[3] == 0x03):
            LampPixelCount = led_amount[4]

AnimationRunner = PythonReceiverClass.PythonReceiver(LampSerial, LampPixelCount)
AnimationRunner.start()
time.sleep(600)
