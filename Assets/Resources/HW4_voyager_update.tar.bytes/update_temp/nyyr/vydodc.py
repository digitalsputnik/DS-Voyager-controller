import base64
import hashlib
import os
from subprocess import Popen, PIPE
import vyconnman


class CFileUpload_SequenceCollector:
    numberOfChunks = int()
    filePath = ""
    currentChunk = 0

    fileBuffer = {int(): bytearray()}
    fileContent = bytearray()

    def __init__(self, chunkCount, filePath):
        self.numberOfChunks = chunkCount
        self.filePath = filePath
        self.currentChunk = 0
        self.fileContent = bytearray()

    def addChunk(self, chunk, data, resend):
        """
                returns true when added chunk is accepted, false otherwise
                chunk is redjected on invalid chunk
                """
        if self.currentChunk == chunk or resend:
            self.fileBuffer[chunk] = base64.b64decode(data)

            print("%s vs %s; chunk size: %s" %
                  (chunk,
                   self.numberOfChunks,
                   len(base64.b64decode(data))))
            if chunk == self.numberOfChunks - 1:
                print("Final chunk received")
                self.fileContent = bytearray()
                for i in range(0, self.numberOfChunks):
                    self.fileContent += self.fileBuffer[i]
                print("File content size %s" % len(self.fileContent))
            elif not resend or (self.currentChunk == chunk and resend):
                self.currentChunk += 1

            return True
        else:
            return False


class CFileUpload_Handler:

    def __init__(self, connectionManager):
        self.connMan = connectionManager
        self.sequenceCollector = CFileUpload_SequenceCollector(0, "")

    def doHandle(self, packet):
        if packet is not None:
            # start sequence packet
            if "chunkCount" and "filePath" in packet.getJson():
                self.sequenceCollector = CFileUpload_SequenceCollector(
                    packet.getJson()["chunkCount"],
                    packet.getJson()["filePath"]
                )
                print("New file transfer sequence started for file %s " %
                      self.sequenceCollector.filePath)
                response = vyconnman.CJsonPacket(b'\xAB',
                                                 b'\x01',
                                                 {
                                                     'type': 'startAck',
                                                     'ack': True
                                                 },
                                                 b'\xEF\xFE')
                self.connMan.write(response)

            # chunk packet
            if "chunk" and "data" in packet.getJson():
                if self.sequenceCollector is not None:
                    ack = self.sequenceCollector.addChunk(
                        packet.getJson()["chunk"],
                        packet.getJson()["data"],
                        packet.getJson()["resend"]
                    )
                    acceptedChunk = packet.getJson()["chunk"]
                    message = ""
                    if not ack:
                        message = "Chunk mismatch (%s/%s)" % \
                                  (packet.getJson()["chunk"],
                                   self.sequenceCollector.currentChunk)
                        print(message)

                    response = vyconnman.CJsonPacket(b'\xAB',
                                                     b'\x01',
                                                     {
                                                         'type': 'chunkAck',
                                                         'ack': ack,
                                                         'message': message,
                                                         'chunk': acceptedChunk
                                                     },
                                                     b'\xEF\xFE')
                    self.connMan.write(response)

            # md5sumOK packet
            if "md5sum" in packet.getJson():
                md5sum = hashlib.md5()
                md5sum.update(self.sequenceCollector.fileContent)
                print("md5sum packet: %s vs %s" %
                      (base64.b64decode(packet.getJson()["md5sum"]),
                       md5sum.digest()))

                fileWritten = False
                message = ""
                if base64.b64decode(packet.getJson()["md5sum"]) == md5sum.digest():
                    md5valid = True
                    print("Md5 sum checks out, writing to disk")

                    try:
                        filename = self.sequenceCollector.filePath
                        if not os.path.exists(os.path.dirname(filename)):
                            os.makedirs(os.path.dirname(filename))

                        f = open(self.sequenceCollector.filePath, "w+")
                        f.write(self.sequenceCollector.fileContent.decode("utf-8"))
                        fileWritten = True
                        message = "File with size %sb written to: %s" % \
                                  (len(self.sequenceCollector.fileContent),
                                   self.sequenceCollector.filePath)
                        print(message)
                    except IOError as e:
                        fileWritten = False
                        message = "Failed to write file: '%s'" % e
                        print("CFileUpload_Handler exception: %s" % str(e))
                    except OSError as exc:  # Guard against race condition
                        fileWritten = False
                        message = "Failed to create path to file: '%s'" % exc
                        print("CFileUpload_Handler exception: %s" % message)
                else:
                    md5valid = False
                    print("Invalid Md5sum")

                response = vyconnman.CJsonPacket(b'\xAB',
                                                 b'\x01',
                                                 {
                                                     'type': 'md5sumAck',
                                                     'ack': md5valid and fileWritten,
                                                     'message': message
                                                 },
                                                 b'\xEF\xFE')
                self.connMan.write(response)

            else:
                print("File upload CRC Invalid")

    def doStartSequence(self):
        return


class CShellCommand_Handler:
    def __init__(self, connectionManager):
        self.connMan = connectionManager

    def doHandle(self, packet):
        if packet is not None:
            print("Shell command: %s" % packet.getbytearray())
            if "shellCall" in packet.getJson():
                shellCall = packet.getJson()["shellCall"]
                if len(shellCall) > 0:
                    print("Performing shell call: %s" % shellCall)
                    p = Popen(shellCall, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE, cwd="/")
                    output, err = p.communicate(b"input data that is passed to subprocess' stdin")
                    rc = p.returncode
                    if rc == 0:
                        print("Output: %s" % output)
                    else:
                        print("Error: %s" % err)

                    self.writeShellResponse(rc, output, err)

    def writeShellResponse(self, returnCode, standardOutput, standardError):
        response = vyconnman.CJsonPacket(b'\xAB',
                                         b'\x00',
                                         {
                                             'returnCode': str(int(returnCode)),
                                             'stdout': base64.b64encode(standardOutput).decode("utf-8"),
                                             'stderr': base64.b64encode(standardError).decode("utf-8"),
                                         },
                                         b'\xEF\xFE')
        self.connMan.write(response)
