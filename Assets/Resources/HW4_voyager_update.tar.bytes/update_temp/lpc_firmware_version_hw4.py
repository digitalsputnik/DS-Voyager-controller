import time
import serial

toHex = lambda x: " ".join("{:02X}".format(c) for c in x)

ser = serial.Serial(
	port='/dev/ttyAMA0',
	baudrate=1500000,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	rtscts=False,
	timeout=0
)

ser.flushInput()
ser.flushOutput()

firmware_version = [0xd5, 0x0a, 0x30, 0x01, 0x20, 0xef, 0xfe, 0x37]

ser_received_data = []
for i in range(50):
	ser_received_data.append(0)

for n in range (0, 2):
	ser.write(firmware_version[:len(firmware_version)])
	time.sleep(0.1)
	
	ser_received_data = (ser.read(24))
		
	start_flag1 = ser_received_data[0:1]
	start_flag1 = int.from_bytes(start_flag1, byteorder = 'big')
	start_flag2 = ser_received_data[1:2]
	start_flag2 = int.from_bytes(start_flag2, byteorder = 'big')
	packet_definition1 = ser_received_data[2:3]
	packet_definition1 = int.from_bytes(packet_definition1, byteorder = 'big')
	packet_definition2 = ser_received_data[3:4]
	packet_definition2 = int.from_bytes(packet_definition2, byteorder = 'big')

	if  start_flag1 == 0xD5 and start_flag2 == 0x0A and packet_definition1 == 0x30 and packet_definition2 == 0x01:
		firmware_ver = ser_received_data[5:7]
		firmware_ver = int.from_bytes(firmware_ver, byteorder = 'big')
		print('Firmware version ' + str(firmware_ver) + '.')
		break
	elif n == 1:
		print('Firmware version unknown.')

ser.close()
exit()
