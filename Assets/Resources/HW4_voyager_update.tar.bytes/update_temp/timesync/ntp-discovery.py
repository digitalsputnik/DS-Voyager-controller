import json
import netifaces
import os
import select
import socket
import sys
import threading
import time
import uuid

# Announcer options
ANNOUNCE_TIMEOUT = 6
ANNOUNCE_INTERVAL = 1
UDP_ANNOUNCE_IP = '<broadcast>'
UDP_ANNOUNCE_PORT = 51259
NETWORK_MODE_FILE = "/mnt/data/network_mode"
VOYAGERSYNC_PROTOCOL_VERSION = 0.02

# Network interface names. Ntp-Discovery will try to use the first one, if unavailable goes to second and so on
NETWORK_INTERFACES = tuple(("wlan0", "wlan1", "wlp5s0"))

# Chrony-specific options - locations for CHIP PRO (see man chrony)
CHRONYC_LOCATION = "/opt/free/bin/chronyc"
CHRONYD_LOCATION = "/opt/free/sbin/chronyd"
CHRONY_CONFIG_LOCATION = "/mnt/data/timesync/chrony.conf"

# Chrony adjusts NTP polling rate automatically, MINPOLL and MAXPOLL set upper and lower limits of refresh rate
MINPOLL = "-1"  # 2^-1 seconds
MAXPOLL = "7"  # 2^7 seconds
MAXDELAY = "1"
MAXDELAYRATIO = "10"

class NtpDiscovery:
    class NtpServerRecord:
        def __init__(self, synced, priority1, clock_quality, priority2, uuid):
            # Priority flags. Higher values mean higher priority
            self.synced_to_current_network = synced  # synced to current network
            self.priority1 = priority1  # used to differentiate between controller, access point host, regular lamp
            self.clockQuality = clock_quality  # currently unused
            self.priority2 = priority2  # currently unused
            self.uuid = uuid

            # Version number for future backwards-compatibility features
            self.voyagersync_version = VOYAGERSYNC_PROTOCOL_VERSION

    def __init__(self):
        # find local IP for outbound UDP interface mapping
        try:
            self.local_ip = find_host_ip()
            print("HOST IP for outbound UDP socket mapping: " + self.local_ip)
        except ConnectionError:
            print(
                "HOST IP for outbound UDP socket mapping not found. Check if network link up and interface added to NETWORK_INTERFACES")
            return

        try:
            # check if we are AP. AP host has higher priority because lower ping means higher ntp accuracy
            if running_on_access_point():
                priority1 = 10
            else:
                priority1 = 5

            # create server record of host running the script, set current master server to localhost
            self.local_record = self.NtpServerRecord(0, priority1, 10, 10, int(uuid.uuid4()))
            self.current_master_record = self.local_record
            self.current_master_ip = self.local_ip

            # master flag. This is set to False every time we receive an announce from a master server better than
            # localhost
            self.weAreMaster = False

            # start announcer thread
            self.lock = threading.Lock()
            self.run_announcer_thread = True
            self.announcer_thread = threading.Thread(target=self.announcer)
            self.announcer_thread.daemon = True
            self.announcer_thread.start()

            # open receive socket for announce handler
            try:
                sock_rcv = socket.socket(socket.AF_INET,  # Internet
                                         socket.SOCK_DGRAM)  # UDP
                sock_rcv.bind((UDP_ANNOUNCE_IP, UDP_ANNOUNCE_PORT))
                sock_rcv.setblocking(False)
            except OSError as e:
                print("Opening receive socket failed" + str(e))
                return

            # start announce handler
            while self.announcer_thread.isAlive():
                try:
                    select.select([sock_rcv], [], [], 0.5)
                    data, addr = sock_rcv.recvfrom(4096)
                    new = self.decodeAnnounce(data)
                    if new.voyagersync_version:  # Very simple validation - check whether version value exists
                        self.handle_announce(new, addr[0])
                    else:
                        print("Received announce did not include voyagersync_version. Discarding")
                except BlockingIOError:
                    continue
                except socket.timeout:
                    continue
                except (json.JSONDecodeError) as e:
                    print("Received announce decoding error: " + str(e))
                except OSError as e:
                    print("Reading from receive socket failed: " + str(e))
                    self.run_announcer_thread = False
                    chrony_remove_server(self.current_master_ip)
                    return
                except Exception as e:
                    print(e.__doc__)
                    print("Received announce error: " + str(e))

        except (KeyboardInterrupt, SystemExit) as e:
            print(e)
            raise e
        except Exception as e:
            return
        finally:
            # Clean-up
            self.run_announcer_thread = False
            self.announcer_thread.join(ANNOUNCE_TIMEOUT)

    def handle_announce(self, proposed_master, proposed_master_ip):
        try:
            self.lock.acquire()

            # Announce from self - ignore
            if self.local_record.uuid == proposed_master.uuid:
                return

            # Announce from current master - reset announce timeout
            if proposed_master.uuid == self.current_master_record.uuid:
                self.weAreMaster = False

            # Announce from better master - replace current master
            elif which_ntp_server_better(self.current_master_record, proposed_master):
                self.weAreMaster = False
                chrony_remove_server(self.current_master_ip)
                self.current_master_record = proposed_master
                self.current_master_ip = proposed_master_ip
                chrony_add_server(proposed_master_ip)

                # Initial sync (only on first iteration).
                if self.local_record.synced_to_current_network == 0:
                    # Sleep a bit for initial sync to complete
                    print("Using server " + proposed_master_ip + " for initial sync")
                    time.sleep(ANNOUNCE_TIMEOUT)
                    print("Current time after inital sync: " + time.ctime())
                    # Check if master still better than us after initial sync has been completed
                    self.local_record.synced_to_current_network = 1
                    if which_ntp_server_better(self.current_master_record, self.local_record):
                        self.current_master_record = self.local_record
        finally:
            self.lock.release()

    def announcer(self):
        # Open announce socket
        sock_send = socket.socket(socket.AF_INET,  # Internet
                                  socket.SOCK_DGRAM)  # UDP
        sock_send.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)  # enable broadcast functionality
        sock_send.bind((self.local_ip, 0))  # Bind correct network interface

        while self.run_announcer_thread:
            self.lock.acquire()
            if self.weAreMaster is True:
                if firstAnnounce: # Transistion from slave to master
                    firstAnnounce = False
                    chrony_remove_server(self.current_master_ip)

                    # We are master, therefore synced to current network
                    self.local_record.synced_to_current_network = 1
                    self.current_master_record = self.local_record
                    self.current_master_ip = self.local_ip
                try:
                    sock_send.sendto(self.encodeAnnounce(self.local_record).encode(),
                                     (UDP_ANNOUNCE_IP, UDP_ANNOUNCE_PORT))
                    print("Sending announce")
                except OSError:
                    print("Announce transmit failed, stopping announce service")
                    sock_send.close()
                    return
                self.lock.release()
                time.sleep(ANNOUNCE_INTERVAL)
            else:
                firstAnnounce = True
                if self.local_record.synced_to_current_network == 0:
                    print(
                        "Waiting " + str(ANNOUNCE_TIMEOUT) + " seconds for initial sync. Initial time: " + time.ctime())
                self.weAreMaster = True
                self.lock.release()
                time.sleep(ANNOUNCE_TIMEOUT)

    def encodeAnnounce(self, data):
        return json.dumps(tuple((data.synced_to_current_network, data.priority1, data.clockQuality, data.priority2,
                                 data.uuid, data.voyagersync_version, "VoyagerSync")))

    def decodeAnnounce(self, data):
        print(data)
        data = json.loads(data.decode('utf-8'))
        if (data[6] == "VoyagerSync"):
            return self.NtpServerRecord(data[0], data[1], data[2], data[3], data[4])
        else:
            raise TypeError("Could not decode: packet does not contain VoyagerSync string")


def running_on_access_point():
    try:
        with open(NETWORK_MODE_FILE) as f:
            if f.readline().strip() == "ap_mode":
                return True
            else:
                return False
    # File not found
    except OSError:
        return False


def find_host_ip():
    for var in NETWORK_INTERFACES:
        try:
            if len(netifaces.ifaddresses(var)) >= 3:
                return netifaces.ifaddresses(var)[2][0]['addr']
        except ValueError:
            continue

    # Did not find host ip
    raise ConnectionError


def which_ntp_server_better(current, new):
    return tuple((current.synced_to_current_network, current.priority1, current.clockQuality, current.priority2,
                  current.uuid)) < tuple(
        (new.synced_to_current_network, new.priority1, new.clockQuality, new.priority2, new.uuid))


def chrony_add_server(ip):
    # Should add chronyc reply "511 Source already present" handling
    # kill_chrony()
    # start_chrony()
    print(
        "ADDING SERVER TO CHRONY:  " + CHRONYC_LOCATION + " add server " + ip + " minpoll " + MINPOLL + " maxpoll " + MAXPOLL + " trust polltarget 6")
    os.system(
        CHRONYC_LOCATION + " add server " + ip + " minpoll " + MINPOLL + " maxpoll " + MAXPOLL + " maxdelay " + MAXDELAY + " maxdelayratio " + MAXDELAYRATIO + " polltarget 6")


def chrony_remove_server(ip):
    print(
        "REMOVING CHRONY SERVER: " + ip)
    os.system(
        CHRONYC_LOCATION + " delete " + ip)


def chrony_stop_sync():
    os.system(CHRONYC_LOCATION + " offline 0.0.0.0/0.0.0.0")
    print("Chrony offline")


def kill_chrony():
    print("KILLING CHRONYD: killall chronyd")
    os.system("killall chronyd ") # Chip Pro
    os.system("pkill chronyd ") # Artik


def start_chrony():
    print("STARTING CHRONYD: " + CHRONYD_LOCATION + " -f " + CHRONY_CONFIG_LOCATION)
    os.system(CHRONYD_LOCATION + " -f " + CHRONY_CONFIG_LOCATION)


if __name__ == '__main__':
    try:
        kill_chrony()
        start_chrony()
        while True:
            sync_process = NtpDiscovery()
            # Normally, NtpDiscovery() will never return. If this happens, we will wait for a few seconds and restart
            print("Restarting service after " + str(ANNOUNCE_TIMEOUT) + " seconds\n")
            time.sleep(ANNOUNCE_TIMEOUT)
    except (KeyboardInterrupt, SystemExit) as e:
        kill_chrony()
        print("Received stop signal")
        sys.exit()
