import serial
import time

toHex = lambda x: " ".join("{:02X}".format(c) for c in x)

ser = serial.Serial(
	port='/dev/ttyAMA0',
	baudrate=1500000,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	rtscts=False,
	timeout=0
)

ser.flushInput()
ser.flushOutput()

ser_received_data = []
for i in range(50):
        ser_received_data.append(0)

#=======================================================
# DISABLE shutdown for 30 seconds
#=======================================================
packet = [0xD5, 0x0A, 0x50, 0x08, 0x30, 0x03, 0x1E, 0xEF, 0xFE, 0x00]
ser.write(packet)
time.sleep(0.5)
ser_received_data = (ser.read(46))
print(toHex(ser_received_data))

ser.close()
exit()
