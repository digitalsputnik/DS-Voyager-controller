#!/bin/bash

LOCATION=/mnt/data/
TIMEOUT=10
PASSWORD=dsputnik

SSID_FILTER='\<DS026.........._M\>'
#SSID_FILTER=$SSID_FILTER'\|''\<voyager_......_M\>'

#remove old before adding new confs
#ls /var/lib/connman/*| grep -v settings| xargs rm -rf

#kill client connection attempt.. might be easier way to timeout.
#timeout_monitor() {
	#sleep "$TIMEOUT"
	#ps ax | grep connmanctl | grep -v grep | awk -F ' ' '{print $1}' | xargs kill -9
	#kill "$1"
	#ls /var/lib/connman/*| grep -v settings| xargs rm -rf
	#timeout_monitor "$$" &
	#Timeout_monitor_pid=$!
#}
#timeout_monitor "$$" &
#Timeout_monitor_pid=$!

#old implementation from reading multiple ssids from 
#Makes searchable string from ssidlist.txt, ignores empty lines

number_of_APs=$(wc -l < $LOCATION'ssidlist.txt')
while [ $number_of_APs -gt 0 ]
do
	read_ssid=$(awk NR==$number_of_APs $LOCATION'ssidlist.txt' | cut -d "\"" -f 2)
	if [ "$read_ssid" != "" ]; then
		#SSID_FILTER=$SSID_FILTER'\|'$read_ssid
		read_ssid=$read_ssid
	fi
	number_of_APs=$(($number_of_APs-1))
done

while true
do
	#rawscan=$(iwlist wlan0 scan | grep "Quality\|ESSID" | awk '{ ORS = (NR%2 ? FS : RS) } 1' )

	#echo $rawscan
	
	#first priority from ssidlist
	#rawscan=$(nice -18 iwlist wlan1 scan | grep "Quality\|ESSID" | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $3, $5}' | sort -n | grep -w  $read_ssid)
	#signal_level=$(echo $rawscan | awk '{print $1}' | cut -d "-" -f 2)
	#ssid=$(echo $rawscan | awk -F'["]' 'NR==1{print $2}')
	#rawscan=$(nice --19 iw dev wlan0 scan | grep "SSID:\|signal:" | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $2, $5, $6, $7}' | grep -w $read_ssid)
	#signal_level=$(echo $rawscan | awk '{print $1}' | cut -d "-" -f 2 | cut -d "." -f1)

     	rawscan=$(echo -e "$(nice --19 iwlist p2p0 scan | grep "SSID:\|level:-" | grep -Eo '".*"'\|'Signal level:-...' | awk '{ ORS = (NR%2 ? FS : RS) } 1')" | grep -w "$read_ssid")
	signal_level=$(echo "$rawscan" | cut -d "\"" -f 3 | cut -d "-" -f 2)
	ssid=$(echo "$rawscan" | grep -Eo '".*"' | tr -d '"' )
	echo "rawscan: $rawscan"
        echo "ssid: $ssid"
        echo "signal level: $signal_level"
	
	#ssid with spaces in names... reads only first string atm. otherwise adds spaces to ending
	#ssid=$(echo $rawscan | awk 'NR==1{print $2, $3, $4}')
	#ssid=$(echo $rawscan | awk 'NR==1{print $2}')
	
	#echo $read_ssid
	#ssid=$(nice -12 iwlist wlan0 scan | grep "Quality\|ESSID" | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $3, $5}' | sort -n | grep -w $read_ssid | awk -F'["]' 'NR==1{print $2}')
	#ssid=$(echo $rawscan | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $3, $5}' | sort -n | grep -w $read_ssid | awk -F'["]' 'NR==1{print $2}')
	#echo $ssid
	#echo $signal_level
	
	#second priority from classic _M
	if [ "${#ssid}" -lt 1 ]; then
		echo "Search for _M"
		#sleep 5
		#ssid=$(nice -12 iw dev wlan0 scan | grep "SSID:\|signal:" |awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $2, $5, $6, $7}' | grep $SSID_FILTER | awk 'NR==1{print $2, $3, $4}')
		#ssid=$(echo $rawscan | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $3, $5}' | sort -n | grep -w  $SSID_FILTER | awk -F'["]' 'NR==1{print $2}')
		#echo "2nd"
		#echo $ssid
		rawscan=$(echo -e "$(nice --19 iwlist p2p0 scan | grep "SSID:\|level:-" | grep -Eo '".*"'\|'Signal level:-...' | awk '{ ORS = (NR%2 ? FS : RS) } 1')" | grep -w "$SSID_FILTER")
	 	signal_level=$(echo "$rawscan" | cut -d "\"" -f 3 | cut -d "-" -f 2)
		ssid=$(echo "$rawscan" | grep -Eo '".*"' | tr -d '"' )
                echo "rawscan: $rawscan"
		echo "ssid: $ssid"
		echo "signal level: $signal_level"
		
	
		#rawscan=$(nice --19 iw dev wlan0 scan | grep "SSID:\|signal:" | awk '{ ORS = (NR%2 ? FS : RS) } 1' | awk '{print $2, $5, $6, $7}' | grep -w $SSID_FILTER)
		#ssid=$(echo $rawscan | awk 'NR==1{print $2}')
		#signal_level=$(echo $rawscan | awk '{print $1}' | cut -d "-" -f 2 | cut -d "." -f1)
		
	fi
	
	### MAIN CONNECTION LOOP ###
	#if [[  "${#ssid}" -gt 1  && "$signal_level" -lt 80 ]]; then
	if [[  "${#ssid}" -gt 0  && "$signal_level" -lt 80 ]]; then
		#echo "connection loop"
		#check if SSID is from ssidlist.txt document and sets the password from there
		
		password_temp=$(cat $LOCATION'ssidlist.txt' | grep -w "$ssid" | cut -d "\"" -f 3 | cut -c 2-)
		ssid_temp=$(cat $LOCATION'ssidlist.txt' | grep -w "$ssid" | cut -d "\"" -f 2)

		#not listed in ssidlist file, default "dsputnik" password
		if [ "$ssid_temp" == "" ]; then
			PASSWORD=$PASSWORD
		#listed in file, not empty password
		elif [ "$password_temp" != "" ]; then
			PASSWORD=$password_temp
		elif [ "$password_temp" == "" ]; then
			PASSWORD="NONE"
		fi

		#wpa supplicant connection start
		sed -i --follow-symlinks "/ssid=/c\	ssid=\"$ssid"\" /etc/wpa_supplicant/wpa_supplicant.conf
		
		#password for no password connections
		if [ "$PASSWORD" == "NONE" ]; then
			sed -i --follow-symlinks "/psk=/c\	key_mgmt=NONE" /etc/wpa_supplicant/wpa_supplicant.conf
			sed -i --follow-symlinks "/key_mgmt=/c\	key_mgmt=NONE" /etc/wpa_supplicant/wpa_supplicant.conf
		else
			sed -i --follow-symlinks "/psk=/c\	psk=\"$PASSWORD"\" /etc/wpa_supplicant/wpa_supplicant.conf
			sed -i --follow-symlinks "/key_mgmt=/c\	psk=\"$PASSWORD"\" /etc/wpa_supplicant/wpa_supplicant.conf
		fi
		
		
		sleep 0.1
		
		systemctl restart wpa_supplicant
		pkill dhclient
		sleep 4
		dhclient &
		
		
		#chip connman
		#connmanctl scan wifi
		#get hash from connmanctl, filters by given ssid and looking for start: "wifi_"
		#hash=$(connmanctl services | grep -w $ssid | grep -o '\bwifi_\w*')
		
		#New conf
		#cat << EOF > /var/lib/connman/$ssid-psk.config
		#[service_$hash]
		#Type = wifi
		#Name = $ssid
		#Passphrase = $PASSWORD
		#EOF

		#sleep 1.3
		#connmanctl config $hash --autoconnect off > /dev/null
		#connmanctl connect $hash > /dev/null &
		#sleep 5
		#ps ax | grep connmanctl | grep -v grep | awk -F ' ' '{print $1}' | xargs kill -9
		
		
		
		counter_ping=0
		#As soon as get IP or loop 10 cycles
		while [ $counter_ping -lt 10 ]
		do
			if ping -c 1 -I wlan0 $(ip route | awk 'NR==1{print $3}') > /dev/null; then	
				#echo "connection ok!"
				counter_ping=0
				sleep 5
				
				
			fi
			sleep 2
			
			counter_ping=$(($counter_ping+1))
		done
		#connection fail
		
	fi
	sleep 15
done
