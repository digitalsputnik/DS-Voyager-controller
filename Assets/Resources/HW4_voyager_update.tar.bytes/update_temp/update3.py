#Main update script for  Voyager ARTIK and LPC. Andro 18.07.2018

### IMPORTANT ###

#from svn autorun_regularboot.sh 
#to generate md5sum file on artik, make sure no checklist file exists :
#md5sum /mnt/data/update_temp/* > /mnt/data/update_temp/checklist.chk ; md5sum /mnt/data/update_temp/nyyr/* >> /mnt/data/update_temp/checklist.chk
#UPDATE LPC VERSION NUMBER!


import time
import os
import sys
import serial

reboot_needed = 0
NEW_VERSION = 209

def active_mode():
	time.sleep(1)
	ser = serial.Serial(
		port='/dev/ttyAMA0',
		baudrate=1500000,
		parity=serial.PARITY_NONE,
		stopbits=serial.STOPBITS_ONE,
		bytesize=serial.EIGHTBITS,
		rtscts=False,
		timeout=0
	)
	
	ser.flushInput()
	ser.flushOutput()
	ser.write([0xD5, 0x0A, 0x50, 0x09, 0x30, 0x04, 0xEF, 0xFE, 0x57])
	ser.close()


os.system("chmod 777 /mnt/data/mxli")
#3rd final check before update that device is ARTIK
cpu_hardware = os.popen("cat /proc/cpuinfo | grep Hardware | awk '{print $3, $4, $5}'").readline().strip()
if cpu_hardware != "s5p4418":
	print ("WRONG HARDWARE" + cpu_hardware )
	sys.exit(1)

#Kill processes using ttyAMA0
os.system("kill -9 $(ps ax | grep vymain.py | grep -v grep |awk 'NR==1{print $1}') 2> /dev/null")

#Just in case if multiple apps should start updating one voyager simultaneously
ps = os.popen("ps ax | grep -v grep | grep update3.py | wc -l").read().strip()
if int(ps) > 1:
	print ("UPDATE RUNNING ALREADY")
	sys.exit(1)

###MOVING FILES. ARTIK UPDATES###

#pre copy check md5sum
if "FAILED" in os.popen("md5sum  -c /mnt/data/update_temp/checklist.chk 2> /dev/null ").read().strip():
	print ("Pre copy MD5SUM FAIL")
	sys.exit()

#rename autorun and in checklist
os.system("sed -i 's/autorun_regularboot.sh/autorun.sh/g' /mnt/data/update_temp/checklist.chk")
os.system("mv /mnt/data/update_temp/autorun_regularboot.sh /mnt/data/update_temp/autorun.sh")

# remove old timesync implementation
os.system("rm -rf /mnt/data/timesync_router.py")
os.system("rm -rf /mnt/data/timesync_service.py")

# new move system to merge folders without removal
os.system("cp -r /mnt/data/update_temp/* /mnt/data/; sync; sync")
os.system("rm -rf /mnt/data/update_temp/*")

time.sleep(0.1)
os.system("sed -i 's#update_temp/##g' /mnt/data/checklist.chk")

time.sleep(0.4)
# post copy md5sum
if "FAILED" in os.popen("md5sum  -c /mnt/data/checklist.chk 2> /dev/null ").read().strip():
	print ("Post copy MD5SUM FAIL")
	os.system("setsid python3 /mnt/data/nyyr/vymain.py >> /dev/null 2>&1 &")
	sys.exit()

	
#update ssidlist.txt to include "" in name
try:
	ssid_quote_test = os.popen("cat /mnt/data/ssidlist.txt | awk '{print $1}' ").readline().strip()
	if ssid_quote_test[0] != '"':
		password_quote = os.popen("cat /mnt/data/ssidlist.txt | awk '{print $2}' ").readline().strip()
		pattern = '"'+ssid_quote_test+'"' + " " + password_quote + "\n"
		with open("/mnt/data/ssidlist.txt", "w") as f:
			f.write(pattern)
			os.fsync(f)
except:
	with open("/mnt/data/ssidlist.txt", "w") as f:
		f.write('"voyager_router" dsputnik')
		os.fsync(f)

	
###LPC###

#Tries to flash twice, if fails 1st.
try:
	lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version_hw4.py").readline().strip()[-3:]
	#LPC MAIN FLASHING
	if int(lpc_version) < NEW_VERSION:
		
		#disable shutdown button for 30s
		os.system("python3 /mnt/data/aux_disable_shutdown_30_sec.py")

		#flashing new soft
		os.system("sh /mnt/data/lpc_firmware_update_hw4.sh /mnt/data/voyager_lpc_release_user_update.bin > /dev/null 2> /dev/null")
		time.sleep(0.2)
		
		lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version_hw4.py").readline().strip()[-3:]
		#print ("LPC VERSION:", int(lpc_version))
		#reboot_needed = 1 #not needed since 173
		active_mode()
except:
	os.system("sh /mnt/data/lpc_firmware_update_hw4.sh /mnt/data/voyager_lpc_release_user_update.bin  > /dev/null 2> /dev/null")
	try:
		lpc_version = os.popen("python3 /mnt/data/lpc_firmware_version_hw4.py").readline().strip()[-3:]
		#print ("LPC VERSION:", int(lpc_version))
		#reboot_needed = 1 #not needed since 173
		active_mode()
		
	except:
		print ("FAIL. LPC NEEDS REFLASHING")
		os.system("setsid python3 /mnt/data/nyyr/vymain.py >> /dev/null 2>&1 &")
		sys.exit()


if reboot_needed == 1:
	print ("UPDATE SUCCESSFUL, REBOOT NEEDED")
else:
	print ("UPDATE SUCCESSFUL")


### RELAUNCH processes ###

os.system("setsid python3 /mnt/data/nyyr/vymain.py >> /dev/null 2>&1 &")

#kill old timesync
os.system("kill -9 $(ps ax | grep timesync_service | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")
os.system("kill -9 $(ps ax | grep timesync_router | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")

#restart ntp timesync
os.system("kill -9 $(ps ax | grep ntp-discovery | grep -v grep | awk 'NR==1{print $1}') 2> /dev/null")
os.system("python3 /mnt/data/timesync/ntp-discovery.py >> /dev/null 2>&1 &")
