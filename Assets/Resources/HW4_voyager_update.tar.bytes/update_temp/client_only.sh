systemctl stop hostapd
systemctl stop dnsmasq

ifconfig wlan0 0.0.0.0 up

#sleep 8

systemctl restart wpa_supplicant
sleep 4
dhclient &

sh /mnt/data/connect_cm_v2.sh &
