systemctl stop wpa_supplicant

#stop dhclient
pkill dhclient
ifconfig wlan0 0.0.0.0 
ifconfig wlan0 172.20.0.1/24 up

systemctl restart dnsmasq
sleep 1
systemctl stop hostapd
sleep 1
systemctl start hostapd
