#!/bin/sh

# TODO: necessary?
# stty -F /dev/ttyAMA3 -crtscts                 # Release CTS & DTR pins

# ENTER ISP MODE

echo 43 > /sys/class/gpio/export               	# Export ISP pin. 
echo out > /sys/class/gpio/gpio43/direction    	# ISP pin output
echo 0 > /sys/class/gpio/gpio43/value          	# Set ISP pin low

sleep .2                                        # Wait .2 sec
echo 50 > /sys/class/gpio/export                # Export RESET pin
echo out > /sys/class/gpio/gpio50/direction     # RESET pin output
echo 0 > /sys/class/gpio/gpio50/value           # Set RESET pin low.

sleep .2                                        # Wait .2 sec
echo 1 > /sys/class/gpio/gpio50/value           # Set RESET pin high. LPC15xx goes to UART ISP mode.

rm /mnt/data/bllpcflashlog						# ???
rm /mnt/data/lpcflashlog						# ???

# Flash LPC1549 bootloader

echo "Flashing bootloader"
/mnt/data/mxli -N LPC1549 -A0x00000000 -B256,512,1024,4096 -F4kix64 -M3ki@0x2000000 -I0x00001549 -P BINARY -S8@7 -f256ki -v -E -d /dev/ttyAMA3 $1 # 2>> /mnt/data/bllpcflashlog
echo "Flashing bootloader complete"

echo 0 > /sys/class/gpio/gpio50/value           # Set RESET pin low.
sleep .2                                        # Wait .2 sec
echo 1 > /sys/class/gpio/gpio50/value           # Set RESET pin high. LPC15xx goes to UART ISP mode.

# Flash LPC1549 main program

echo "Flashing default main program"
/mnt/data/mxli -N LPC1549 -A0x00000000 -B256,512,1024,4096 -F4kix64 -M3ki@0x2000000 -I0x00001549 -P BINARY -S8@7 -f256ki -a 0x4000 -v -E -d /dev/ttyAMA3 $2 # 2>> /mnt/data/lpcflashlog
echo "Flashing default main program complete"

# EXIT ISP MODE

sleep .2                                       	# Wait .2 sec
echo 1 > /sys/class/gpio/gpio43/value          	# Set ISP pin high. Next LPC15xx reset leads to normal boot process.
sleep .2                                        # Wait .2 sec
echo 0 > /sys/class/gpio/gpio50/value           # Set RESET pin low.
sleep .2                                        # Wait .2 sec
echo 1 > /sys/class/gpio/gpio50/value          	# Set RESET pin high.

echo 43 > /sys/class/gpio/unexport          	# Unexport ISP pin
echo 50 > /sys/class/gpio/unexport              # Unexport RESET pin

python3 /mnt/data/lpc_firmware_version_hw4.py	# Read LPC1549 firmware version