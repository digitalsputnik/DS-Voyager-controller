### set network mode
network_mode=$(cat /mnt/data/network_mode)
if [ "$network_mode" == "client_mode" ] ; then
	(sleep 3; sh /mnt/data/client_only.sh )&
	echo 0 > /mnt/data/timesyncflag
else
	#dirty fix to enable p2p0 scan while in AP mode
	(sleep 4; dhclient & sleep 2 ; pkill dhclient ) &
	echo 1 > /mnt/data/timesyncflag
fi

# Check if hostapd.conf configuration file exists
hostapd_line_check=$(wc -l < /mnt/data/sysln/etc/hostapd/hostapd.conf)
if [[ ! -f /mnt/data/sysln/etc/hostapd/hostapd.conf || "$hostapd_line_check" -lt  2 ]]; then
	#hostapd conf file not empty
	cp /etc/hostapd/hostapd.conf.original /mnt/data/sysln/etc/hostapd/hostapd.conf

	#ssid changed backup name. otherwise keeps original.
	if [ ! -f /mnt/data/active_ssid.txt ]; then
        	active_ssid_line_check=0
        else
	        active_ssid_line_check=$(wc -l < /mnt/data/active_ssid.txt)
        fi
	
	if [ "$active_ssid_line_check" -gt 1 ]; then
		ssid=$(cat /mnt/data/active_ssid.txt | awk 'NR==1')
		password=$(cat /mnt/data/active_ssid.txt | awk 'NR==2')
		sed -i "4 s/.*/ssid=$ssid/" /etc/hostapd/hostapd.conf
		sed -i "/wpa_passphrase=/c\wpa_passphrase=$password" /etc/hostapd/hostapd.conf
	fi
fi

if [ ! -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
	cp /etc/wpa_supplicant/wpa_supplicant.conf.original /mnt/data/sysln/etc/wpa_supplicant/wpa_supplicant.conf
fi 



# Check if wpasupplicant configuration file exists


### scripts
python3 /mnt/data/nyyr/vymain.py >> /dev/null 2>&1 &
#temp timesync solution
python3 /mnt/data/timesync_service.py &

