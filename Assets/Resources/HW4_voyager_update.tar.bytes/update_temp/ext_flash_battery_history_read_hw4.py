import time
import serial

k_to_c = 2732
toHex = lambda x: " ".join("{:02X}".format(c) for c in x)

ser = serial.Serial(
		port='/dev/ttyAMA0',
		baudrate=1500000,          # 115200 in versions v0.00.1 - v0.02.0. 750000 from version v0.02.1 o$
		parity=serial.PARITY_NONE,
		stopbits=serial.STOPBITS_ONE,
		bytesize=serial.EIGHTBITS,
		rtscts=False,
		timeout=0               # Rx timeout, debugging only, adds delay. Defau
)

ser.flushInput()
ser.flushOutput()

DS_VOYAGER_START_FLAG = 0xD50A
DS_VOYAGER_START_FLAG_MSB = 0xD5
DS_VOYAGER_START_FLAG_LSB = 0x0A

DS_VOYAGER_CONTROL_COLORS = 0x10
DS_VOYAGER_CONTROL_COLORS_8BIT_SET_INSTANT_FULL_BUFFER = 0x03
DS_VOYAGER_CONTROL_ITSH_8BIT_SET_INSTANT_FULL_BUFFER = 0x04		# added back: v0.04.6
DS_VOYAGER_CONTROL_ITSH_16BIT_SET_INSTANT_FULL_BUFFER = 0x05	# added back: v0.04.6
DS_VOYAGER_CONTROL_ITSHA_8BIT_SET_INSTANT_FULL_BUFFER = 0x06
DS_VOYAGER_CONTROL_ITSHA_16BIT_SET_INSTANT_FULL_BUFFER = 0x07

DS_VOYAGER_CALIBRATE_COLORS = 0x11
DS_VOYAGER_CALIBRATE_COLORS_SET_LUT = 0x01
DS_VOYAGER_CALIBRATE_COLORS_SET_LUT_REPLY = 0x02
DS_VOYAGER_CALIBRATE_COLORS_GET_LUT = 0x03
DS_VOYAGER_CALIBRATE_COLORS_GET_LUT_REPLY = 0x04

DS_VOYAGER_BATTERY = 0x20
DS_VOYAGER_BATTERY_STATUS = 0x01
DS_VOYAGER_BATTERY_SBS_COMMAND = 0x02
DS_VOYAGER_BATTERY_PERIODIC_SBS_COMMUNICATION = 0x03

DS_VOYAGER_LPC_FIRMWARE = 0x30
DS_VOYAGER_LPC_FIRMWARE_VERSION = 0x01
DS_VOYAGER_LPC_FIRMWARE_UPDATE = 0x02

DS_VOYAGER_EXT_FLASH = 0x40										# v0.07.0
DS_VOYAGER_EXT_FLASH_BAT_LOG = 0x01								# v0.07.0
DS_VOYAGER_EXT_FLASH_TIME = 0x02								# v0.07.0

READ_COMMAND = 0x20
READ_COMMAND_RESPONSE = 0x21
WRITE_COMMAND = 0x30
WRITE_COMMAND_RESPONSE = 0x31

END_FLAG = 0xEFFE
END_FLAG_MSB = 0xEF
END_FLAG_LSB = 0xFE

sector_msb = 0
sector_lsb = 4
page = 0
data_length = 0
crc8 = 0x00

battery_log_slot_size = 16

packet_rx = []

for i in range(300):
    packet_rx.append(0)

while sector_lsb < 18:
	if(sector_lsb < 18):
		packet_tx = [DS_VOYAGER_START_FLAG_MSB, 
				DS_VOYAGER_START_FLAG_LSB, 
				DS_VOYAGER_EXT_FLASH, 
				DS_VOYAGER_EXT_FLASH_BAT_LOG, 
				READ_COMMAND, 
				data_length, 
				sector_msb, 
				sector_lsb, 
				page, 
				END_FLAG_MSB, 
				END_FLAG_LSB, 
				crc8]
				
		print(packet_tx)
		
		ser.write(packet_tx[:len(packet_tx)])
		time.sleep(0.3)

		packet_rx = (ser.read(300))

		start_flag1 = int.from_bytes(packet_rx[0:1], byteorder = 'big')
		start_flag2 = int.from_bytes(packet_rx[1:2], byteorder = 'big')
		packet_definition1 = int.from_bytes(packet_rx[2:3], byteorder = 'big')
		packet_definition2 = int.from_bytes(packet_rx[3:4], byteorder = 'big')
		command_class_rx = int.from_bytes(packet_rx[4:5], byteorder = 'big')
		error_code_rx = int.from_bytes(packet_rx[5:6], byteorder = 'big')
		sector_msb_rx = int.from_bytes(packet_rx[6:7], byteorder = 'big')
		sector_lsb_rx = int.from_bytes(packet_rx[7:8], byteorder = 'big')
		page_rx = int.from_bytes(packet_rx[8:9], byteorder = 'big')
		data_length_rx = int.from_bytes(packet_rx[9:11], byteorder = 'big')
		#end_flag_msb_rx =  packet_rx[0:1]
		#end_flag_lsb_rx =  packet_rx[0:1]
		#crc8_rx =  packet_rx[0:1]

		if (start_flag1 == DS_VOYAGER_START_FLAG_MSB and
			start_flag2 == DS_VOYAGER_START_FLAG_LSB and
			packet_definition1 == DS_VOYAGER_EXT_FLASH and
			packet_definition2 == DS_VOYAGER_EXT_FLASH_BAT_LOG and
			command_class_rx == READ_COMMAND_RESPONSE and
			sector_msb_rx == sector_msb and
			sector_lsb_rx == sector_lsb and
			page_rx == page and
			data_length_rx == 0x100):
			
			for n in range (0, 16):
				if (int.from_bytes(packet_rx[11 + battery_log_slot_size * n:19 + battery_log_slot_size * n], byteorder = 'big') != 0xFFFFFFFFFFFFFFFF):
					time_rx = int.from_bytes(packet_rx[11 + battery_log_slot_size * n:15 + battery_log_slot_size * n], byteorder = 'big')	
					second = time_rx % 60	
					minute = (time_rx // 60) % 60
					hour = (time_rx // (60 * 60)) % 24
					day = (time_rx // (60 * 60 * 24)) % 365
					year = 1970 + time_rx // (60 * 60 * 24 * 365)
					
					battery_chg = int.from_bytes(packet_rx[15 + battery_log_slot_size * n:17 + battery_log_slot_size * n], byteorder = 'big')
					battery_temp = int.from_bytes(packet_rx[17 + battery_log_slot_size * n:19 + battery_log_slot_size * n], byteorder = 'big')
					battery_temp = ((battery_temp - k_to_c)/10)
					subscription_reason = int.from_bytes(packet_rx[19 + battery_log_slot_size * n: 20 + battery_log_slot_size * n], byteorder = 'big')
					charger_state = (subscription_reason & 0b00000100) >> 2
					
					charger_state_str = []
					if charger_state == 0:
						charger_state_str = "	Charger not connected"
					else:
						charger_state_str = "	Charger connected"
					
					subscription_reason = subscription_reason & 0b00000011
					
					subscription_reason_str = []
					
					if subscription_reason == 0:
						subscription_reason_str = "	Charger in"
					elif subscription_reason == 1:
						subscription_reason_str = "	Charger out"
					elif subscription_reason == 2:
						subscription_reason_str = "	Periodic"
					elif subscription_reason == 3:
						subscription_reason_str = "	Boot	"
					
					print(year, "-", day, "	", hour, ":", minute, ":", second, "	Remaining capacity:", battery_chg, "mAh", "	temp:", battery_temp, "degC", subscription_reason_str, charger_state_str)
	if page < 0x0F:
		page += 0x01
		
	else:
		page = 0x00
		sector_lsb += 0x01			
	
ser.close()
exit()
