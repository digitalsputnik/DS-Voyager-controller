#!/bin/sh

kill -9 $(ps ax | grep vymain.py | awk 'NR==1{print $1}')

# ENTER ISP MODE

echo 43 > /sys/class/gpio/export               	# Export ISP pin. 
echo out > /sys/class/gpio/gpio43/direction    	# ISP pin output
echo 0 > /sys/class/gpio/gpio43/value          	# Set ISP pin low

sleep .2                                        # Wait .2 sec
echo 50 > /sys/class/gpio/export                # Export RESET pin
echo out > /sys/class/gpio/gpio50/direction     # RESET pin output
echo 0 > /sys/class/gpio/gpio50/value           # Set RESET pin low.

sleep .2                                        # Wait .2 sec
echo 1 > /sys/class/gpio/gpio50/value           # Set RESET pin high. LPC1549 goes to UART ISP mode.

# UPDATE LPC FIRMWARE

echo "Flashing user update main program"
/mnt/data/mxli -N LPC1549 -A0x00000000 -B256,512,1024,4096 -F4kix64 -M3ki@0x2000000 -I0x00001549 -P BINARY -S8@7 -f256ki -a 0x19000 -v -E -d /dev/ttyAMA0 $1
echo "Flashing user update main program complete"

# EXIT ISP MODE

sleep .2                                       	# Wait .2 sec
echo 1 > /sys/class/gpio/gpio43/value          	# Set ISP pin high. Next LPC1549 reset leads to normal boot process.
sleep .2                                        # Wait .2 sec
echo 0 > /sys/class/gpio/gpio50/value           # Set RESET pin low.
sleep .2                                        # Wait .2 sec
echo 1 > /sys/class/gpio/gpio50/value          	# Set RESET pin high.

echo 43 > /sys/class/gpio/unexport          	# Unexport ISP pin
echo 50 > /sys/class/gpio/unexport              # Unexport RESET pin

sleep 3

python3 /mnt/data/lpc_firmware_version_hw4.py	# Read LPC1549 firmware version
